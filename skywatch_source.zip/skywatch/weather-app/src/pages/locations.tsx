import React, { useState } from "react";
import { MapPin, Search, Star, Trash2, Check } from "lucide-react";
import { useActiveLocation } from "@/hooks/use-active-location";
import { LocationSearch } from "@/components/ui/location-search";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const LocationsPage: React.FC = () => {
  const { locations, active, setActive, remove } = useActiveLocation();
  const [removing, setRemoving] = useState<number | null>(null);

  const handleRemove = async (id: number) => {
    setRemoving(id);
    try { await remove(id); } finally { setRemoving(null); }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Saved Locations</h1>
        <p className="text-slate-500 mt-1">Manage the cities you track with SkyWatch.</p>
      </div>

      <div className="card p-6">
        <LocationSearch />
      </div>

      <div>
        <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-3">
          <Star size={18} className="text-amber-500" /> Your Places
        </h2>
        {locations.length === 0 ? (
          <div className="card p-8 text-center text-slate-500">
            You haven't saved any locations yet. Use the search above to add your first city.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {locations.map((l) => (
              <div key={l.id} className={cn(
                "card p-5 transition-all",
                l.id === active?.id ? "ring-2 ring-brand-500 border-brand-200" : "hover:shadow-cardHover"
              )}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-brand-50 text-brand-600 flex items-center justify-center flex-shrink-0">
                      <MapPin size={16} />
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900 truncate">{l.name}</div>
                      <div className="text-xs text-slate-500 truncate">{[l.region, l.country].filter(Boolean).join(", ")}</div>
                    </div>
                  </div>
                  {l.id === active?.id && (
                    <span className="badge bg-brand-600 text-white flex-shrink-0">
                      <Check size={10} /> Active
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-500 mb-3">
                  {l.latitude.toFixed(4)}°, {l.longitude.toFixed(4)}°
                </div>
                <div className="flex gap-2">
                  {l.id !== active?.id && (
                    <Button size="sm" variant="primary" onClick={() => setActive(l.id)}>
                      Set Active
                    </Button>
                  )}
                  <Button size="sm" variant="danger" disabled={removing === l.id} onClick={() => handleRemove(l.id)}>
                    <Trash2 size={14} /> {removing === l.id ? "Removing…" : "Remove"}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
