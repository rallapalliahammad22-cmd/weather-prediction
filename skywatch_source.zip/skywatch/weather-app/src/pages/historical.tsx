import React, { useEffect, useMemo, useState } from "react";
import {
  BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend, ReferenceLine,
} from "recharts";
import {
  Thermometer, CloudRain, TrendingUp, TrendingDown,
  Sun, Wind, Award, AlertTriangle, MapPin, BarChart3,
} from "lucide-react";
import { useActiveLocation } from "@/hooks/use-active-location";
import { get } from "@/lib/api";
import type { ClimateNormals } from "@/lib/types";
import { ErrorBoundary } from "@/components/error-boundary";

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const MONTH_SHORT = MONTHS.map(m => m.slice(0, 3));

export const HistoricalPage: React.FC = () => (
  <ErrorBoundary>
    <HistoricalPageInner />
  </ErrorBoundary>
);

const HistoricalPageInner: React.FC = () => {
  const { active } = useActiveLocation();
  const [climate, setClimate] = useState<ClimateNormals | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!active) return;
    setLoading(true);
    setError(null);
    get<{ climate: ClimateNormals }>(`/api/weather/climate?lat=${active.latitude}&lon=${active.longitude}`)
      .then(r => {
        if (!r?.climate) throw new Error("Empty climate response");
        setClimate(r.climate);
      })
      .catch(err => setError(err.message || String(err)))
      .finally(() => setLoading(false));
  }, [active]);

  if (!active) return <div className="text-slate-500">No active location.</div>;
  if (loading)   return <div className="card p-10 text-center text-slate-500">Loading climate data…</div>;
  if (error)     return <div className="card p-6 text-red-700 bg-red-50 border-red-200">Failed to load climate data: {error}</div>;
  if (!climate)  return <div className="text-slate-500">No climate data available.</div>;

  return (
    <div className="space-y-6">
      <Header locationName={active.name} range={climate.dataRange} zone={active.country || ""} />

      {/* KPI strip */}
      <KpiStrip climate={climate} />

      {/* 5-year temperature trend */}
      <YearTrendChart climate={climate} />

      {/* Monthly temperature + rainfall grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MonthlyTempCard climate={climate} />
        <MonthlyRainCard climate={climate} />
      </div>

      {/* Sunshine & rainy days heatmap-like grid */}
      <SunshineAndRainGrid climate={climate} />

      {/* Insights */}
      <InsightsGrid climate={climate} />

      {/* Best time to visit */}
      <BestMonthsCard climate={climate} />

      {/* Rainy season banner */}
      <RainySeasonBanner climate={climate} />
    </div>
  );
};

// ===========================
// Sub-components
// ===========================

const Header: React.FC<{ locationName: string; range: { from: number; to: number }; zone: string }> = ({ locationName, range, zone }) => (
  <div className="flex flex-wrap items-end justify-between gap-4">
    <div>
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <MapPin size={14} />
        <span>{zone}</span>
      </div>
      <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mt-1">Climate Normals · {locationName}</h1>
      <p className="text-slate-600 mt-2">
        Historical weather analysis spanning{" "}
        <span className="font-semibold text-slate-900">{range.from}–{range.to}</span>{" "}
        (5 reconstructed years)
      </p>
    </div>
    <div className="card px-4 py-3 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100">
      <div className="text-xs text-slate-500 font-medium">Last updated</div>
      <div className="text-base font-bold text-slate-900">{new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</div>
    </div>
  </div>
);

const KpiStrip: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const warming = climate.insights?.warmingTrend ?? 0;
  const warmingPct = `${warming >= 0 ? "+" : ""}${warming}°C/yr`;
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <Kpi
        icon={<Thermometer size={20} />}
        label="Annual Avg Temp"
        value={`${Number(climate.annualAvgTemp ?? 0).toFixed(1)}°C`}
        sub={`Range: ${Number(climate.annualAvgLow ?? 0).toFixed(1)}° – ${Number(climate.annualAvgHigh ?? 0).toFixed(1)}°`}
        accent="amber"
      />
      <Kpi
        icon={<CloudRain size={20} />}
        label="Annual Rainfall"
        value={`${Math.round(Number(climate.annualRainfall ?? 0)).toLocaleString()} mm`}
        sub={`${climate.annualRainyDays ?? 0} rainy days/yr`}
        accent="blue"
      />
      <Kpi
        icon={<Sun size={20} />}
        label="Sunshine"
        value={`${(climate.annualSunshineHours ?? 0).toLocaleString()} hrs/yr`}
        sub={`${((climate.annualSunshineHours ?? 0) / 365).toFixed(1)} hrs/day avg`}
        accent="orange"
      />
      <Kpi
        icon={<TrendingUp size={20} />}
        label="Warming Trend"
        value={warmingPct}
        sub={`Over ${climate.dataSpanYears ?? 5} year period`}
        accent={warming > 0 ? "red" : "green"}
        trend={warming > 0 ? "up" : "down"}
      />
    </div>
  );
};

const Kpi: React.FC<{
  icon: React.ReactNode; label: string; value: string; sub: string;
  accent: "amber" | "blue" | "orange" | "red" | "green"; trend?: "up" | "down";
}> = ({ icon, label, value, sub, accent, trend }) => {
  const palette: Record<string, { bg: string; text: string; chip: string }> = {
    amber:  { bg: "bg-amber-50",  text: "text-amber-700",  chip: "from-amber-400 to-orange-400" },
    blue:   { bg: "bg-blue-50",   text: "text-blue-700",   chip: "from-blue-400 to-cyan-400" },
    orange: { bg: "bg-orange-50", text: "text-orange-700", chip: "from-orange-400 to-yellow-400" },
    red:    { bg: "bg-red-50",    text: "text-red-700",    chip: "from-red-400 to-rose-500" },
    green:  { bg: "bg-emerald-50",text: "text-emerald-700",chip: "from-emerald-400 to-teal-400" },
  };
  const c = palette[accent];
  return (
    <div className="card p-5 relative overflow-hidden">
      <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full bg-gradient-to-br ${c.chip} opacity-10`} />
      <div className="flex items-center gap-3 mb-3 relative">
        <div className={`w-10 h-10 rounded-lg ${c.bg} ${c.text} flex items-center justify-center`}>{icon}</div>
        <div className="text-sm text-slate-600 font-medium">{label}</div>
      </div>
      <div className="flex items-baseline gap-2">
        <div className="text-2xl font-bold text-slate-900">{value}</div>
        {trend && (
          <div className={trend === "up" ? "text-red-500" : "text-emerald-500"}>
            {trend === "up" ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
          </div>
        )}
      </div>
      <div className="text-xs text-slate-500 mt-1">{sub}</div>
    </div>
  );
};

const YearTrendChart: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const data = useMemo(() => {
    const from = climate.dataRange?.from ?? 2020;
    return (climate.yearlyAvgTemps ?? []).map((temp, i) => ({
      year: String(from + i),
      avgTemp: temp,
      rainfall: climate.yearlyRainfall?.[i] ?? 0,
    }));
  }, [climate]);

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <BarChart3 size={18} /> 5-Year Temperature &amp; Rainfall Trend
          </h2>
          <p className="text-sm text-slate-500 mt-1">How this location's climate has varied year over year</p>
        </div>
      </div>
      <ChartBox heightPx={320}>
        <AreaChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
          <defs>
            <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#f97316" stopOpacity={0.6}/>
              <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
            </linearGradient>
            <linearGradient id="rainGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.6}/>
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis dataKey="year" tick={{ fontSize: 12, fill: "#64748b" }} />
          <YAxis yAxisId="temp" tick={{ fontSize: 12, fill: "#64748b" }} domain={["dataMin - 1", "dataMax + 1"]} />
          <YAxis yAxisId="rain" orientation="right" tick={{ fontSize: 12, fill: "#64748b" }} />
          <Tooltip
            contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }}
            labelStyle={{ color: "#475569", fontWeight: 600 }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Area yAxisId="temp" type="monotone" dataKey="avgTemp" name="Avg Temp (°C)" stroke="#f97316" strokeWidth={2.5} fill="url(#tempGrad)" />
          <Area yAxisId="rain" type="monotone" dataKey="rainfall" name="Rainfall (mm)" stroke="#3b82f6" strokeWidth={2.5} fill="url(#rainGrad)" />
          <ReferenceLine yAxisId="temp" y={climate.annualAvgTemp} stroke="#94a3b8" strokeDasharray="4 4" />
        </AreaChart>
      </ChartBox>
    </div>
  );
};

const MonthlyTempCard: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const data = useMemo(
    () => MONTH_SHORT.map((m, i) => ({
      month: m,
      high: climate.monthlyHighs?.[i] ?? 0,
      low:  climate.monthlyLows?.[i] ?? 0,
    })),
    [climate]
  );

  return (
    <div className="card p-6">
      <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-1">
        <Thermometer size={18} /> Monthly Temperature Range
      </h2>
      <p className="text-sm text-slate-500 mb-4">Min and max temperatures per month (°C)</p>
      <ChartBox heightPx={280}>
        <BarChart data={data} barCategoryGap="18%" margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#64748b" }} />
          <YAxis tick={{ fontSize: 11, fill: "#64748b" }} />
          <Tooltip
            contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }}
            labelStyle={{ color: "#475569", fontWeight: 600 }}
            formatter={(value: any, name: any) => [`${value}°C`, String(name)]}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="high" name="High" fill="#ef4444" radius={[6, 6, 0, 0]} />
          <Bar dataKey="low"  name="Low"  fill="#3b82f6" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ChartBox>
    </div>
  );
};

const MonthlyRainCard: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const data = useMemo(
    () => MONTH_SHORT.map((m, i) => ({
      month: m,
      rain: climate.monthlyRain?.[i] ?? 0,
      days: climate.monthlyRainDays?.[i] ?? 0,
    })),
    [climate]
  );

  return (
    <div className="card p-6">
      <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-1">
        <CloudRain size={18} /> Monthly Rainfall
      </h2>
      <p className="text-sm text-slate-500 mb-4">Average mm &amp; rainy days per month</p>
      <ChartBox heightPx={280}>
        <BarChart data={data} barCategoryGap="18%" margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#64748b" }} />
          <YAxis yAxisId="rain" tick={{ fontSize: 11, fill: "#64748b" }} />
          <YAxis yAxisId="days" orientation="right" tick={{ fontSize: 11, fill: "#64748b" }} domain={[0, 31]} />
          <Tooltip
            contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }}
            labelStyle={{ color: "#475569", fontWeight: 600 }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar yAxisId="rain" dataKey="rain" name="Rain (mm)" fill="#60a5fa" radius={[6, 6, 0, 0]} />
          <Bar yAxisId="days" dataKey="days" name="Rainy days" fill="#94a3b8" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ChartBox>
    </div>
  );
};

const SunshineAndRainGrid: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const rain  = climate.monthlyRain ?? [];
  const sun   = climate.monthlySunshineHours ?? [];
  const maxRain = rain.length ? Math.max(...rain) : 1;
  const maxSun  = sun.length  ? Math.max(...sun)  : 1;

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Sun size={18} /> Sunshine &amp; Rain Pattern
          </h2>
          <p className="text-sm text-slate-500">Heatmap-style view across the year (darker = more rain)</p>
        </div>
      </div>

      <div className="grid grid-cols-6 sm:grid-cols-12 gap-1">
        {MONTH_SHORT.map((m, i) => {
          const rainVal = rain[i] ?? 0;
          const sunVal  = sun[i] ?? 0;
          const rainIntensity = maxRain > 0 ? rainVal / maxRain : 0;
          const bg = `rgba(59, 130, 246, ${(0.15 + rainIntensity * 0.7).toFixed(2)})`;
          return (
            <div
              key={m}
              className="rounded-md p-2 text-center border border-slate-200"
              style={{ background: bg }}
              title={`${m}: ${Math.round(rainVal)} mm rain, ${sunVal} hrs sun/day`}
            >
              <div className="text-[10px] uppercase font-bold text-slate-700 tracking-wider">{m}</div>
              <div className="text-lg font-bold text-white drop-shadow">{Math.round(rainVal)}</div>
              <div className="text-[10px] text-white/90">mm</div>
              <div className="mt-1 text-[10px] text-white/90 flex items-center justify-center gap-0.5">
                <Sun size={10} /> {sunVal}h
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between mt-4 text-xs text-slate-500 flex-wrap gap-2">
        <span>Cell color = rainfall intensity</span>
        <span className="flex items-center gap-2">
          <span className="w-3 h-3 rounded bg-blue-200" /> Low
          <span className="w-3 h-3 rounded bg-blue-400" /> Medium
          <span className="w-3 h-3 rounded bg-blue-700" /> High
        </span>
      </div>
    </div>
  );
};

const InsightsGrid: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const ins = climate.insights ?? {
    extremeHeatDaysPerYear: 0,
    heavyRainDaysPerYear: 0,
    thunderstormDaysPerYear: 0,
    sunnyDaysPerYear: 0,
    comfortDaysPerYear: 0,
    temperatureRangeC: 0,
    warmingTrend: 0,
  };
  const ex = climate.extremes ?? {
    hottestMonth: "—", hottestMonthTemp: 0,
    coldestMonth: "—", coldestMonthTemp: 0,
    wettestMonth: "—", wettestMonthRain: 0,
  };

  const stats = [
    { icon: <AlertTriangle size={18} />, label: "Extreme Heat Days", value: `${ins.extremeHeatDaysPerYear}`, unit: "days/yr", desc: "Days above 35 °C", color: "red" },
    { icon: <CloudRain size={18} />,     label: "Heavy Rain Days",  value: `${ins.heavyRainDaysPerYear}`,   unit: "days/yr", desc: "Days with >50 mm", color: "blue" },
    { icon: <Wind size={18} />,          label: "Thunderstorm Days",value: `${ins.thunderstormDaysPerYear}`,unit: "days/yr", desc: "Days with storms", color: "purple" },
    { icon: <Sun size={18} />,           label: "Sunny Days",       value: `${ins.sunnyDaysPerYear}`,       unit: "days/yr", desc: "Mostly clear skies", color: "orange" },
    { icon: <Award size={18} />,         label: "Comfortable Days", value: `${ins.comfortDaysPerYear}`,     unit: "days/yr", desc: "Mild with light rain", color: "green" },
    { icon: <Thermometer size={18} />,   label: "Temperature Range",value: `${ins.temperatureRangeC}°`,      unit: "C",       desc: `From ${ex.coldestMonthTemp}° to ${ex.hottestMonthTemp}°`, color: "amber" },
  ];

  const palette: Record<string, { bg: string; text: string }> = {
    red:    { bg: "bg-red-50",    text: "text-red-700" },
    blue:   { bg: "bg-blue-50",   text: "text-blue-700" },
    purple: { bg: "bg-purple-50", text: "text-purple-700" },
    orange: { bg: "bg-orange-50", text: "text-orange-700" },
    green:  { bg: "bg-emerald-50",text: "text-emerald-700" },
    amber:  { bg: "bg-amber-50",  text: "text-amber-700" },
  };

  return (
    <div>
      <h2 className="text-lg font-semibold text-slate-900 mb-3 flex items-center gap-2">
        <BarChart3 size={18} /> Climate Insights
      </h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {stats.map((s) => {
          const c = palette[s.color];
          return (
            <div key={s.label} className="card p-4">
              <div className={`w-9 h-9 rounded-lg ${c.bg} ${c.text} flex items-center justify-center mb-2`}>{s.icon}</div>
              <div className="text-xs text-slate-500 font-medium">{s.label}</div>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl font-bold text-slate-900">{s.value}</span>
                <span className="text-xs text-slate-500">{s.unit}</span>
              </div>
              <div className="text-[11px] text-slate-500 mt-1 leading-snug">{s.desc}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const BestMonthsCard: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const best = climate.bestMonths ?? [];
  if (best.length === 0) {
    return (
      <div className="card p-6 bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 border-emerald-200">
        <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-1">
          <Award size={18} className="text-emerald-600" /> Best Months to Visit
        </h2>
        <p className="text-sm text-slate-600">Insufficient data to determine best months.</p>
      </div>
    );
  }
  return (
    <div className="card p-6 bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 border-emerald-200">
      <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-1">
        <Award size={18} className="text-emerald-600" /> Best Months to Visit
      </h2>
      <p className="text-sm text-slate-600 mb-4">Top 3 months ranked by comfort (temperature, rainfall, sunshine)</p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {best.map((bm, i) => (
          <div key={bm.month} className="bg-white rounded-xl p-5 border border-emerald-200 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-emerald-400 to-teal-400 opacity-20 rounded-full -mr-8 -mt-8" />
            <div className="flex items-center justify-between mb-2 relative">
              <div className="text-xs text-emerald-700 font-bold uppercase tracking-wider">
                {i === 0 ? "🥇 Best" : i === 1 ? "🥈 Great" : "🥉 Good"}
              </div>
              <div className="bg-emerald-100 text-emerald-700 text-xs font-bold px-2 py-0.5 rounded-full">
                {bm.score}/100
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900">{bm.month}</div>
            <div className="text-sm text-slate-600 mt-1">{bm.reason}</div>
            <div className="mt-3 h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full"
                style={{ width: `${bm.score}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const RainySeasonBanner: React.FC<{ climate: ClimateNormals }> = ({ climate }) => {
  const months = climate.rainySeason?.months ?? [];
  if (months.length === 0) return null;
  return (
    <div className="card p-5 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 flex items-start gap-4">
      <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center flex-shrink-0">
        <CloudRain size={24} />
      </div>
      <div>
        <h3 className="text-base font-semibold text-slate-900">
          Rainy Season: {climate.rainySeason?.start ?? "—"} – {climate.rainySeason?.end ?? "—"}
        </h3>
        <p className="text-sm text-slate-600 mt-1">
          Expect significant rainfall during {months.join(", ")}.
          The wettest month is <strong>{climate.extremes?.wettestMonth ?? "—"}</strong> with{" "}
          <strong>{climate.extremes?.wettestMonthRain ?? 0} mm</strong> of precipitation on average.
        </p>
      </div>
    </div>
  );
};

/** Defensive chart wrapper that waits for non-zero dimensions. */
const ChartBox: React.FC<{ children: React.ReactElement; heightPx?: number }> = ({ children, heightPx = 320 }) => {
  const [size, setSize] = useState({ w: 0, h: 0 });
  const ref = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => setSize({ w: el.clientWidth, h: el.clientHeight });
    measure();
    let ro: ResizeObserver | null = null;
    try {
      ro = new ResizeObserver(measure);
      ro.observe(el);
    } catch {
      // Fallback for older browsers
      window.addEventListener("resize", measure);
    }
    return () => {
      if (ro) ro.disconnect();
      else window.removeEventListener("resize", measure);
    };
  }, []);

  return (
    <div ref={ref} style={{ height: `${heightPx}px`, width: "100%" }}>
      {size.w > 0 && size.h > 0 ? (
        <ResponsiveContainer width={size.w} height={size.h}>
          {children}
        </ResponsiveContainer>
      ) : (
        <div className="h-full flex items-center justify-center text-slate-400 text-sm">Loading chart…</div>
      )}
    </div>
  );
};
