import React, { useEffect, useState } from "react";
import { Bell, BellOff, Check, Trash2, RefreshCw, AlertTriangle, Flame, Wind, Thermometer, CloudRain, Mail, MessageSquare, Smartphone, Monitor, Settings as SettingsIcon } from "lucide-react";
import { useActiveLocation } from "@/hooks/use-active-location";
import { useAuth, readLocalPrefs, writeLocalPrefs } from "@/hooks/use-auth";
import { get, post, del, api } from "@/lib/api";
import type { AlertRow } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { severityColor, cn } from "@/lib/utils";

const TYPE_ICON: Record<string, React.ReactNode> = {
  heavy_rain:   <CloudRain size={18} />,
  high_heat:    <Thermometer size={18} />,
  heatwave:     <Flame size={18} />,
  strong_wind:  <Wind size={18} />,
  temp_swing:   <Thermometer size={18} />,
  thunderstorm: <AlertTriangle size={18} />,
};

export const AlertsPage: React.FC = () => {
  const { active } = useActiveLocation();
  const { user, updatePrefs } = useAuth();
  const [alerts, setAlerts] = useState<AlertRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [prefsOpen, setPrefsOpen] = useState(false);
  const [pushEnabled, setPushEnabled] = useState(false);
  const [vapidKey, setVapidKey] = useState("");

  const refresh = async () => {
    if (!active) return;
    setLoading(true);
    try {
      const r = await get<{ alerts: AlertRow[] }>("/api/alerts");
      const mine = r.alerts.filter(a => a.location_id === active.id);
      // First-time visitors: auto-generate alerts for the active location
      // so they see something useful right away.
      if (mine.length === 0) {
        await post("/api/alerts/generate", { locationId: active.id }).catch(() => {});
        const r2 = await get<{ alerts: AlertRow[] }>("/api/alerts");
        setAlerts(r2.alerts.filter(a => a.location_id === active.id));
      } else {
        setAlerts(mine);
      }
    } finally { setLoading(false); }
  };

  useEffect(() => { refresh(); }, [active]);

  useEffect(() => {
    api<{ key: string; configured: boolean }>("/api/notifications/vapid-public-key")
      .then(r => { setVapidKey(r.key); setPushEnabled(r.configured && !!r.key); })
      .catch(() => {});
  }, []);

  const generate = async () => {
    if (!active) return;
    setGenerating(true);
    try {
      await post("/api/alerts/generate", { locationId: active.id });
      await refresh();
    } finally { setGenerating(false); }
  };

  const acknowledge = async (id: number) => {
    await post(`/api/alerts/${id}/acknowledge`);
    await refresh();
  };

  const remove = async (id: number) => {
    await del(`/api/alerts/${id}`);
    await refresh();
  };

  const activeAlerts = alerts.filter(a => !a.acknowledged);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Weather Alerts</h1>
          <p className="text-slate-500 mt-1">
            Automatic alerts for {active?.name} when heavy rainfall, extreme heat, or unusual weather is forecasted.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary" onClick={() => setPrefsOpen(true)}>
            <SettingsIcon size={14} /> Notification Settings
          </Button>
          <Button onClick={generate} disabled={generating}>
            <RefreshCw size={14} className={cn(generating && "animate-spin")} />
            {generating ? "Generating…" : "Generate Alerts"}
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="text-slate-500">Loading…</div>
      ) : activeAlerts.length === 0 ? (
        <div className="card p-10 text-center">
          <BellOff size={36} className="text-slate-300 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-slate-900">No active alerts</h3>
          <p className="text-slate-500 mt-1 max-w-md mx-auto">
            SkyWatch didn't detect any extreme conditions in the next 14 days for {active?.name}.
            You can still generate a fresh analysis anytime.
          </p>
          <Button className="mt-4" onClick={generate} disabled={generating}>
            {generating ? "Generating…" : "Generate Now"}
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {activeAlerts.map(a => (
            <div key={a.id} className={cn("card p-5 border-l-4",
              a.severity === "extreme" ? "border-l-purple-500" :
              a.severity === "high"     ? "border-l-red-500" :
              a.severity === "moderate" ? "border-l-amber-500" :
                                           "border-l-blue-500"
            )}>
              <div className="flex items-start gap-4">
                <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center",
                  a.severity === "extreme" ? "bg-purple-100 text-purple-700" :
                  a.severity === "high"     ? "bg-red-100 text-red-700" :
                  a.severity === "moderate" ? "bg-amber-100 text-amber-700" :
                                               "bg-blue-100 text-blue-700"
                )}>
                  {TYPE_ICON[a.type] || <Bell size={18} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-semibold text-slate-900">{a.title}</h3>
                    <span className={cn("badge border", severityColor(a.severity))}>{a.severity}</span>
                    <span className="text-xs text-slate-500">forecast: {a.forecast_day}</span>
                  </div>
                  <p className="text-slate-600 mt-1.5 text-sm">{a.message}</p>
                  <div className="flex items-center gap-2 mt-3">
                    <Button size="sm" variant="secondary" onClick={() => acknowledge(a.id)}>
                      <Check size={14} /> Acknowledge
                    </Button>
                    <Button size="sm" variant="danger" onClick={() => remove(a.id)}>
                      <Trash2 size={14} /> Dismiss
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Acknowledged alerts log */}
      {alerts.filter(a => a.acknowledged).length > 0 && (
        <div className="card p-6">
          <h3 className="text-base font-semibold text-slate-900 mb-3">Recent History</h3>
          <div className="space-y-2">
            {alerts.filter(a => a.acknowledged).slice(0, 5).map(a => (
              <div key={a.id} className="flex items-center gap-3 py-2 border-b border-slate-100 last:border-b-0">
                <div className="text-slate-400">{TYPE_ICON[a.type]}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-700">{a.title}</div>
                  <div className="text-xs text-slate-500">{a.forecast_day} · acknowledged</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <NotificationPrefsDialog
        open={prefsOpen}
        onClose={() => setPrefsOpen(false)}
        isLoggedIn={!!user}
        userPhone={user?.phone ?? null}
        onSave={async (prefs, phone) => {
          await updatePrefs(prefs);
          if (phone !== undefined && user) {
            await post("/api/auth/me", { phone });
          }
          if (prefs.push && pushEnabled) {
            await enablePush(vapidKey);
          }
          setPrefsOpen(false);
        }}
      />
    </div>
  );
};

interface PrefsDialogProps {
  open: boolean;
  onClose: () => void;
  isLoggedIn: boolean;
  userPhone: string | null;
  onSave: (prefs: { email: boolean; sms: boolean; push: boolean; inApp: boolean }, phone?: string | null) => Promise<void>;
}

const NotificationPrefsDialog: React.FC<PrefsDialogProps> = ({ open, onClose, isLoggedIn, userPhone, onSave }) => {
  const local = readLocalPrefs();
  const [prefs, setPrefs] = useState(local);
  const [phone, setPhone] = useState(userPhone || "");

  useEffect(() => {
    if (open) {
      setPrefs(readLocalPrefs());
      setPhone(userPhone || "");
    }
  }, [open, userPhone]);

  return (
    <Dialog open={open} onClose={onClose} title={
      <div className="flex items-center gap-2">
        <SettingsIcon size={18} className="text-brand-600" /> Notification Preferences
      </div>
    }>
      <p className="text-sm text-slate-500 mb-4">
        Choose how you want to be alerted. {!isLoggedIn && "You can use these without signing in — settings are saved in this browser."}
      </p>
      <div className="space-y-3">
        <ChannelRow icon={<Monitor size={16} />}    label="In-app alerts"    desc="Always visible on this device"
                    checked={prefs.inApp} onChange={(v) => setPrefs({ ...prefs, inApp: v })} />
        <ChannelRow icon={<Mail size={16} />}       label="Email"           desc={isLoggedIn ? "Sent to your account email" : "Provide your email below"}
                    checked={prefs.email} onChange={(v) => setPrefs({ ...prefs, email: v })} />
        {!isLoggedIn && prefs.email && (
          <input type="email" required placeholder="you@example.com" className="input" id="anon-email"
            onChange={(e) => { (window as any).__anonEmail = e.target.value; }} />
        )}
        <ChannelRow icon={<MessageSquare size={16} />} label="SMS" desc="Standard rates may apply"
                    checked={prefs.sms} onChange={(v) => setPrefs({ ...prefs, sms: v })} />
        {(prefs.sms) && (
          <div>
            <input type="tel" placeholder="+91 9876543210" className="input" value={phone} onChange={(e) => setPhone(e.target.value)} />
            {!isLoggedIn && <p className="text-xs text-slate-500 mt-1">For SMS without login, this number is stored only in your browser.</p>}
          </div>
        )}
        <ChannelRow icon={<Smartphone size={16} />} label="Browser push notifications" desc="Even when this tab is closed"
                    checked={prefs.push} onChange={(v) => setPrefs({ ...prefs, push: v })} />
      </div>
      <div className="mt-6 flex justify-end gap-2">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button onClick={() => onSave(prefs, phone)}>Save Preferences</Button>
      </div>
    </Dialog>
  );
};

const ChannelRow: React.FC<{ icon: React.ReactNode; label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }> = ({ icon, label, desc, checked, onChange }) => (
  <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50">
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 rounded-lg bg-brand-50 text-brand-600 flex items-center justify-center">{icon}</div>
      <div>
        <div className="font-medium text-slate-900 text-sm">{label}</div>
        <div className="text-xs text-slate-500">{desc}</div>
      </div>
    </div>
    <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="w-4 h-4 accent-brand-600" />
  </label>
);

async function enablePush(vapidKey: string) {
  if (!("serviceWorker" in navigator) || !("PushManager" in window) || !vapidKey) return false;
  try {
    const reg = await navigator.serviceWorker.register("/sw.js");
    const perm = await Notification.requestPermission();
    if (perm !== "granted") return false;
    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidKey),
    });
    const json = sub.toJSON();
    await post("/api/notifications/push/subscribe", {
      endpoint: sub.endpoint,
      keys: { p256dh: json.keys!.p256dh, auth: json.keys!.auth },
    });
    return true;
  } catch (err) {
    console.error("[push] subscribe failed", err);
    return false;
  }
}

function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = window.atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; ++i) out[i] = raw.charCodeAt(i);
  return out;
}
