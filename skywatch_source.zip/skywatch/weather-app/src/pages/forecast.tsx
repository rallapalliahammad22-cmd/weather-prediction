import React, { useEffect, useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, ReferenceDot } from "recharts";
import { CloudRain, Wind, Sunrise, Sunset, CalendarDays } from "lucide-react";
import { useActiveLocation } from "@/hooks/use-active-location";
import { get } from "@/lib/api";
import type { DailyWeather } from "@/lib/types";
import { conditionEmoji, fmtDate, fmtDayShort, cn } from "@/lib/utils";

export const ForecastPage: React.FC = () => {
  const { active } = useActiveLocation();
  const [forecast, setForecast] = useState<DailyWeather[]>([]);
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!active) return;
    setLoading(true);
    get<{ forecast: DailyWeather[] }>(`/api/weather/forecast?lat=${active.latitude}&lon=${active.longitude}`)
      .then(r => setForecast(r.forecast))
      .finally(() => setLoading(false));
  }, [active]);

  const selected = forecast[selectedIdx];

  const chartData = useMemo(() => {
    if (!selected) return [];
    return selected.hourly.map(h => ({
      hour: h.hour,
      label: h.hour === 0 ? "12 AM" : h.hour < 12 ? `${h.hour} AM` : h.hour === 12 ? "12 PM" : `${h.hour - 12} PM`,
      temp: h.temperature,
      feelsLike: h.feelsLike,
      precipProb: h.precipitationProb,
    }));
  }, [selected]);

  if (loading || !selected || !active) return <div className="text-slate-500">Loading forecast…</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">14-Day Forecast</h1>
        <p className="text-slate-500 mt-1">Detailed hourly and daily outlook for {active.name} · powered by 5-year historical analysis</p>
      </div>

      {/* Day selector strip */}
      <div className="card p-3">
        <div className="overflow-x-auto">
          <div className="flex gap-2">
            {forecast.map((d, i) => {
              const { weekday, day } = fmtDayShort(d.date);
              return (
                <button
                  key={d.date}
                  onClick={() => setSelectedIdx(i)}
                  className={cn(
                    "flex-shrink-0 w-20 py-3 px-2 rounded-lg border text-center transition-colors",
                    i === selectedIdx
                      ? "bg-brand-600 text-white border-brand-600"
                      : "bg-white border-slate-200 hover:bg-slate-50"
                  )}
                >
                  <div className={cn("text-xs font-medium", i === selectedIdx ? "text-brand-100" : "text-slate-500")}>{weekday}</div>
                  <div className={cn("text-base font-bold", i === selectedIdx ? "text-white" : "text-slate-900")}>{day}</div>
                  <div className="text-xl my-1">{conditionEmoji(d.condition)}</div>
                  <div className={cn("text-xs font-semibold", i === selectedIdx ? "text-white" : "text-slate-900")}>
                    {Math.round(d.tempHigh)}°<span className={cn("ml-1", i === selectedIdx ? "text-brand-200" : "text-slate-400")}>{Math.round(d.tempLow)}°</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Selected day detail */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-6 lg:col-span-2">
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="text-sm text-slate-500">{fmtDate(selected.date, "EEEE")}</div>
              <div className="text-2xl font-bold text-slate-900">{fmtDate(selected.date, "MMMM d, yyyy")}</div>
              <div className="text-slate-600 mt-2 flex items-center gap-2">
                <span className="text-3xl">{conditionEmoji(selected.condition)}</span>
                <span>{selected.description}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-5xl font-bold text-slate-900 leading-none">{Math.round(selected.tempHigh)}°</div>
              <div className="text-slate-500 mt-1">Low {Math.round(selected.tempLow)}°</div>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            <Mini icon={<CloudRain size={14} className="text-brand-600" />} label="Rain Prob." value={`${selected.precipitationProb}%`} />
            <Mini icon={<Wind size={14} className="text-teal-600" />}       label="Max Wind"    value={`${selected.windGust.toFixed(1)} km/h`} />
            <Mini icon={<Sunrise size={14} className="text-amber-500" />}   label="Sunrise"     value={selected.sunrise} />
            <Mini icon={<Sunset size={14} className="text-orange-500" />}    label="Sunset"      value={selected.sunset} />
          </div>
          <h3 className="text-base font-semibold text-slate-900 mb-3 flex items-center gap-2">
            <CalendarDays size={16} /> Temperature Over 24 Hours
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748b" }} interval={2} />
                <YAxis tick={{ fontSize: 11, fill: "#64748b" }} domain={["dataMin - 2", "dataMax + 2"]} unit="°" />
                <Tooltip
                  contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }}
                  formatter={(v: any, n: any) => [`${v}°`, n === "temp" ? "Temperature" : "Feels like"]}
                  labelFormatter={(l) => `Time: ${l}`}
                />
                <Line type="monotone" dataKey="temp" stroke="#2563eb" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
                <Line type="monotone" dataKey="feelsLike" stroke="#94a3b8" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                <ReferenceDot x={chartData[12]?.label} y={chartData[12]?.temp} r={5} fill="#ef4444" stroke="white" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-6 space-y-3">
          <h3 className="text-base font-semibold text-slate-900 mb-2">Hourly Detail</h3>
          <div className="max-h-[28rem] overflow-y-auto -mx-2">
            {selected.hourly.map(h => (
              <div key={h.hour} className="flex items-center justify-between px-2 py-2 border-b border-slate-100 last:border-b-0">
                <div className="flex items-center gap-2 w-20">
                  <span className="text-sm text-slate-600 font-medium">
                    {h.hour === 0 ? "12 AM" : h.hour < 12 ? `${h.hour} AM` : h.hour === 12 ? "12 PM" : `${h.hour - 12} PM`}
                  </span>
                </div>
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-xl">{conditionEmoji(h.condition)}</span>
                  {h.precipitationProb > 20 && (
                    <span className="text-xs text-brand-600 flex items-center gap-0.5">
                      <CloudRain size={12} /> {h.precipitationProb}%
                    </span>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-sm font-semibold text-slate-900">{Math.round(h.temperature)}°</div>
                  {Math.abs(h.temperature - h.feelsLike) >= 2 && (
                    <div className="text-xs text-slate-500">Feels {Math.round(h.feelsLike)}°</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const Mini: React.FC<{ icon: React.ReactNode; label: string; value: string }> = ({ icon, label, value }) => (
  <div className="rounded-lg border border-slate-100 p-3">
    <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
      {icon} {label}
    </div>
    <div className="text-base font-semibold text-slate-900">{value}</div>
  </div>
);
