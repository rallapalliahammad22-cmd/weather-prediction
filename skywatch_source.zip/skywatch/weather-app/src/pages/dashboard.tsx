import React, { useEffect, useState } from "react";
import { Wind, Droplets, Sun, Eye, Bell, Calendar, Activity } from "lucide-react";
import { Link } from "react-router-dom";
import { useActiveLocation } from "@/hooks/use-active-location";
import { get } from "@/lib/api";
import type { CurrentWeather, DailyWeather } from "@/lib/types";
import { WeatherIcon } from "@/components/ui/weather-icon";
import { Button } from "@/components/ui/button";
import { fmtDate, fmtDayShort, conditionEmoji } from "@/lib/utils";

export const DashboardPage: React.FC = () => {
  const { active } = useActiveLocation();
  const [current, setCurrent] = useState<CurrentWeather | null>(null);
  const [forecast, setForecast] = useState<DailyWeather[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!active) return;
    setLoading(true);
    Promise.all([
      get<{ current: CurrentWeather }>(`/api/weather/current?lat=${active.latitude}&lon=${active.longitude}`),
      get<{ forecast: DailyWeather[] }>(`/api/weather/forecast?lat=${active.latitude}&lon=${active.longitude}`),
    ]).then(([c, f]) => {
      setCurrent(c.current);
      setForecast(f.forecast);
    }).finally(() => setLoading(false));
  }, [active]);

  if (loading || !current || !active) {
    return <div className="text-slate-500">Loading…</div>;
  }

  const outlook = forecast.slice(0, 7);
  const today = forecast[0];

  return (
    <div className="space-y-6">
      {/* Location header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">{active.name}</h1>
        <p className="text-slate-500 mt-1">{[active.region, active.country].filter(Boolean).join(", ")} · {fmtDate(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      {/* Hero */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-8 lg:col-span-2">
          <div className="flex items-start justify-between gap-6">
            <div className="flex-1">
              <div className="text-7xl font-bold text-slate-900 leading-none">{Math.round(current.temperature)}°</div>
              <div className="text-xl text-slate-700 mt-2 font-medium">{current.condition}</div>
              <div className="text-sm text-slate-500 mt-1">Feels like {Math.round(current.feelsLike)}°</div>
              <div className="text-sm text-slate-600 mt-4 max-w-md">{current.description}</div>
              <div className="flex items-center gap-2 mt-6">
                <Link to="/forecast">
                  <Button variant="secondary">14-Day Forecast</Button>
                </Link>
                <Link to="/alerts">
                  <Button variant="secondary"><Bell size={14} /> Active Alerts</Button>
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <WeatherIcon condition={current.condition} size={120} />
            </div>
          </div>
        </div>

        <div className="card p-6 space-y-4">
          <Stat icon={<Wind size={18} />} label="Wind" value={`${current.windSpeed.toFixed(1)} km/h`} />
          <Stat icon={<Droplets size={18} />} label="Humidity" value={`${current.humidity}%`} />
          <Stat icon={<Sun size={18} />} label="UV Index" value={`${current.uvIndex}`} />
          <Stat icon={<Eye size={18} />} label="Visibility" value={`${current.visibility.toFixed(1)} km`} />
        </div>
      </div>

      {/* 7-day outlook */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Calendar size={18} /> 7-Day Outlook
          </h2>
          <Link to="/forecast" className="text-sm text-brand-600 hover:text-brand-700 font-medium">Details →</Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {outlook.map((d) => {
            const { weekday, day } = fmtDayShort(d.date);
            return (
              <div key={d.date} className="rounded-lg border border-slate-100 p-3 text-center hover:bg-slate-50 transition-colors">
                <div className="text-xs text-slate-500 font-medium">{weekday}</div>
                <div className="text-sm font-bold text-slate-900">{day}</div>
                <div className="text-2xl my-2">{conditionEmoji(d.condition)}</div>
                <div className="flex items-center justify-center gap-1 text-xs text-brand-600">
                  <Droplets size={10} /> {d.precipitationProb}%
                </div>
                <div className="mt-1">
                  <span className="font-bold text-slate-900">{Math.round(d.tempHigh)}°</span>
                  <span className="text-slate-400 ml-1">{Math.round(d.tempLow)}°</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Hourly forecast */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Activity size={18} /> Today's Hourly Forecast
          </h2>
          <div className="text-xs text-slate-500">{today?.description}</div>
        </div>
        <div className="overflow-x-auto -mx-2">
          <div className="flex gap-2 px-2 pb-2">
            {today?.hourly.map((h) => (
              <div key={h.hour} className="flex-shrink-0 w-20 rounded-lg border border-slate-100 p-3 text-center">
                <div className="text-xs text-slate-500 font-medium">
                  {h.hour === 0 ? "12 AM" : h.hour < 12 ? `${h.hour} AM` : h.hour === 12 ? "12 PM" : `${h.hour - 12} PM`}
                </div>
                <div className="text-2xl my-2">{conditionEmoji(h.condition)}</div>
                <div className="text-base font-bold text-slate-900">{Math.round(h.temperature)}°</div>
                {h.precipitationProb > 20 && (
                  <div className="text-xs text-brand-600 mt-1 flex items-center justify-center gap-1">
                    <Droplets size={10} /> {h.precipitationProb}%
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const Stat: React.FC<{ icon: React.ReactNode; label: string; value: string }> = ({ icon, label, value }) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center gap-3">
      <div className="w-9 h-9 rounded-lg bg-brand-50 text-brand-600 flex items-center justify-center">{icon}</div>
      <div className="text-sm text-slate-500">{label}</div>
    </div>
    <div className="text-base font-semibold text-slate-900">{value}</div>
  </div>
);
