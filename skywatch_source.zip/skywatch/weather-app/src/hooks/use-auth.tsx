import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api, getToken, setToken } from "@/lib/api";

export interface NotificationPrefs {
  email: boolean;
  sms: boolean;
  push: boolean;
  inApp: boolean;
}

export interface User {
  id: number;
  email: string;
  phone: string | null;
  displayName: string | null;
  notificationPrefs: NotificationPrefs;
  createdAt: string;
}

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, phone?: string, displayName?: string) => Promise<void>;
  signOut: () => void;
  refresh: () => Promise<void>;
  updatePrefs: (prefs: Partial<NotificationPrefs>) => Promise<void>;
  updatePhone: (phone: string | null) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);
export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
};

const PREFS_KEY = "skywatch.prefs";

export function readLocalPrefs(): NotificationPrefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { email: false, sms: false, push: false, inApp: true };
}

export function writeLocalPrefs(p: NotificationPrefs) {
  localStorage.setItem(PREFS_KEY, JSON.stringify(p));
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!getToken()) { setUser(null); setLoading(false); return; }
    try {
      const res = await api<{ user: User }>("/api/auth/me");
      setUser(res.user);
    } catch {
      setToken(null);
      setUser(null);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const signIn = async (email: string, password: string) => {
    const { token } = await api<{ token: string }>("/api/auth/login", { method: "POST", json: { email, password } });
    setToken(token);
    await refresh();
  };

  const signUp = async (email: string, password: string, phone?: string, displayName?: string) => {
    const { token } = await api<{ token: string }>("/api/auth/register", { method: "POST", json: { email, password, phone, displayName } });
    setToken(token);
    await refresh();
  };

  const signOut = () => {
    setToken(null);
    setUser(null);
  };

  const updatePrefs = async (prefs: Partial<NotificationPrefs>) => {
    // Always persist locally so anonymous browsers remember them too.
    const current = readLocalPrefs();
    writeLocalPrefs({ ...current, ...prefs });

    if (user) {
      const res = await api<{ prefs: NotificationPrefs }>("/api/notifications/preferences", { method: "POST", json: prefs });
      // Update user record
      setUser({ ...user, notificationPrefs: res.prefs });
    }
  };

  const updatePhone = async (phone: string | null) => {
    if (user) {
      await api("/api/auth/me", { method: "PATCH", json: { phone } });
      setUser({ ...user, phone });
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, refresh, updatePrefs, updatePhone }}>
      {children}
    </AuthContext.Provider>
  );
}
