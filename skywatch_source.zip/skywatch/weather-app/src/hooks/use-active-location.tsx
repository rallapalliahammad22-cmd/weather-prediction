import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api, getAnonymousId } from "@/lib/api";
import type { LocationRow } from "@/lib/types";

interface ActiveLocationContextValue {
  locations: LocationRow[];
  active: LocationRow | null;
  loading: boolean;
  refresh: () => Promise<void>;
  addLocation: (loc: Omit<LocationRow, "id" | "user_id" | "anonymous_id" | "is_active" | "created_at"> & { activate?: boolean }) => Promise<LocationRow>;
  setActive: (id: number) => Promise<void>;
  remove: (id: number) => Promise<void>;
}

const Ctx = createContext<ActiveLocationContextValue | null>(null);
export const useActiveLocation = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useActiveLocation must be used inside <ActiveLocationProvider>");
  return c;
};

// Default location if nothing saved yet
const DEFAULT_LOC: Omit<LocationRow, "id" | "user_id" | "anonymous_id" | "is_active" | "created_at"> = {
  name: "Chennai",
  country: "India",
  region: "Tamil Nadu",
  latitude: 13.0827,
  longitude: 80.2707,
  timezone: "Asia/Kolkata",
};

export function ActiveLocationProvider({ children }: { children: React.ReactNode }) {
  const [locations, setLocations] = useState<LocationRow[]>([]);
  const [active, setActiveLoc] = useState<LocationRow | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ locations: LocationRow[] }>("/api/locations");
      if (res.locations.length === 0) {
        // Seed with Chennai so the UI has something to show.
        await api("/api/locations", { method: "POST", json: { ...DEFAULT_LOC, anonymousId: getAnonymousId(), activate: true } });
        const r2 = await api<{ locations: LocationRow[] }>("/api/locations");
        setLocations(r2.locations);
        setActiveLoc(r2.locations.find(l => l.is_active) || r2.locations[0] || null);
      } else {
        setLocations(res.locations);
        setActiveLoc(res.locations.find(l => l.is_active) || res.locations[0]);
      }
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const addLocation: ActiveLocationContextValue["addLocation"] = async (loc) => {
    const { location } = await api<{ location: LocationRow }>("/api/locations", {
      method: "POST",
      json: { ...loc, anonymousId: getAnonymousId(), activate: loc.activate ?? true },
    });
    await refresh();
    return location;
  };

  const setActive = async (id: number) => {
    await api(`/api/locations/${id}/activate`, { method: "POST" });
    await refresh();
  };

  const remove = async (id: number) => {
    await api(`/api/locations/${id}`, { method: "DELETE" });
    await refresh();
  };

  return (
    <Ctx.Provider value={{ locations, active, loading, refresh, addLocation, setActive, remove }}>
      {children}
    </Ctx.Provider>
  );
}
