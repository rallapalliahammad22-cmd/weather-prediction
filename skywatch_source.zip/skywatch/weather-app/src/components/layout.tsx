import React, { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { Cloud, LayoutDashboard, CalendarDays, Bell, History, MapPin, LogIn, LogOut, User as UserIcon } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useActiveLocation } from "@/hooks/use-active-location";
import { AuthDialog } from "./auth-dialog";
import { LocationPicker } from "./ui/location-picker";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/",          label: "Dashboard",  icon: LayoutDashboard, end: true },
  { to: "/forecast",  label: "Forecast",   icon: CalendarDays },
  { to: "/alerts",    label: "Alerts",     icon: Bell },
  { to: "/historical",label: "Historical", icon: History },
  { to: "/locations", label: "Locations",  icon: MapPin },
];

export const Layout: React.FC = () => {
  const { user, signOut } = useAuth();
  const { active } = useActiveLocation();
  const [authOpen, setAuthOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 bg-brand-600 rounded-lg flex items-center justify-center">
                  <Cloud size={20} className="text-white" strokeWidth={2.5} />
                </div>
                <span className="text-lg font-bold text-slate-900">SkyWatch</span>
              </div>
              <nav className="hidden md:flex items-center gap-1">
                {NAV.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    className={({ isActive }) => cn(
                      "flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                      isActive ? "text-brand-700 bg-brand-50" : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                    )}
                  >
                    <item.icon size={16} />
                    {item.label}
                  </NavLink>
                ))}
              </nav>
            </div>
            <div className="flex items-center gap-2">
              <LocationPicker />
              {user ? (
                <div className="flex items-center gap-2">
                  <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100">
                    <UserIcon size={14} className="text-slate-600" />
                    <span className="text-sm font-medium text-slate-700">{user.displayName || user.email}</span>
                  </div>
                  <button onClick={signOut} className="p-2 rounded-lg hover:bg-slate-100 text-slate-600" title="Sign out">
                    <LogOut size={16} />
                  </button>
                </div>
              ) : (
                <button onClick={() => setAuthOpen(true)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700">
                  <LogIn size={14} /> Sign in
                </button>
              )}
            </div>
          </div>
          {/* Mobile nav */}
          <nav className="md:hidden flex items-center gap-1 pb-2 overflow-x-auto">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) => cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap",
                  isActive ? "text-brand-700 bg-brand-50" : "text-slate-600"
                )}
              >
                <item.icon size={14} />
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {active ? <Outlet /> : <div className="text-center text-slate-500 mt-20">Loading location…</div>}
      </main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 text-xs text-slate-500 flex flex-wrap justify-between gap-2">
          <div>© {new Date().getFullYear()} SkyWatch · Forecasts powered by 5-year historical analysis</div>
          <div>{active ? <>Currently showing: <strong>{active.name}</strong>, {active.country}</> : null}</div>
        </div>
      </footer>

      <AuthDialog open={authOpen} onClose={() => setAuthOpen(false)} />
    </div>
  );
};
