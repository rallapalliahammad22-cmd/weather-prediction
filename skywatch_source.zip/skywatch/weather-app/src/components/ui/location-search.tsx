import React, { useState, useEffect, useRef } from "react";
import { Search, MapPin, Plus, Star } from "lucide-react";
import { get } from "@/lib/api";
import { useActiveLocation } from "@/hooks/use-active-location";
import { Button } from "@/components/ui/button";

interface SearchResult {
  name: string;
  country: string;
  region: string;
  lat: number;
  lon: number;
  timezone: string;
}

interface Props {
  onAdded?: () => void;
  className?: string;
}

export const LocationSearch: React.FC<Props> = ({ onAdded, className }) => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [open, setOpen] = useState(false);
  const [adding, setAdding] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { addLocation } = useActiveLocation();

  useEffect(() => {
    const t = setTimeout(async () => {
      if (query.trim().length < 2) { setResults([]); return; }
      try {
        const r = await get<{ results: SearchResult[] }>(`/api/weather/search?q=${encodeURIComponent(query)}`);
        setResults(r.results);
      } catch { setResults([]); }
    }, 200);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (!containerRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const handleAdd = async (r: SearchResult) => {
    setAdding(r.lat + r.lon);
    try {
      await addLocation({
        name: r.name, country: r.country, region: r.region,
        latitude: r.lat, longitude: r.lon, timezone: r.timezone,
        activate: true,
      });
      setQuery(""); setResults([]); setOpen(false);
      onAdded?.();
    } finally { setAdding(null); }
  };

  return (
    <div ref={containerRef} className={`relative ${className || ""}`}>
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={query}
          onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Search for a city (e.g. Tokyo, Paris, New York)..."
          className="input pl-9"
        />
      </div>
      {open && results.length > 0 && (
        <div className="absolute z-30 mt-1 w-full bg-white rounded-lg border border-slate-200 shadow-lg max-h-80 overflow-y-auto">
          {results.map((r) => (
            <div key={`${r.lat}-${r.lon}`} className="flex items-center justify-between p-3 hover:bg-slate-50 border-b border-slate-100 last:border-b-0">
              <div className="flex items-start gap-3 min-w-0">
                <MapPin size={16} className="text-slate-400 mt-0.5 flex-shrink-0" />
                <div className="min-w-0">
                  <div className="font-medium text-slate-900 truncate">{r.name}</div>
                  <div className="text-xs text-slate-500 truncate">
                    {[r.region, r.country].filter(Boolean).join(", ")}
                  </div>
                </div>
              </div>
              <Button size="sm" variant="secondary" disabled={adding !== null} onClick={() => handleAdd(r)}>
                {adding === r.lat + r.lon ? "…" : <><Plus size={14} /> Add</>}
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
