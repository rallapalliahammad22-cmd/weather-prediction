import React from "react";
import { cn } from "@/lib/utils";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger" | "ghost";
  size?: "sm" | "md" | "lg";
}

export const Button: React.FC<ButtonProps> = ({
  variant = "primary", size = "md", className, ...rest
}) => {
  const variantClass = {
    primary:   "bg-brand-600 text-white hover:bg-brand-700",
    secondary: "bg-white border border-slate-200 text-slate-700 hover:bg-slate-50",
    danger:    "bg-red-50 border border-red-200 text-red-700 hover:bg-red-100",
    ghost:     "text-slate-700 hover:bg-slate-100",
  }[variant];
  const sizeClass = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-5 py-2.5 text-base",
  }[size];
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
        variantClass, sizeClass, className
      )}
    />
  );
};
