import React, { useState, useRef, useEffect } from "react";
import { ChevronDown, MapPin, Check } from "lucide-react";
import { useActiveLocation } from "@/hooks/use-active-location";
import { cn } from "@/lib/utils";

export const LocationPicker: React.FC<{ className?: string }> = ({ className }) => {
  const { locations, active, setActive } = useActiveLocation();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  if (!active) return <div className="text-sm text-slate-400">No location selected</div>;

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        onClick={() => setOpen(!open)}
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-sm font-medium"
      >
        <MapPin size={14} className="text-slate-500" />
        <span className="text-slate-900">{active.name}</span>
        <span className="text-slate-500">, {active.country}</span>
        <ChevronDown size={14} className="text-slate-400 ml-1" />
      </button>
      {open && (
        <div className="absolute right-0 mt-1 w-72 bg-white rounded-lg border border-slate-200 shadow-lg z-30 max-h-80 overflow-y-auto">
          {locations.length === 0 ? (
            <div className="p-4 text-sm text-slate-500">No locations saved</div>
          ) : locations.map((l) => (
            <button
              key={l.id}
              onClick={() => { setActive(l.id); setOpen(false); }}
              className={cn(
                "w-full flex items-center justify-between p-3 hover:bg-slate-50 border-b border-slate-100 last:border-b-0 text-left",
                l.id === active.id && "bg-brand-50"
              )}
            >
              <div className="min-w-0">
                <div className="font-medium text-slate-900 truncate">{l.name}</div>
                <div className="text-xs text-slate-500 truncate">{[l.region, l.country].filter(Boolean).join(", ")}</div>
              </div>
              {l.id === active.id && <Check size={16} className="text-brand-600" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
