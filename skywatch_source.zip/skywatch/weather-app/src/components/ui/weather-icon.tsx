import React from "react";
import type { WeatherCondition } from "@/lib/types";
import {
  Sun, Cloud, CloudRain, CloudDrizzle, CloudLightning, CloudFog, Wind, Thermometer,
} from "lucide-react";

interface IconProps { condition: WeatherCondition; size?: number; className?: string; }

export const WeatherIcon: React.FC<IconProps> = ({ condition, size = 64, className }) => {
  const props = { size, className, strokeWidth: 1.5 };
  switch (condition) {
    case "Clear":         return <Sun {...props} className={`text-amber-400 ${className || ""}`} />;
    case "Partly Cloudy": return <Cloud {...props} className={`text-slate-400 ${className || ""}`} />;
    case "Cloudy":        return <Cloud {...props} className={`text-slate-500 ${className || ""}`} />;
    case "Overcast":      return <Cloud {...props} className={`text-slate-600 ${className || ""}`} />;
    case "Light Rain":    return <CloudDrizzle {...props} className={`text-brand-500 ${className || ""}`} />;
    case "Rain":          return <CloudRain {...props} className={`text-brand-500 ${className || ""}`} />;
    case "Heavy Rain":    return <CloudRain {...props} className={`text-brand-700 ${className || ""}`} />;
    case "Thunderstorm":  return <CloudLightning {...props} className={`text-purple-600 ${className || ""}`} />;
    case "Fog":           return <CloudFog {...props} className={`text-slate-400 ${className || ""}`} />;
    case "Windy":         return <Wind {...props} className={`text-teal-500 ${className || ""}`} />;
    case "Hot":           return <Thermometer {...props} className={`text-red-500 ${className || ""}`} />;
    default:              return <Cloud {...props} className="text-slate-400" />;
  }
};
