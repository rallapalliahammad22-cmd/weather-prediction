import React, { useState } from "react";
import { LogIn, UserPlus, Mail, Lock, Phone, User as UserIcon } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface Props { open: boolean; onClose: () => void; }

export const AuthDialog: React.FC<Props> = ({ open, onClose }) => {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setErr(null);
    try {
      if (mode === "signin") await signIn(email, password);
      else await signUp(email, password, phone || undefined, name || undefined);
      onClose();
    } catch (e: any) { setErr(e.message); }
    finally { setBusy(false); }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2">
          {mode === "signin" ? <LogIn size={20} className="text-brand-600" /> : <UserPlus size={20} className="text-brand-600" />}
          <span>{mode === "signin" ? "Sign in to SkyWatch" : "Create your SkyWatch account"}</span>
        </div>
      }
    >
      <p className="text-sm text-slate-500 mb-4">
        {mode === "signin"
          ? "Welcome back. Sign in to sync your locations across devices."
          : "An account is optional. Create one only if you want to sync your data."}
      </p>
      <form onSubmit={submit} className="space-y-3">
        {mode === "signup" && (
          <div>
            <label className="text-xs font-medium text-slate-600">Display name</label>
            <div className="relative mt-1">
              <UserIcon size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input value={name} onChange={e => setName(e.target.value)} className="input pl-8" placeholder="Your name" />
            </div>
          </div>
        )}
        <div>
          <label className="text-xs font-medium text-slate-600">Email</label>
          <div className="relative mt-1">
            <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="input pl-8" placeholder="you@example.com" />
          </div>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-600">Password</label>
          <div className="relative mt-1">
            <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)} className="input pl-8" placeholder="At least 6 characters" />
          </div>
        </div>
        {mode === "signup" && (
          <div>
            <label className="text-xs font-medium text-slate-600">Phone (optional, for SMS alerts)</label>
            <div className="relative mt-1">
              <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="input pl-8" placeholder="+91 9876543210" />
            </div>
          </div>
        )}
        {err && <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md p-2">{err}</div>}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
        </Button>
      </form>
      <div className="text-center text-sm text-slate-500 mt-4">
        {mode === "signin" ? (
          <>New here? <button className="text-brand-600 font-medium" onClick={() => setMode("signup")}>Create an account</button></>
        ) : (
          <>Already have an account? <button className="text-brand-600 font-medium" onClick={() => setMode("signin")}>Sign in</button></>
        )}
      </div>
    </Dialog>
  );
};
