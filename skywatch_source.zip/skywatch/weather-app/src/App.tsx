import React from "react";
import { Routes, Route } from "react-router-dom";
import { Layout } from "@/components/layout";
import { DashboardPage } from "@/pages/dashboard";
import { ForecastPage } from "@/pages/forecast";
import { AlertsPage } from "@/pages/alerts";
import { HistoricalPage } from "@/pages/historical";
import { LocationsPage } from "@/pages/locations";
import { AuthProvider } from "@/hooks/use-auth";
import { ActiveLocationProvider } from "@/hooks/use-active-location";
import { ErrorBoundary } from "@/components/error-boundary";

export default function App() {
  return (
    <AuthProvider>
      <ActiveLocationProvider>
        <ErrorBoundary>
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/forecast" element={<ForecastPage />} />
              <Route path="/alerts" element={<AlertsPage />} />
              <Route path="/historical" element={<HistoricalPage />} />
              <Route path="/locations" element={<LocationsPage />} />
            </Route>
          </Routes>
        </ErrorBoundary>
      </ActiveLocationProvider>
    </AuthProvider>
  );
}
