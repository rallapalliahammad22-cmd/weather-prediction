/**
 * Tiny fetch wrapper that auto-attaches the JWT (if any) and the
 * anonymous browser ID (if any) to every request.
 */

const TOKEN_KEY = "skywatch.token";
const ANON_KEY = "skywatch.anonId";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(t: string | null) {
  if (t) localStorage.setItem(TOKEN_KEY, t);
  else localStorage.removeItem(TOKEN_KEY);
}

export function getAnonymousId(): string {
  let id = localStorage.getItem(ANON_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(ANON_KEY, id);
  }
  return id;
}

interface ApiOpts extends RequestInit {
  json?: unknown;
  noAuthRedirect?: boolean;
}

export async function api<T = any>(path: string, opts: ApiOpts = {}): Promise<T> {
  const headers = new Headers(opts.headers);
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  headers.set("x-anonymous-id", getAnonymousId());
  if (opts.json !== undefined) {
    headers.set("Content-Type", "application/json");
  }

  const res = await fetch(path, {
    ...opts,
    headers,
    body: opts.json !== undefined ? JSON.stringify(opts.json) : opts.body,
  });

  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try { const j = await res.json(); msg = j.error || msg; } catch {}
    throw new Error(msg);
  }
  return res.json();
}

// Convenience helpers
export const get  = <T = any>(path: string)                    => api<T>(path);
export const post = <T = any>(path: string, json?: unknown)    => api<T>(path, { method: "POST", json });
export const patch= <T = any>(path: string, json?: unknown)    => api<T>(path, { method: "PATCH", json });
export const del  = <T = any>(path: string)                    => api<T>(path, { method: "DELETE" });
