import { format } from "date-fns";

export function fmtDate(iso: string | Date, fmt = "EEE, MMM d") {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return format(d, fmt);
}

export function fmtDayShort(iso: string) {
  // "Sat" "Sun" with day-of-month on second line
  const d = new Date(iso);
  return {
    weekday: format(d, "EEE"),
    day: format(d, "d"),
  };
}

export function conditionEmoji(c: string): string {
  switch (c) {
    case "Clear":         return "☀️";
    case "Partly Cloudy": return "⛅";
    case "Cloudy":        return "☁️";
    case "Overcast":      return "☁️";
    case "Light Rain":    return "🌦️";
    case "Rain":          return "🌧️";
    case "Heavy Rain":    return "🌧️";
    case "Thunderstorm":  return "⛈️";
    case "Fog":           return "🌫️";
    case "Windy":         return "💨";
    case "Hot":           return "🔥";
    default:              return "☁️";
  }
}

export function severityColor(s: string): string {
  switch (s) {
    case "info":     return "bg-blue-100 text-blue-800 border-blue-200";
    case "moderate": return "bg-amber-100 text-amber-800 border-amber-200";
    case "high":     return "bg-red-100 text-red-800 border-red-200";
    case "extreme":  return "bg-purple-100 text-purple-800 border-purple-200";
    default:         return "bg-slate-100 text-slate-800 border-slate-200";
  }
}

export function cn(...args: (string | false | null | undefined)[]) {
  return args.filter(Boolean).join(" ");
}
