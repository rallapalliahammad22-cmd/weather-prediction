// Shared type definitions matching the backend response shapes.

export type WeatherCondition =
  | "Clear" | "Partly Cloudy" | "Cloudy" | "Overcast"
  | "Light Rain" | "Rain" | "Heavy Rain" | "Thunderstorm"
  | "Fog" | "Windy" | "Hot";

export interface HourlyWeather {
  hour: number;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  windDir: number;
  precipitation: number;
  precipitationProb: number;
  uvIndex: number;
  visibility: number;
  condition: WeatherCondition;
  cloudCover: number;
}

export interface DailyWeather {
  date: string;
  tempHigh: number;
  tempLow: number;
  tempAvg: number;
  feelsLikeHigh: number;
  feelsLikeLow: number;
  humidity: number;
  windSpeed: number;
  windGust: number;
  precipitation: number;
  precipitationProb: number;
  uvIndex: number;
  visibility: number;
  sunrise: string;
  sunset: string;
  condition: WeatherCondition;
  description: string;
  hourly: HourlyWeather[];
}

export interface CurrentWeather {
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  windDir: number;
  uvIndex: number;
  visibility: number;
  pressure: number;
  condition: WeatherCondition;
  description: string;
  isDay: boolean;
  observedAt: string;
}

export interface ClimateNormals {
  location: { lat: number; lon: number };
  monthlyHighs: number[];
  monthlyLows: number[];
  monthlyAvgTemps: number[];
  monthlyRain: number[];
  monthlyRainDays: number[];
  monthlySunshineHours: number[];
  yearlyAvgTemps: number[];
  yearlyRainfall: number[];
  yearlyExtremeHeatDays: number[];
  yearlyHeavyRainDays: number[];
  annualAvgTemp: number;
  annualRainfall: number;
  annualAvgHigh: number;
  annualAvgLow: number;
  annualRainyDays: number;
  annualSunshineHours: number;
  dataSpanYears: number;
  dataRange: { from: number; to: number };
  extremes: {
    hottestMonth: string;
    hottestMonthTemp: number;
    coldestMonth: string;
    coldestMonthTemp: number;
    wettestMonth: string;
    wettestMonthRain: number;
  };
  bestMonths: { month: string; score: number; reason: string }[];
  rainySeason: { start: string; end: string; months: string[] };
  insights: {
    extremeHeatDaysPerYear: number;
    heavyRainDaysPerYear: number;
    thunderstormDaysPerYear: number;
    sunnyDaysPerYear: number;
    comfortDaysPerYear: number;
    temperatureRangeC: number;
    warmingTrend: number;
  };
}

export interface LocationRow {
  id: number;
  user_id: number | null;
  anonymous_id: string | null;
  name: string;
  country: string | null;
  region: string | null;
  latitude: number;
  longitude: number;
  timezone: string | null;
  is_active: number;
  created_at: string;
}

export type AlertSeverity = "info" | "moderate" | "high" | "extreme";

export interface AlertRow {
  id: number;
  location_id: number;
  location_name: string;
  type: string;
  severity: AlertSeverity;
  title: string;
  message: string;
  forecast_day: string;
  metadata: any;
  acknowledged: number;
  created_at: string;
}
