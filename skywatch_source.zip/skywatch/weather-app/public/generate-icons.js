// Generates PNG icons for the PWA from the SVG sources.
// Run with:  node public/generate-icons.js
// Requires:  npm i -D sharp
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function main() {
  let sharp;
  try {
    sharp = (await import("sharp")).default;
  } catch {
    console.error("Please run: npm i -D sharp");
    process.exit(1);
  }

  const sources = [
    { svg: "icon-192.svg", png: "icon-192.png", size: 192 },
    { svg: "icon-512.svg", png: "icon-512.png", size: 512 },
    { svg: "favicon.svg", png: "favicon.ico", size: 64 },
  ];

  for (const { svg, png, size } of sources) {
    const svgPath = path.join(__dirname, svg);
    const pngPath = path.join(__dirname, png);
    if (!fs.existsSync(svgPath)) {
      console.warn("Missing", svg);
      continue;
    }
    const svgBuf = fs.readFileSync(svgPath);
    await sharp(svgBuf).resize(size, size).png().toFile(pngPath);
    console.log("Wrote", png, "(" + size + "px)");
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
