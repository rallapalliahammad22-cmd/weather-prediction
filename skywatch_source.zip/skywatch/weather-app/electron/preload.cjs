const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("skywatch", {
  platform: process.platform,
  isElectron: true,
  versions: {
    node: process.versions.node,
    chrome: process.versions.chrome,
    electron: process.versions.electron,
  },
  // IPC bridge for native notifications
  notify: (title, body) => ipcRenderer.invoke("notify", { title, body }),
});
