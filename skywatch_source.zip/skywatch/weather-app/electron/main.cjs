const { app, BrowserWindow, shell, Menu, Tray, nativeImage } = require("electron");
const path = require("path");
const { spawn } = require("child_process");
const http = require("http");

// Suppress EPIPE errors when child process pipes close unexpectedly
process.stdout.on("error", (e) => {
  if (e.code !== "EPIPE") console.error(e);
});
process.stderr.on("error", (e) => {
  if (e.code !== "EPIPE") console.error(e);
});

let mainWindow;
let tray;
let backendProcess;

const isDev = process.env.NODE_ENV === "development" || !app.isPackaged;
const BACKEND_PORT = 4321;
const FRONTEND_URL = isDev
  ? "http://localhost:5173"
  : `http://localhost:${BACKEND_PORT}`;   // <-- load from backend (it serves the dist)

// Wait for backend to be ready
function waitForBackend(url, timeoutMs = 30000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const check = () => {
      http
        .get(url, (res) => {
          if (res.statusCode === 200 || res.statusCode === 304) resolve();
          else retry();
        })
        .on("error", retry);
    };
    const retry = () => {
      if (Date.now() - start > timeoutMs)
        reject(new Error("Backend did not start in time"));
      else setTimeout(check, 500);
    };
    check();
  });
}

// Find the bundled api-server dist/index.js
function getBackendPath() {
  if (isDev) {
    // Use TypeScript source via tsx
    return path.join(__dirname, "..", "..", "api-server", "src", "index.ts");
  }
  // Production: bundled by electron-builder into resources/api-server/
  const fs = require("fs");
  const candidates = [
    path.join(process.resourcesPath, "api-server", "dist", "src", "index.js"),
    path.join(process.resourcesPath, "api-server", "dist", "index.js"),
    path.join(process.resourcesPath, "api-server", "index.js"),
    path.join(process.resourcesPath, "api-server", "src", "index.js"),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      console.log("[electron] Found backend at:", p);
      return p;
    }
  }

  // If not found in candidates, search recursively inside resources/api-server
  try {
    const apiServerDir = path.join(process.resourcesPath, "api-server");
    if (fs.existsSync(apiServerDir)) {
      const findIndexJs = (dir) => {
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        for (const e of entries) {
          const fullPath = path.join(dir, e.name);
          if (e.isDirectory() && e.name !== "node_modules" && e.name !== "frontend" && e.name !== "db") {
            const found = findIndexJs(fullPath);
            if (found) return found;
          } else if (e.isFile() && e.name === "index.js") {
            return fullPath;
          }
        }
        return null;
      };
      const found = findIndexJs(apiServerDir);
      if (found) {
        console.log("[electron] Found backend via recursive search at:", found);
        return found;
      }
    }
  } catch (e) {
    console.error("[electron] Recursive search error:", e);
  }

  // Fallback - return the top candidate and let it fail with a clear error
  console.error("[electron] Could not find bundled api-server. Checked:");
  candidates.forEach((p) => console.error("  -", p));
  return candidates[0];
}

async function startBackend() {
  if (isDev) return; // Use dev backend on http://localhost:4000

  const backendPath = getBackendPath();
  console.log("[electron] Starting backend from:", backendPath);

  // IMPORTANT: process.execPath in Electron is Electron itself, NOT node.
  // Setting ELECTRON_RUN_AS_NODE=1 makes the spawned process run as plain Node.js.
  const node = process.execPath;
  const userDataPath = app.getPath("userData");
  const dbPath = path.join(userDataPath, "skywatch.db");

  backendProcess = spawn(node, [backendPath], {
    cwd: path.dirname(backendPath),
    env: {
      ...process.env,
      PORT: BACKEND_PORT,
      NODE_ENV: "production",
      ELECTRON_RUN_AS_NODE: "1",
      DB_PATH: dbPath,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });

  backendProcess.stdout.on("data", (d) =>
    console.log("[backend]", d.toString().trim())
  );
  backendProcess.stderr.on("data", (d) =>
    console.error("[backend]", d.toString().trim())
  );
  backendProcess.on("exit", (code) =>
    console.log("[backend] exited with code", code)
  );
  backendProcess.on("error", (e) =>
    console.error("[backend] failed to start:", e)
  );
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 700,
    icon: path.join(__dirname, "..", "public", "icon-512.png"),
    backgroundColor: "#0f172a",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      nodeIntegration: false,
      contextIsolation: true,
      // Don't allow service worker to interfere in Electron
    },
    show: false,
  });

  // Show when ready
  mainWindow.once("ready-to-show", () => mainWindow.show());

  // Disable PWA service worker in Electron (causes continuous reload issues)
  mainWindow.webContents.on("dom-ready", () => {
    mainWindow.webContents
      .executeJavaScript(
        `if ('serviceWorker' in navigator) {
           navigator.serviceWorker.getRegistrations().then(regs => {
             regs.forEach(r => r.unregister());
           });
         }`
      )
      .catch(() => {});
  });

  // Load URL
  if (isDev) {
    mainWindow.loadURL("http://localhost:5173");
    mainWindow.webContents.openDevTools({ mode: "detach" });
  } else {
    // Production: backend serves the React dist on the same port
    mainWindow.loadURL(FRONTEND_URL);
  }

  // External links in default browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    const isExternalHttp = (url.startsWith("http://") || url.startsWith("https://")) &&
      !url.includes("localhost") && !url.includes("127.0.0.1");
    if (isExternalHttp) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  // Prevent navigation away from app
  mainWindow.webContents.on("will-navigate", (event, url) => {
    const isLocal = url.startsWith(FRONTEND_URL) || url.startsWith("http://localhost") || url.startsWith("http://127.0.0.1") || url.startsWith("file://");
    if (!isLocal) {
      event.preventDefault();
      const isExternalHttp = (url.startsWith("http://") || url.startsWith("https://")) &&
        !url.includes("localhost") && !url.includes("127.0.0.1");
      if (isExternalHttp) {
        shell.openExternal(url);
      }
    }
  });

  // Handle load errors gracefully instead of showing chrome-error screen
  mainWindow.webContents.on("did-fail-load", (_event, errorCode, errorDescription, validatedURL) => {
    console.error(`[electron] Failed to load ${validatedURL}: ${errorDescription} (${errorCode})`);
    if (validatedURL.includes("localhost") && errorCode === -102) { // ERR_CONNECTION_REFUSED
      setTimeout(() => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          console.log("[electron] Retrying connection to backend...");
          mainWindow.loadURL(FRONTEND_URL).catch(() => {});
        }
      }, 1000);
    }
  });

  // Hide menu bar (we have a tray icon)
  Menu.setApplicationMenu(null);
}

function createTray() {
  const iconPath = path.join(__dirname, "..", "public", "icon-512.png");
  const icon = nativeImage.createFromPath(iconPath);
  tray = new Tray(icon);
  tray.setToolTip("SkyWatch - Weather Forecast");
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: "Open SkyWatch", click: () => mainWindow?.show() },
      { label: "Refresh", click: () => mainWindow?.webContents.reload() },
      { type: "separator" },
      { label: "Quit", click: () => app.quit() },
    ])
  );
  tray.on("click", () => mainWindow?.show());
}

app.whenReady().then(async () => {
  if (!isDev) {
    await startBackend();
    try {
      await waitForBackend(`http://localhost:${BACKEND_PORT}/api/health`);
      console.log("[electron] Backend is ready!");
    } catch (e) {
      console.error("[electron] Backend startup failed:", e);
    }
  }
  createWindow();
  createTray();
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

app.on("before-quit", () => {
  if (backendProcess) backendProcess.kill();
});
