#!/usr/bin/env bash
# SkyWatch Desktop Build Script (macOS / Linux)
set -e
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "☁  Building SkyWatch Desktop App"
echo ""

# Step 0: Build API server (needed for Electron production)
echo "[0/5] Building api-server (TypeScript -> JS)..."
cd "$ROOT_DIR/api-server"
if [ ! -d "node_modules" ]; then npm install; fi
npm run build

# Step 1: Generate icons
echo ""
echo "[1/5] Generating PNG icons from SVG..."
cd "$ROOT_DIR/weather-app"
if [ ! -d "node_modules" ]; then npm install; fi
if [ -f "public/icon-192.svg" ]; then
    node public/generate-icons.js || echo "⚠ Icon generation failed (sharp not installed)"
fi

# Step 2: Build frontend
echo ""
echo "[2/5] Building frontend (Vite)..."
npm run build

# Step 3: Verify electron
echo ""
echo "[3/5] Verifying electron + electron-builder..."
if [ ! -d "node_modules/electron-builder" ]; then
    npm install --save-dev electron electron-builder
fi

# Step 4: Copy api-server dist into Electron resources
echo ""
echo "[4/5] Copying api-server bundle into Electron resources..."
API_DEST="$ROOT_DIR/weather-app/build/api-server"
rm -rf "$API_DEST" && mkdir -p "$API_DEST"
cp -r "$ROOT_DIR/api-server/dist" "$API_DEST/dist"
if [ -f "$API_DEST/dist/src/index.js" ] && [ ! -f "$API_DEST/dist/index.js" ]; then
    cp "$API_DEST/dist/src/index.js" "$API_DEST/dist/index.js"
fi
if [ -d "$ROOT_DIR/api-server/db" ]; then cp -r "$ROOT_DIR/api-server/db" "$API_DEST/db"; fi
if [ -f "$ROOT_DIR/api-server/package.json" ]; then cp "$ROOT_DIR/api-server/package.json" "$API_DEST/package.json"; fi
if [ -f "$ROOT_DIR/api-server/.env" ]; then cp "$ROOT_DIR/api-server/.env" "$API_DEST/.env"; fi
if [ -d "$ROOT_DIR/api-server/node_modules" ]; then
    echo "  Copying api-server production node_modules..."
    cp -r "$ROOT_DIR/api-server/node_modules" "$API_DEST/node_modules"
fi
if [ -d "$ROOT_DIR/weather-app/dist" ]; then
    echo "  Copying frontend dist into api-server/frontend..."
    cp -r "$ROOT_DIR/weather-app/dist" "$API_DEST/frontend"
fi

# Step 5: Build for current platform
echo ""
echo "[5/5] Building desktop installer..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    npm run electron:mac
    echo "→ Output: weather-app/release/SkyWatch-*.dmg"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    npm run electron:linux
    echo "→ Output: weather-app/release/SkyWatch-*.AppImage"
else
    echo "Unknown platform: $OSTYPE — try: npm run electron:win"
fi

echo ""
echo "✅ Done!"
