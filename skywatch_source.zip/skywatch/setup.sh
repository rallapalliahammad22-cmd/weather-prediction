#!/usr/bin/env bash
# SkyWatch setup script — installs dependencies for both api-server and weather-app.
set -e
cd "$(dirname "$0")"

echo "☁  SkyWatch setup"
echo ""

echo "[1/2] Installing api-server…"
( cd api-server && npm install )
echo ""

echo "[2/2] Installing weather-app…"
( cd weather-app && npm install )
echo ""

echo "✅ Done. To start the app:"
echo ""
echo "   Terminal 1:  cd api-server  &&  npm run dev"
echo "   Terminal 2:  cd weather-app &&  npm run dev"
echo ""
echo "Then open http://localhost:5173 in your browser."
