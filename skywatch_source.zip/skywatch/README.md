# SkyWatch — 14-Day Weather Forecast App

SkyWatch is a full-stack weather prediction app that forecasts **14 days** of weather based on **5 years** of historical analysis. Now deployable as:

- 🌐 **Web app** (PWA — installable on any device)
- 🖥️ **Desktop app** (Windows / macOS / Linux via Electron)
- 📱 **Mobile app** (Android / iOS via Capacitor)

## Features

- 🌤 Current weather for any city (3,400+ locations)
- 📅 14-day forecast powered by 5-year historical analysis
- ⏱ Hourly forecast + 24-hour temperature chart
- 📊 Historical climate normals with monthly temperature/rainfall charts
- 🌍 Multiple locations with search and quick switch
- 🚨 Automatic alerts (heavy rain, extreme heat, temperature swings)
- 📬 Multi-channel notifications (Email, SMS, Web Push, In-app)
- 🔓 Login is optional — works fully without account
- 📱 **PWA** — install on phone/desktop from browser
- 🖥️ **Electron** — native desktop app
- 📲 **Capacitor** — native Android/iOS apps

## 🏗️ Architecture

```
skywatch/
├── api-server/                  Node.js + Express + SQLite backend
│   ├── src/
│   │   ├── lib/                  weather engine, alerts, auth, notifications
│   │   ├── routes/               REST API endpoints
│   │   ├── jobs/                 cron alert checker
│   │   └── index.ts              Express bootstrap
│   ├── db/schema/                SQL tables
│   └── package.json
│
├── weather-app/                 React + Vite + TypeScript frontend
│   ├── src/
│   │   ├── hooks/                use-auth, use-active-location
│   │   ├── components/           layout, dialogs, UI primitives
│   │   ├── pages/                dashboard, forecast, alerts, historical, locations
│   │   └── App.tsx
│   ├── public/
│   │   ├── manifest.json         PWA manifest
│   │   ├── sw.js                 Service worker
│   │   ├── icon-192.svg/.png     PWA icons
│   │   └── icon-512.svg/.png     PWA icons
│   ├── electron/
│   │   ├── main.js               Electron main process
│   │   └── preload.js            Secure preload bridge
│   ├── capacitor.config.json     Mobile app config
│   └── package.json              With all build scripts
│
├── build-desktop.sh / .ps1      Desktop build scripts
├── build-mobile.ps1              Mobile build script
├── setup.sh / setup.ps1          Initial setup
└── README.md
```

## 🚀 Quick Start (Web)

```bash
# One-time setup
./setup.sh             # or setup.ps1 on Windows

# Start backend
cd api-server && npm run dev

# Start frontend (new terminal)
cd weather-app && npm run dev

# Open http://localhost:5173
```

## 📱 Build Mobile App (Android/iOS)

```bash
# Install Capacitor
cd weather-app
npm install --save-dev @capacitor/cli @capacitor/core @capacitor/android @capacitor/ios

# Build the web app + add Android platform
npm run cap:add:android

# Open in Android Studio
npm run cap:open:android

# Or build APK from CLI
npm run cap:build:android
# Output: weather-app/android/app/build/outputs/apk/debug/app-debug.apk
```

For iOS (Mac only):
```bash
npm run cap:add:ios
npm run cap:open:ios
```

## 🖥️ Build Desktop App (Windows / Mac / Linux)

```bash
cd weather-app
npm install --save-dev electron electron-builder

# Generate PNG icons from SVG
npm run icons

# Build for Windows (from Windows)
npm run electron:win
# Output: weather-app/release/SkyWatch Setup 1.0.0.exe

# Build for macOS (from Mac)
npm run electron:mac
# Output: weather-app/release/SkyWatch-1.0.0.dmg

# Build for Linux (from Linux)
npm run electron:linux
# Output: weather-app/release/SkyWatch-1.0.0.AppImage
```

Or use the convenience scripts:
```bash
# macOS / Linux
./build-desktop.sh

# Windows (PowerShell)
.\build-desktop.ps1
```

## 🌐 PWA (Install from browser)

SkyWatch is a **Progressive Web App**. After visiting http://localhost:5173 in Chrome/Edge:
- Click the **install icon** (⊕) in the address bar
- Or use **Add to Home Screen** on mobile

Works **offline** thanks to the service worker.

## 📊 Coverage

- 🇮🇳 **India**: 3,200+ cities including all mandals, villages, gram panchayats
- 🌍 **International**: 200+ cities across 6 continents
- 🌦️ **Climate zones**: Tropical, subtropical, temperate, boreal, polar

## 🔧 Tech Stack

**Frontend**: React 18, Vite, TypeScript, TailwindCSS, Recharts, React Router, Lucide
**Backend**: Node.js, Express, sql.js (pure JS SQLite), Zod, Nodemailer, Twilio, web-push
**PWA**: Service Worker, Web App Manifest, IndexedDB cache
**Desktop**: Electron 33, electron-builder
**Mobile**: Capacitor 6
