# SkyWatch Desktop Build Script (Windows)
# Builds SkyWatch as a Windows .exe installer

$ErrorActionPreference = "Stop"

Write-Host "☁  Building SkyWatch Desktop App" -ForegroundColor Cyan
Write-Host ""

# Step 0: Build API server (needed for Electron production)
Write-Host "[0/5] Building api-server (TypeScript -> JS)..." -ForegroundColor Yellow
Set-Location "$PSScriptRoot\api-server"
if (-not (Test-Path "node_modules")) { npm install }
npm run build
if ($LASTEXITCODE -ne 0) { Write-Host "❌ api-server build failed" -ForegroundColor Red; exit 1 }

# Step 1: Generate icons for frontend
Write-Host ""
Write-Host "[1/5] Generating PNG icons for frontend..." -ForegroundColor Yellow
Set-Location "$PSScriptRoot\weather-app"
if (-not (Test-Path "node_modules")) { npm install }
if (Test-Path "public\generate-icons.js") {
    try { node public\generate-icons.js }
    catch { Write-Host "⚠ Icon generation failed (run: npm install sharp)" -ForegroundColor Yellow }
}

# Step 2: Build frontend
Write-Host ""
Write-Host "[2/5] Building frontend (Vite)..." -ForegroundColor Yellow
npm run build
if ($LASTEXITCODE -ne 0) { Write-Host "❌ frontend build failed" -ForegroundColor Red; exit 1 }

# Step 3: Verify electron + electron-builder
Write-Host ""
Write-Host "[3/5] Verifying electron + electron-builder..." -ForegroundColor Yellow
if (-not (Test-Path "node_modules\electron-builder")) {
    Write-Host "Installing electron-builder..." -ForegroundColor Yellow
    npm install --save-dev electron electron-builder
}

# Step 4: Copy api-server dist into Electron resources
Write-Host ""
Write-Host "[4/5] Copying api-server bundle into Electron resources..." -ForegroundColor Yellow
$apiDest = "$PSScriptRoot\weather-app\build\api-server"
if (Test-Path $apiDest) { Remove-Item -Recurse -Force $apiDest }
New-Item -ItemType Directory -Path $apiDest -Force | Out-Null
Copy-Item -Recurse "$PSScriptRoot\api-server\dist" "$apiDest\dist"
# Ensure dist/index.js is available even if tsc outputted to dist/src/index.js
if (Test-Path "$apiDest\dist\src\index.js") {
    if (-not (Test-Path "$apiDest\dist\index.js")) {
        Copy-Item "$apiDest\dist\src\index.js" "$apiDest\dist\index.js"
    }
}
# Also copy the db folder if it exists (will hold skywatch.db)
if (Test-Path "$PSScriptRoot\api-server\db") {
    Copy-Item -Recurse "$PSScriptRoot\api-server\db" "$apiDest\db"
}
# Copy package.json (needed by sql.js & other deps)
if (Test-Path "$PSScriptRoot\api-server\package.json") {
    Copy-Item "$PSScriptRoot\api-server\package.json" "$apiDest\package.json"
}
# Copy .env if it exists (optional)
if (Test-Path "$PSScriptRoot\api-server\.env") {
    Copy-Item "$PSScriptRoot\api-server\.env" "$apiDest\.env"
}
# Copy node_modules (production deps only) - needed for runtime imports
if (Test-Path "$PSScriptRoot\api-server\node_modules") {
    Write-Host "  Copying api-server production node_modules..." -ForegroundColor Yellow
    Copy-Item -Recurse "$PSScriptRoot\api-server\node_modules" "$apiDest\node_modules"
}
# Copy frontend dist into api-server bundle so backend can serve it on port 4321
if (Test-Path "$PSScriptRoot\weather-app\dist") {
    Write-Host "  Copying frontend dist into api-server/frontend..." -ForegroundColor Yellow
    Copy-Item -Recurse "$PSScriptRoot\weather-app\dist" "$apiDest\frontend"
}

# Step 5: Build Windows installer
Write-Host ""
Write-Host "[5/5] Building Windows installer (.exe)..." -ForegroundColor Yellow
npm run electron:win

Write-Host ""
Write-Host "✅ Done!" -ForegroundColor Green
Write-Host "Installer is in:  weather-app\release\" -ForegroundColor Cyan
Write-Host "Find the .exe file and double-click to install SkyWatch!" -ForegroundColor Cyan
