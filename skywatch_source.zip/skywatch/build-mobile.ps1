# SkyWatch Mobile Build Script (Android / iOS)
# Builds SkyWatch as a native mobile app

$ErrorActionPreference = "Stop"
Set-Location "$PSScriptRoot\weather-app"

Write-Host "☁  Building SkyWatch Mobile App" -ForegroundColor Cyan
Write-Host ""

# Step 1: Build frontend
Write-Host "[1/5] Building frontend (Vite)..." -ForegroundColor Yellow
npm run build

# Step 2: Verify Capacitor is installed
Write-Host ""
Write-Host "[2/5] Verifying Capacitor..." -ForegroundColor Yellow
if (-not (Test-Path "node_modules\@capacitor\cli")) {
    Write-Host "Installing Capacitor..." -ForegroundColor Yellow
    npm install --save-dev @capacitor/cli @capacitor/core @capacitor/android @capacitor/ios @capacitor/splash-screen @capacitor/status-bar
}

# Step 3: Sync
Write-Host ""
Write-Host "[3/5] Syncing web build with Capacitor..." -ForegroundColor Yellow
npx cap sync

# Step 4: Add Android platform if missing
Write-Host ""
Write-Host "[4/5] Adding Android platform..." -ForegroundColor Yellow
if (-not (Test-Path "android")) {
    npx cap add android
}

# Step 5: Open in Android Studio (or build APK)
Write-Host ""
Write-Host "[5/5] Ready to build!" -ForegroundColor Yellow
Write-Host ""
Write-Host "Choose next step:" -ForegroundColor Cyan
Write-Host "  1) Open in Android Studio:  npx cap open android" -ForegroundColor White
Write-Host "  2) Build APK from CLI:        cd android && ./gradlew assembleDebug" -ForegroundColor White
Write-Host ""
Write-Host "APK will be at:  android\app\build\outputs\apk\debug\app-debug.apk" -ForegroundColor Cyan
Write-Host ""
Write-Host "For iOS (Mac only):  npx cap add ios && npx cap open ios" -ForegroundColor Cyan
