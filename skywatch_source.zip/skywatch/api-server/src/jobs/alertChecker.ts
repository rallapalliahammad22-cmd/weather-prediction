/**
 * Periodic job: every 30 minutes, regenerate alerts for all
 * active locations and dispatch notifications for any new ones.
 *
 * Runs in-process via node-cron. Replace with a dedicated worker
 * queue if you scale out.
 */

import cron from "node-cron";
import { db, dbReady } from "../lib/db.js";
import { get14DayForecast } from "../lib/weather.js";
import { generateAlerts } from "../lib/alerts.js";
import { sendAlertEmail } from "../lib/email.js";
import { sendAlertSms } from "../lib/sms.js";
import { sendAlertPush } from "../lib/push.js";

export function startAlertChecker() {
  // Every 30 minutes
  cron.schedule("*/30 * * * *", async () => {
    try { await runOnce(); }
    catch (err) { console.error("[alert-checker]", err); }
  });
  // Also run once on boot (after DB ready)
  dbReady().then(() => runOnce()).catch(err => console.error("[alert-checker] boot:", err));
}

async function runOnce() {
  const active = db.prepare(
    "SELECT * FROM locations WHERE is_active = 1"
  ).all() as any[];

  if (!active.length) {
    console.log("[alert-checker] no active locations");
    return;
  }
  console.log(`[alert-checker] checking ${active.length} active location(s)`);

  for (const loc of active) {
    const days = get14DayForecast(loc.latitude, loc.longitude);
    const alerts = generateAlerts(loc.id, days);

    // Only insert alerts for forecast days we haven't alerted about yet
    const existingDays = new Set(
      (db.prepare(
        "SELECT forecast_day FROM alerts WHERE location_id = ? AND forecast_day >= date('now')"
      ).all(loc.id) as any[]).map(r => r.forecast_day)
    );
    const newAlerts = alerts.filter(a => !existingDays.has(a.forecastDay));
    if (!newAlerts.length) continue;

    const insert = db.prepare(
      `INSERT INTO alerts (location_id, type, severity, title, message, forecast_day, metadata)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    );
    for (const a of newAlerts) {
      insert.run(loc.id, a.type, a.severity, a.title, a.message, a.forecastDay,
        a.metadata ? JSON.stringify(a.metadata) : null);
    }

    // Dispatch
    const ownerId = loc.user_id;
    const anonId = loc.anonymous_id;
    let prefs = { email: true, sms: false, push: true, inApp: true };
    let phone: string | null = null;
    let email: string | null = null;
    if (ownerId) {
      const u: any = db.prepare("SELECT email, phone, notification_prefs FROM users WHERE id = ?").get(ownerId);
      if (u) {
        email = u.email;
        phone = u.phone;
        try { prefs = { ...prefs, ...JSON.parse(u.notification_prefs) }; } catch {}
      }
    }

    for (const alert of newAlerts) {
      if (prefs.email && email) {
        const r = await sendAlertEmail(email, alert, loc.name);
        db.prepare(`INSERT INTO notification_log (alert_id, channel, recipient, status) VALUES (?, ?, ?, ?)`)
          .run(0, "email", email, r.ok ? "sent" : "failed");
      }
      if (prefs.sms && phone) {
        const r = await sendAlertSms(phone, alert, loc.name);
        db.prepare(`INSERT INTO notification_log (alert_id, channel, recipient, status) VALUES (?, ?, ?, ?)`)
          .run(0, "sms", phone, r.ok ? "sent" : "failed");
      }
      if (prefs.push) {
        await sendAlertPush({ userId: ownerId, anonymousId: anonId, alert, locationName: loc.name });
      }
    }

    console.log(`[alert-checker] ${loc.name}: ${newAlerts.length} new alert(s)`);
  }
}
