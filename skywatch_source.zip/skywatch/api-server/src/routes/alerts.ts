import { Router } from "express";
import { z } from "zod";
import { db } from "../lib/db.js";
import { attachUser } from "../lib/auth.js";
import { generateAlerts, type Alert } from "../lib/alerts.js";
import { get14DayForecast } from "../lib/weather.js";
import { sendAlertEmail } from "../lib/email.js";
import { sendAlertSms } from "../lib/sms.js";
import { sendAlertPush } from "../lib/push.js";

const router = Router();
router.use(attachUser);

function ownerClause(req: any) {
  if (req.user) return { sql: "user_id = ?", params: [req.user.uid] };
  const anon = req.header("x-anonymous-id");
  if (anon) return { sql: "anonymous_id = ?", params: [anon] };
  return null;
}

router.get("/", (req, res) => {
  const owner = ownerClause(req);
  if (!owner) return res.json({ alerts: [] });
  const rows = db.prepare(
    `SELECT a.*, l.name AS location_name FROM alerts a
     JOIN locations l ON a.location_id = l.id
     WHERE l.${owner.sql}
     ORDER BY a.created_at DESC, a.forecast_day ASC`
  ).all(...owner.params);
  res.json({
    alerts: rows.map((r: any) => ({ ...r, metadata: r.metadata ? JSON.parse(r.metadata) : null })),
  });
});

router.post("/generate", (req, res) => {
  const schema = z.object({
    locationId: z.number(),
    anonymousId: z.string().optional().nullable(),
  });
  const data = schema.parse(req.body);

  const owner = ownerClause(req);
  if (!owner) return res.status(400).json({ error: "Anonymous ID required" });

  const loc: any = db.prepare(
    `SELECT * FROM locations WHERE id = ? AND ${owner.sql}`
  ).get(data.locationId, ...owner.params);
  if (!loc) return res.status(404).json({ error: "Location not found" });

  const days = get14DayForecast(loc.latitude, loc.longitude);
  const alerts = generateAlerts(loc.id, days);

  // Clear existing open alerts for this location before inserting new ones.
  db.prepare("DELETE FROM alerts WHERE location_id = ?").run(loc.id);

  const insert = db.prepare(
    `INSERT INTO alerts (location_id, type, severity, title, message, forecast_day, metadata)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  const insertedIds: number[] = [];
  for (const a of alerts) {
    const r = insert.run(a.locationId, a.type, a.severity, a.title, a.message, a.forecastDay,
      a.metadata ? JSON.stringify(a.metadata) : null);
    insertedIds.push(Number(r.lastInsertRowid));
  }

  // Dispatch notifications (best-effort, don't block the response).
  dispatchNotifications(alerts, loc, req.user?.uid ?? null,
    req.user ? null : (data.anonymousId || req.header("x-anonymous-id") || null));

  res.json({ alerts, insertedIds });
});

router.post("/:id/acknowledge", (req, res) => {
  db.prepare("UPDATE alerts SET acknowledged = 1 WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

router.delete("/:id", (req, res) => {
  db.prepare("DELETE FROM alerts WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

async function dispatchNotifications(alerts: Alert[], location: any, userId: number | null, anonymousId: string | null) {
  if (!alerts.length) return;

  // Decide which channels to use based on user prefs OR anonymous enablement.
  let prefs = { email: true, sms: false, push: true, inApp: true };
  let phone: string | null = null;
  let email: string | null = null;

  if (userId) {
    const row: any = db.prepare("SELECT email, phone, notification_prefs FROM users WHERE id = ?").get(userId);
    if (row) {
      email = row.email;
      phone = row.phone;
      try { prefs = { ...prefs, ...JSON.parse(row.notification_prefs) }; } catch {}
    }
  }

  for (const alert of alerts) {
    // In-app: always store the alert (already done above).
    db.prepare(
      `INSERT INTO notification_log (alert_id, channel, recipient, status) VALUES (?, ?, ?, ?)`
    ).run(0, "inApp", null, "delivered"); // placeholder, ignore

    if (prefs.email && email) {
      const r = await sendAlertEmail(email, alert, location.name);
      db.prepare(
        `INSERT INTO notification_log (alert_id, channel, recipient, status, error) VALUES (?, ?, ?, ?, ?)`
      ).run(alert.locationId, "email", email, r.ok ? "sent" : "failed", r.error || null);
    }
    if (prefs.sms && phone) {
      const r = await sendAlertSms(phone, alert, location.name);
      db.prepare(
        `INSERT INTO notification_log (alert_id, channel, recipient, status, error) VALUES (?, ?, ?, ?, ?)`
      ).run(alert.locationId, "sms", phone, r.ok ? "sent" : "failed", r.error || null);
    }
    if (prefs.push) {
      const r = await sendAlertPush({ userId, anonymousId, alert, locationName: location.name });
      db.prepare(
        `INSERT INTO notification_log (alert_id, channel, recipient, status) VALUES (?, ?, ?, ?)`
      ).run(alert.locationId, "push", "subscribers", r.ok ? "sent" : "failed");
    }
  }
}

export default router;
