import { Router } from "express";
import { z } from "zod";
import {
  getCurrent, get14DayForecast, get7DayOutlook, getClimateNormals,
  getHistorical, searchLocation, resolveLocation,
} from "../lib/weather.js";

const router = Router();

const coordsSchema = z.object({
  lat: z.coerce.number(),
  lon: z.coerce.number(),
});

router.get("/current", (req, res) => {
  const { lat, lon } = coordsSchema.parse(req.query);
  res.json({ current: getCurrent(lat, lon) });
});

router.get("/forecast", (req, res) => {
  const { lat, lon } = coordsSchema.parse(req.query);
  res.json({ forecast: get14DayForecast(lat, lon) });
});

router.get("/outlook", (req, res) => {
  const { lat, lon } = coordsSchema.parse(req.query);
  res.json({ outlook: get7DayOutlook(lat, lon) });
});

router.get("/climate", (req, res) => {
  const { lat, lon } = coordsSchema.parse(req.query);
  res.json({ climate: getClimateNormals(lat, lon) });
});

const histSchema = z.object({
  lat: z.coerce.number(),
  lon: z.coerce.number(),
  from: z.string(),
  to: z.string(),
});
router.get("/historical", (req, res) => {
  const { lat, lon, from, to } = histSchema.parse(req.query);
  const days = getHistorical(lat, lon, new Date(from), new Date(to));
  res.json({ historical: days });
});

router.get("/search", (req, res) => {
  const q = String(req.query.q || "");
  res.json({ results: searchLocation(q) });
});

router.get("/resolve", (req, res) => {
  const q = String(req.query.q || "");
  res.json({ location: resolveLocation(q) });
});

export default router;
