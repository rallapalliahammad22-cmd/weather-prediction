import { Router } from "express";
import { z } from "zod";
import { db } from "../lib/db.js";
import { attachUser, requireAuth } from "../lib/auth.js";
import { searchLocation, resolveLocation, getCurrent, get14DayForecast, getClimateNormals } from "../lib/weather.js";
import { generateAlerts } from "../lib/alerts.js";

const router = Router();
router.use(attachUser);

router.get("/search", (req, res) => {
  const q = String(req.query.q || "");
  res.json({ results: searchLocation(q) });
});

const createSchema = z.object({
  name: z.string(),
  country: z.string().optional().nullable(),
  region: z.string().optional().nullable(),
  latitude: z.number(),
  longitude: z.number(),
  timezone: z.string().optional().nullable(),
  anonymousId: z.string().optional().nullable(),
  activate: z.boolean().optional(),
});

function ownerClause(req: any) {
  if (req.user) return { sql: "user_id = ?", params: [req.user.uid] };
  const anon = req.header("x-anonymous-id");
  if (anon) return { sql: "anonymous_id = ?", params: [anon] };
  return null;
}

router.get("/", (req, res) => {
  const owner = ownerClause(req);
  if (!owner) return res.json({ locations: [] });
  const rows = db.prepare(
    `SELECT * FROM locations WHERE ${owner.sql} ORDER BY is_active DESC, created_at DESC`
  ).all(...owner.params);
  res.json({ locations: rows });
});

router.post("/", (req, res) => {
  const data = createSchema.parse(req.body);
  const owner = ownerClause(req);
  if (!owner) return res.status(400).json({ error: "Anonymous ID required" });

  if (data.activate) {
    db.prepare(`UPDATE locations SET is_active = 0 WHERE ${owner.sql}`).run(...owner.params);
  }

  const userId = req.user?.uid ?? null;
  const anonId = req.user ? null : (data.anonymousId || req.header("x-anonymous-id"));
  const result = db.prepare(
    `INSERT INTO locations (user_id, anonymous_id, name, country, region, latitude, longitude, timezone, is_active)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    userId,
    anonId,
    data.name,
    data.country || null,
    data.region || null,
    data.latitude,
    data.longitude,
    data.timezone || null,
    data.activate ? 1 : 0
  );
  const row = db.prepare("SELECT * FROM locations WHERE id = ?").get(result.lastInsertRowid);
  res.json({ location: row });
});

router.post("/:id/activate", (req, res) => {
  const owner = ownerClause(req);
  if (!owner) return res.status(400).json({ error: "Anonymous ID required" });
  db.prepare(`UPDATE locations SET is_active = 0 WHERE ${owner.sql}`).run(...owner.params);
  db.prepare(`UPDATE locations SET is_active = 1 WHERE id = ? AND ${owner.sql}`).run(req.params.id, ...owner.params);
  res.json({ ok: true });
});

router.delete("/:id", (req, res) => {
  const owner = ownerClause(req);
  if (!owner) return res.status(400).json({ error: "Anonymous ID required" });
  db.prepare(`DELETE FROM locations WHERE id = ? AND ${owner.sql}`).run(req.params.id, ...owner.params);
  res.json({ ok: true });
});

router.get("/:id/snapshot", (req, res) => {
  const owner = ownerClause(req);
  if (!owner) return res.status(400).json({ error: "Anonymous ID required" });
  const row: any = db.prepare(
    `SELECT * FROM locations WHERE id = ? AND ${owner.sql}`
  ).get(req.params.id, ...owner.params);
  if (!row) return res.status(404).json({ error: "Location not found" });
  const lat = row.latitude, lon = row.longitude;
  const current = getCurrent(lat, lon);
  const forecast = get14DayForecast(lat, lon);
  const climate = getClimateNormals(lat, lon);
  const alerts = generateAlerts(row.id, forecast);
  res.json({
    location: row,
    current,
    forecast,
    climate,
    alerts,
  });
});

export default router;
