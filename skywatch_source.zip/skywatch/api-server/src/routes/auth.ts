import { Router } from "express";
import { z } from "zod";
import { login, register, attachUser, requireAuth } from "../lib/auth.js";
import { db } from "../lib/db.js";

const router = Router();
router.use(attachUser);

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  phone: z.string().optional(),
  displayName: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

router.post("/register", async (req, res) => {
  try {
    const data = registerSchema.parse(req.body);
    const token = await register(data.email, data.password, data.phone, data.displayName);
    res.json({ token });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/login", async (req, res) => {
  try {
    const data = loginSchema.parse(req.body);
    const token = await login(data.email, data.password);
    res.json({ token });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get("/me", requireAuth, (req: any, res) => {
  const row = db.prepare(
    "SELECT id, email, phone, display_name, notification_prefs, created_at FROM users WHERE id = ?"
  ).get(req.user.uid);
  if (!row) return res.status(404).json({ error: "User not found" });
  res.json({
    id: row.id,
    email: row.email,
    phone: row.phone,
    displayName: row.display_name,
    notificationPrefs: JSON.parse(row.notification_prefs),
    createdAt: row.created_at,
  });
});

router.patch("/me", requireAuth, (req: any, res) => {
  const schema = z.object({
    phone: z.string().optional().nullable(),
    displayName: z.string().optional().nullable(),
    notificationPrefs: z.object({
      email: z.boolean().optional(),
      sms: z.boolean().optional(),
      push: z.boolean().optional(),
      inApp: z.boolean().optional(),
    }).optional(),
  });
  const data = schema.parse(req.body);
  const fields: string[] = [];
  const params: any[] = [];
  if (data.phone !== undefined)        { fields.push("phone = ?");        params.push(data.phone); }
  if (data.displayName !== undefined) { fields.push("display_name = ?"); params.push(data.displayName); }
  if (data.notificationPrefs) {
    const current = db.prepare("SELECT notification_prefs FROM users WHERE id = ?").get(req.user.uid) as any;
    const merged = { ...JSON.parse(current.notification_prefs), ...data.notificationPrefs };
    fields.push("notification_prefs = ?"); params.push(JSON.stringify(merged));
  }
  if (!fields.length) return res.json({ ok: true });
  params.push(req.user.uid);
  db.prepare(`UPDATE users SET ${fields.join(", ")} WHERE id = ?`).run(...params);
  res.json({ ok: true });
});

export default router;
