import { Router } from "express";
import { z } from "zod";
import { db } from "../lib/db.js";
import { attachUser } from "../lib/auth.js";
import {
  savePushSubscription, removePushSubscription, getVapidPublicKey, isPushConfigured,
} from "../lib/push.js";

const router = Router();
router.use(attachUser);

router.get("/vapid-public-key", (_req, res) => {
  res.json({ key: getVapidPublicKey(), configured: isPushConfigured() });
});

const subscribeSchema = z.object({
  endpoint: z.string().url(),
  keys: z.object({
    p256dh: z.string(),
    auth: z.string(),
  }),
  anonymousId: z.string().optional().nullable(),
});

router.post("/push/subscribe", (req, res) => {
  const data = subscribeSchema.parse(req.body);
  savePushSubscription({
    userId: req.user?.uid ?? null,
    anonymousId: req.user ? null : (data.anonymousId || req.header("x-anonymous-id")),
    endpoint: data.endpoint,
    keys: data.keys,
  });
  res.json({ ok: true });
});

router.post("/push/unsubscribe", (req, res) => {
  const schema = z.object({ endpoint: z.string().url() });
  const { endpoint } = schema.parse(req.body);
  removePushSubscription(endpoint);
  res.json({ ok: true });
});

/**
 * Update notification preferences for the currently logged-in user.
 * For anonymous visitors, this endpoint echoes the supplied prefs
 * but does not persist them — the browser keeps them in localStorage.
 */
const prefsSchema = z.object({
  email: z.boolean().optional(),
  sms: z.boolean().optional(),
  push: z.boolean().optional(),
  inApp: z.boolean().optional(),
  phone: z.string().optional().nullable(),
});

router.post("/preferences", (req, res) => {
  const data = prefsSchema.parse(req.body);
  if (!req.user) {
    // Echo back for the frontend to persist locally.
    return res.json({ ok: true, persisted: false, prefs: data });
  }
  const row: any = db.prepare("SELECT notification_prefs, phone FROM users WHERE id = ?").get(req.user.uid);
  const merged = { ...JSON.parse(row.notification_prefs), ...data };
  db.prepare("UPDATE users SET notification_prefs = ?, phone = COALESCE(?, phone) WHERE id = ?")
    .run(JSON.stringify(merged), data.phone ?? null, req.user.uid);
  res.json({ ok: true, persisted: true, prefs: merged });
});

export default router;
