/**
 * SMS delivery via Twilio. Falls back to console-log when no
 * Twilio credentials are configured.
 */

import twilio from "twilio";
import type { Alert } from "./alerts.js";

const SID   = process.env.TWILIO_SID;
const TOKEN = process.env.TWILIO_TOKEN;
const FROM  = process.env.TWILIO_FROM;

let client: ReturnType<typeof twilio> | null = null;
if (SID && TOKEN) {
  client = twilio(SID, TOKEN);
  console.log(`[sms] Twilio configured`);
} else {
  console.log("[sms] Twilio not configured — SMS will be logged to console");
}

export async function sendAlertSms(to: string, alert: Alert, locationName: string) {
  const body = `SkyWatch ${alert.severity.toUpperCase()}: ${alert.title}\n${locationName} (${alert.forecastDay}) — ${alert.message}`;

  if (!client || !FROM) {
    console.log(`\n[sms-stub] → ${to}\n${body}\n`);
    return { ok: true, stub: true };
  }

  try {
    await client.messages.create({ body, from: FROM, to });
    return { ok: true };
  } catch (err: any) {
    console.error(`[sms] send failed for ${to}:`, err.message);
    return { ok: false, error: err.message };
  }
}
