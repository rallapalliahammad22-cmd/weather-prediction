/**
 * Email delivery via SMTP (Nodemailer). If SMTP env vars are not
 * configured we fall back to logging to the console — perfect for
 * local development.
 */

import nodemailer from "nodemailer";
import type { Alert } from "./alerts.js";

const HOST  = process.env.SMTP_HOST;
const PORT  = Number(process.env.SMTP_PORT || 587);
const USER  = process.env.SMTP_USER;
const PASS  = process.env.SMTP_PASS;
const FROM  = process.env.SMTP_FROM || "SkyWatch <noreply@skywatch.app>";

let transporter: nodemailer.Transporter | null = null;

if (HOST && USER && PASS) {
  transporter = nodemailer.createTransport({
    host: HOST,
    port: PORT,
    secure: PORT === 465,
    auth: { user: USER, pass: PASS },
  });
  console.log(`[email] SMTP configured (${HOST}:${PORT})`);
} else {
  console.log("[email] SMTP not configured — emails will be logged to console");
}

export function alertEmailBody(alert: Alert, locationName: string) {
  const sevColor = {
    info:     "#2563eb",
    moderate: "#f59e0b",
    high:     "#ef4444",
    extreme:  "#7c1d6f",
  }[alert.severity];

  return `
    <div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:560px;margin:auto;padding:24px;border:1px solid #e5e7eb;border-radius:12px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
        <div style="background:#2563eb;color:#fff;padding:8px 12px;border-radius:8px;font-weight:700;">☁ SkyWatch</div>
        <div style="color:#6b7280;font-size:14px;">Weather Alert</div>
      </div>
      <h2 style="margin:0 0 8px;font-size:20px;color:#111827;">${alert.title}</h2>
      <div style="display:inline-block;background:${sevColor};color:#fff;padding:4px 10px;border-radius:999px;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;font-weight:600;margin-bottom:16px;">${alert.severity}</div>
      <p style="color:#374151;line-height:1.5;font-size:15px;">${alert.message}</p>
      <div style="margin-top:24px;padding:12px 16px;background:#f9fafb;border-radius:8px;font-size:13px;color:#6b7280;">
        <strong>${locationName}</strong> · forecast day <strong>${alert.forecastDay}</strong>
      </div>
      <p style="margin-top:24px;font-size:12px;color:#9ca3af;">
        You are receiving this because you enabled email alerts for ${locationName} on SkyWatch.
      </p>
    </div>
  `;
}

export async function sendAlertEmail(to: string, alert: Alert, locationName: string) {
  const subject = `[SkyWatch] ${alert.title} — ${locationName} (${alert.forecastDay})`;
  const html = alertEmailBody(alert, locationName);

  if (!transporter) {
    console.log(`\n[email-stub] → ${to}\nSubject: ${subject}\n${alert.message}\n`);
    return { ok: true, stub: true };
  }

  try {
    await transporter.sendMail({ from: FROM, to, subject, html });
    return { ok: true };
  } catch (err: any) {
    console.error(`[email] send failed for ${to}:`, err.message);
    return { ok: false, error: err.message };
  }
}
