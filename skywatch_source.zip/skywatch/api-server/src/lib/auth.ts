/**
 * SkyWatch Auth (optional)
 * --------------------------------------------------------------
 * Login is NOT required to use the app. These helpers exist so
 * users who want to sync their saved locations and notification
 * preferences across devices can create an account.
 *
 * Tokens are JWTs signed with HS256.
 */

import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { db } from "./db.js";

const SECRET = process.env.JWT_SECRET || "skywatch-dev-secret-change-me";
const TOKEN_TTL = "30d";

export interface UserRow {
  id: number;
  email: string;
  password_hash: string;
  phone: string | null;
  display_name: string | null;
  notification_prefs: string;
  created_at: string;
}

export interface TokenPayload {
  uid: number;
  email: string;
}

export async function register(email: string, password: string, phone?: string, displayName?: string) {
  if (!email || !password) throw new Error("Email and password are required");
  if (password.length < 6) throw new Error("Password must be at least 6 characters");

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email.toLowerCase());
  if (existing) throw new Error("An account with that email already exists");

  const hash = await bcrypt.hash(password, 10);
  const prefs = JSON.stringify({ email: !!email, sms: !!phone, push: true, inApp: true });
  const result = db.prepare(
    `INSERT INTO users (email, password_hash, phone, display_name, notification_prefs)
     VALUES (?, ?, ?, ?, ?)`
  ).run(email.toLowerCase(), hash, phone || null, displayName || null, prefs);
  const id = Number(result.lastInsertRowid);
  return sign({ uid: id, email: email.toLowerCase() });
}

export async function login(email: string, password: string) {
  const row = db.prepare("SELECT * FROM users WHERE email = ?").get(email.toLowerCase()) as UserRow | undefined;
  if (!row) throw new Error("Invalid email or password");
  const ok = await bcrypt.compare(password, row.password_hash);
  if (!ok) throw new Error("Invalid email or password");
  return sign({ uid: row.id, email: row.email });
}

export function sign(payload: TokenPayload): string {
  return jwt.sign(payload, SECRET, { expiresIn: TOKEN_TTL });
}

export function verify(token: string): TokenPayload | null {
  try { return jwt.verify(token, SECRET) as TokenPayload; }
  catch { return null; }
}

/** Express middleware: sets req.user if a valid Bearer token is present, otherwise continues. */
export function attachUser(req: any, _res: any, next: any) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (token) {
    const payload = verify(token);
    if (payload) req.user = payload;
  }
  next();
}

/** Express middleware: requires a logged-in user. */
export function requireAuth(req: any, res: any, next: any) {
  if (!req.user) return res.status(401).json({ error: "Authentication required" });
  next();
}

/** Generate a stable opaque ID for anonymous browser sessions. */
export function anonymousId() {
  return crypto.randomBytes(16).toString("hex");
}
