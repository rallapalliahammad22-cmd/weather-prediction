/**
 * SkyWatch Alert Engine
 * --------------------------------------------------------------
 * Inspects a 14-day forecast and raises alerts when:
 *   - Heavy rainfall (> ALERT_HEAVY_RAIN_MM mm or >90th percentile)
 *   - Extreme heat (high > ALERT_HIGH_HEAT_C °C)
 *   - Heatwave (3+ consecutive days > 38 °C)
 *   - Strong wind (gust > ALERT_STRONG_WIND_KMH km/h)
 *   - Unusual temperature swing (>15 °C day-over-day)
 *   - Thunderstorms
 */

import type { DailyWeather } from "./weather.js";

export type AlertType =
  | "heavy_rain"
  | "high_heat"
  | "heatwave"
  | "strong_wind"
  | "temp_swing"
  | "thunderstorm";

export type AlertSeverity = "info" | "moderate" | "high" | "extreme";

export interface Alert {
  locationId: number;
  type: AlertType;
  severity: AlertSeverity;
  title: string;
  message: string;
  forecastDay: string;        // YYYY-MM-DD
  metadata?: Record<string, unknown>;
}

const TH = {
  rain: Number(process.env.ALERT_HEAVY_RAIN_MM || 50),
  heat: Number(process.env.ALERT_HIGH_HEAT_C || 40),
  wind: Number(process.env.ALERT_STRONG_WIND_KMH || 60),
};

function severityRain(mm: number): AlertSeverity {
  if (mm >= 100) return "extreme";
  if (mm >= 75)  return "high";
  if (mm >= 50)  return "moderate";
  return "info";
}
function severityHeat(c: number): AlertSeverity {
  if (c >= 47) return "extreme";
  if (c >= 44) return "high";
  if (c >= 40) return "moderate";
  return "info";
}

export function generateAlerts(locationId: number, days: DailyWeather[]): Alert[] {
  const alerts: Alert[] = [];

  // ---- Heavy rain / thunderstorm (per-day) ----
  for (const d of days) {
    if (d.precipitation >= TH.rain || d.condition === "Heavy Rain" || d.condition === "Thunderstorm") {
      alerts.push({
        locationId,
        type: d.condition === "Thunderstorm" ? "thunderstorm" : "heavy_rain",
        severity: severityRain(d.precipitation),
        title: d.condition === "Thunderstorm" ? "⛈️ Thunderstorms Likely" : "🌧️ Heavy Rainfall Alert",
        message: `${d.date}: ${d.precipitation.toFixed(1)} mm of rain expected. ${d.description}`,
        forecastDay: d.date,
        metadata: { precipitation: d.precipitation, condition: d.condition },
      });
    }

    // ---- High heat ----
    if (d.tempHigh >= TH.heat) {
      alerts.push({
        locationId,
        type: "high_heat",
        severity: severityHeat(d.tempHigh),
        title: "🔥 Extreme Heat Warning",
        message: `${d.date}: forecast high of ${d.tempHigh.toFixed(0)} °C — stay hydrated and avoid prolonged sun exposure.`,
        forecastDay: d.date,
        metadata: { high: d.tempHigh },
      });
    }

    // ---- Strong wind ----
    if (d.windGust >= TH.wind) {
      alerts.push({
        locationId,
        type: "strong_wind",
        severity: d.windGust >= 90 ? "high" : "moderate",
        title: "💨 Strong Wind Warning",
        message: `${d.date}: wind gusts up to ${d.windGust.toFixed(0)} km/h expected.`,
        forecastDay: d.date,
        metadata: { gust: d.windGust },
      });
    }

    // ---- Day-over-day swing ----
    const idx = days.indexOf(d);
    if (idx > 0) {
      const prev = days[idx - 1];
      const swing = Math.abs(d.tempHigh - prev.tempHigh);
      if (swing >= 15) {
        alerts.push({
          locationId,
          type: "temp_swing",
          severity: swing >= 20 ? "high" : "moderate",
          title: "🌡️ Unusual Temperature Swing",
          message: `${d.date}: ${swing.toFixed(0)} °C change from ${prev.date} (${prev.tempHigh.toFixed(0)}° → ${d.tempHigh.toFixed(0)}°).`,
          forecastDay: d.date,
          metadata: { swing, from: prev.tempHigh, to: d.tempHigh },
        });
      }
    }
  }

  // ---- Heatwave (3 consecutive days >= 38 °C) ----
  let streak = 0;
  let streakStart: DailyWeather | null = null;
  for (const d of days) {
    if (d.tempHigh >= 38) {
      if (streak === 0) streakStart = d;
      streak++;
      if (streak >= 3 && streakStart) {
        alerts.push({
          locationId,
          type: "heatwave",
          severity: "high",
          title: "🌞 Heatwave Detected",
          message: `Heatwave from ${streakStart.date} to ${d.date}: highs of 38 °C or more for ${streak} consecutive days.`,
          forecastDay: streakStart.date,
          metadata: { days: streak },
        });
        streak = 0;
        streakStart = null;
      }
    } else {
      streak = 0;
      streakStart = null;
    }
  }

  // Dedupe by (type, forecastDay) keeping the highest severity
  const dedup = new Map<string, Alert>();
  for (const a of alerts) {
    const key = `${a.type}|${a.forecastDay}`;
    const existing = dedup.get(key);
    if (!existing) dedup.set(key, a);
    else if (severityRank(a.severity) > severityRank(existing.severity)) dedup.set(key, a);
  }
  return [...dedup.values()].sort((a, b) => a.forecastDay.localeCompare(b.forecastDay));
}

function severityRank(s: AlertSeverity) {
  return { info: 1, moderate: 2, high: 3, extreme: 4 }[s];
}

export const ALERT_THRESHOLDS = TH;
