/**
 * SQLite database wrapper using sql.js (pure-JS, WASM).
 * Works on Windows / macOS / Linux with NO native compilation.
 * Persists the database to a single file on disk.
 */

import initSqlJs from "sql.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { USERS_SCHEMA } from "../../db/schema/users.js";
import { LOCATIONS_SCHEMA } from "../../db/schema/locations.js";
import { ALERTS_SCHEMA, NOTIFICATION_LOG_SCHEMA } from "../../db/schema/alerts.js";
import { PUSH_SUBSCRIPTIONS_SCHEMA } from "../../db/schema/push_subscriptions.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.DB_PATH || path.join(__dirname, "../../db/skywatch.db");

let SQL: any;
let dbInstance: any;
let dirty = false;
let saveTimer: NodeJS.Timeout | null = null;

async function init() {
  if (dbInstance) return dbInstance;
  if (!SQL) {
    SQL = await initSqlJs();
  }
  try {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  } catch {}
  if (fs.existsSync(dbPath)) {
    const buf = fs.readFileSync(dbPath);
    dbInstance = new SQL.Database(new Uint8Array(buf));
  } else {
    dbInstance = new SQL.Database();
  }

  // Initialise schema (idempotent)
  dbInstance.exec(USERS_SCHEMA);
  dbInstance.exec(LOCATIONS_SCHEMA);
  dbInstance.exec(ALERTS_SCHEMA);
  dbInstance.exec(NOTIFICATION_LOG_SCHEMA);
  dbInstance.exec(PUSH_SUBSCRIPTIONS_SCHEMA);
  persist();
  console.log(`[db] SQLite ready at ${dbPath}`);
  return dbInstance;
}

function persist() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    if (!dirty || !dbInstance) return;
    try {
      const data = dbInstance.export();
      fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      fs.writeFileSync(dbPath, Buffer.from(data));
      dirty = false;
    } catch (e) {
      console.error(`[db] Failed to save database to ${dbPath}:`, e);
    }
  }, 50);
}

function flushSync() {
  if (!dbInstance) return;
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  if (!dirty) return;
  try {
    const data = dbInstance.export();
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    fs.writeFileSync(dbPath, Buffer.from(data));
    dirty = false;
  } catch (e) {
    console.error(`[db] Failed to sync database on exit to ${dbPath}:`, e);
  }
}

process.on("exit", flushSync);
process.on("SIGINT", () => { flushSync(); process.exit(0); });
process.on("SIGTERM", () => { flushSync(); process.exit(0); });

/**
 * Wrap a sql.js Statement so it looks like a better-sqlite3 prepared
 * statement:  stmt.bind(params); then step() in a loop.
 *
 * sql.js API:
 *   stmt.bind(params)        — bind parameters (array)
 *   stmt.step()              — returns true while rows remain
 *   stmt.getAsObject()       — current row as object
 *   stmt.reset()             — clear bindings for reuse
 *   stmt.free()              — release
 */
function wrapStatement(stmt: any) {
  return {
    run(...params: any[]) {
      try {
        stmt.bind(params);
        while (stmt.step()) { /* drain */ }
      } finally {
        stmt.reset();
      }
      dirty = true;
      persist();
      const changes = dbInstance.getRowsModified();
      const lastRowId = dbInstance.exec("SELECT last_insert_rowid() as id")[0]?.values?.[0]?.[0] ?? 0;
      return { changes, lastInsertRowid: BigInt(lastRowId) };
    },
    get(...params: any[]) {
      try {
        stmt.bind(params);
        if (stmt.step()) return stmt.getAsObject();
        return undefined;
      } finally {
        stmt.reset();
      }
    },
    all(...params: any[]) {
      const rows: any[] = [];
      try {
        stmt.bind(params);
        while (stmt.step()) rows.push(stmt.getAsObject());
      } finally {
        stmt.reset();
      }
      return rows;
    },
  };
}

export const db = {
  prepare(sql: string) {
    if (!dbInstance) throw new Error("Database not initialized yet — call dbReady() first");
    const stmt = dbInstance.prepare(sql);
    return wrapStatement(stmt);
  },
  exec(sql: string) {
    if (!dbInstance) throw new Error("Database not initialized yet — call dbReady() first");
    dbInstance.exec(sql);
    dirty = true;
    persist();
  },
  transaction<T>(fn: () => T): T {
    if (!dbInstance) throw new Error("Database not initialized yet");
    dbInstance.exec("BEGIN");
    try {
      const result = fn();
      dbInstance.exec("COMMIT");
      dirty = true;
      persist();
      return result;
    } catch (err) {
      dbInstance.exec("ROLLBACK");
      throw err;
    }
  },
};

export async function dbReady() {
  await init();
}

/** Synchronous bootstrap for top-level await users. */
export function dbBootstrap() {
  // Fire-and-forget; subsequent calls will await dbReady() if needed
  init().catch(err => console.error("[db] init error", err));
}

export default db;
