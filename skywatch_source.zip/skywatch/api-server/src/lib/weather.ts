/**
 * SkyWatch Weather Engine
 * --------------------------------------------------------------
 * Generates deterministic-yet-realistic weather data based on
 * location (lat / lon) and date. The model uses a 5-year
 * pseudo-historical record per location and produces a 14-day
 * forecast by weighted analysis of those years + a year-over-year
 * trend factor.
 *
 * NOTE: This is a self-contained engine — no external API key
 * is required. The same inputs always produce the same outputs,
 * so charts and alerts stay stable across reloads.
 */

import { INDIA_CITIES } from "./cities-india.js";
import { INDIA_CITIES_EXTRA } from "./cities-india-extra.js";
import { INDIA_CITIES_EXTRA2 } from "./cities-india-extra2.js";
import { AP_TN_CITIES } from "./cities-ap-tn.js";
import { AP_ALL_CITIES } from "./cities-ap-all.js";

export type WeatherCondition =
  | "Clear"
  | "Partly Cloudy"
  | "Cloudy"
  | "Overcast"
  | "Light Rain"
  | "Rain"
  | "Heavy Rain"
  | "Thunderstorm"
  | "Fog"
  | "Windy"
  | "Hot";

export interface HourlyWeather {
  hour: number;           // 0..23
  temperature: number;    // °C
  feelsLike: number;      // °C
  humidity: number;       // %
  windSpeed: number;      // km/h
  windDir: number;        // 0..359
  precipitation: number;  // mm
  precipitationProb: number; // 0..100
  uvIndex: number;        // 0..11
  visibility: number;     // km
  condition: WeatherCondition;
  cloudCover: number;     // 0..100
}

export interface DailyWeather {
  date: string;           // YYYY-MM-DD
  tempHigh: number;
  tempLow: number;
  tempAvg: number;
  feelsLikeHigh: number;
  feelsLikeLow: number;
  humidity: number;       // avg %
  windSpeed: number;      // avg km/h
  windGust: number;       // max km/h
  precipitation: number;  // total mm
  precipitationProb: number; // max prob %
  uvIndex: number;        // max
  visibility: number;     // min km
  sunrise: string;        // HH:MM
  sunset: string;         // HH:MM
  condition: WeatherCondition;
  description: string;
  hourly: HourlyWeather[];
}

export interface ClimateNormals {
  location: { lat: number; lon: number };
  monthlyHighs: number[];          // 12 values, °C
  monthlyLows: number[];           // 12 values, °C
  monthlyAvgTemps: number[];       // 12 values, °C (average of high+low)
  monthlyRain: number[];           // 12 values, mm
  monthlyRainDays: number[];       // 12 values, days with >1mm rain
  monthlySunshineHours: number[];  // 12 values, hrs/day avg
  yearlyAvgTemps: number[];        // 5 values, °C per year
  yearlyRainfall: number[];        // 5 values, mm per year
  yearlyExtremeHeatDays: number[]; // 5 values, days >35°C per year
  yearlyHeavyRainDays: number[];   // 5 values, days >50mm per year
  annualAvgTemp: number;
  annualRainfall: number;
  annualAvgHigh: number;
  annualAvgLow: number;
  annualRainyDays: number;
  annualSunshineHours: number;
  dataSpanYears: number;
  dataRange: { from: number; to: number };
  extremes: {
    hottestMonth: string;
    hottestMonthTemp: number;
    coldestMonth: string;
    coldestMonthTemp: number;
    wettestMonth: string;
    wettestMonthRain: number;
  };
  bestMonths: { month: string; score: number; reason: string }[];
  rainySeason: { start: string; end: string; months: string[] };
  insights: {
    extremeHeatDaysPerYear: number;
    heavyRainDaysPerYear: number;
    thunderstormDaysPerYear: number;
    sunnyDaysPerYear: number;
    comfortDaysPerYear: number;
    temperatureRangeC: number;
    warmingTrend: number;
  };
}

export interface CurrentWeather {
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  windDir: number;
  uvIndex: number;
  visibility: number;
  pressure: number;
  condition: WeatherCondition;
  description: string;
  isDay: boolean;
  observedAt: string;
}

// ---------- seeded RNG ----------
function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t = (t + 0x6d2b79f5) >>> 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// ---------- geo / climate helpers ----------
export function climateZone(lat: number): "tropical" | "subtropical" | "temperate" | "boreal" | "polar" {
  const a = Math.abs(lat);
  if (a < 15) return "tropical";
  if (a < 30) return "subtropical";
  if (a < 50) return "temperate";
  if (a < 66) return "boreal";
  return "polar";
}

interface ZoneProfile {
  baseHigh: number;     // average July-ish peak
  baseLow: number;      // average winter low
  ampSummer: number;    // seasonal swing magnitude
  rainBase: number;     // mm/month average
  rainPeak: number;     // mm wettest month
  rainDry: number;      // mm driest month
  humidity: number;     // 0..100
}

const ZONES: Record<ReturnType<typeof climateZone>, ZoneProfile> = {
  tropical:    { baseHigh: 33, baseLow: 24, ampSummer: 3,  rainBase: 180, rainPeak: 320, rainDry: 40,  humidity: 78 },
  subtropical: { baseHigh: 32, baseLow: 8,  ampSummer: 12, rainBase: 90,  rainPeak: 220, rainDry: 10,  humidity: 65 },
  temperate:   { baseHigh: 26, baseLow: -2, ampSummer: 18, rainBase: 70,  rainPeak: 130, rainDry: 35,  humidity: 68 },
  boreal:      { baseHigh: 20, baseLow: -18,ampSummer: 22, rainBase: 55,  rainPeak: 100, rainDry: 25,  humidity: 72 },
  polar:       { baseHigh: 8,  baseLow: -30,ampSummer: 15, rainBase: 30,  rainPeak: 60,  rainDry: 10,  humidity: 80 },
};

// Map lat to monthly temperature curves (Northern hemisphere).
// Southern hemisphere is mirrored.
function monthlyTemps(profile: ZoneProfile, lat: number) {
  const south = lat < 0;
  const out: { high: number; low: number }[] = [];
  for (let m = 0; m < 12; m++) {
    // peak in July (m=6) for N, January for S
    const phase = south ? (m - 0) : (m - 6);
    const seasonal = Math.cos((phase / 12) * Math.PI * 2);
    const high = profile.baseHigh - profile.ampSummer * 0.4 * (1 - seasonal) / 2;
    const low  = profile.baseLow  + profile.ampSummer * 0.6 * (1 + seasonal) / 2;
    out.push({
      high: round(high),
      low:  round(low),
    });
  }
  return out;
}

function monthlyRain(profile: ZoneProfile, lat: number) {
  // Monsoon-ish: peak around month 6 for N, month 12 for S
  const south = lat < 0;
  return Array.from({ length: 12 }, (_, m) => {
    const phase = south ? (m - 11) : (m - 6);
    const seasonal = (Math.cos((phase / 12) * Math.PI * 2) + 1) / 2; // 0..1
    const mm = profile.rainDry + (profile.rainPeak - profile.rainDry) * seasonal;
    return round(mm);
  });
}

// ---------- core helpers ----------
function round(n: number, p = 1) { return Math.round(n * Math.pow(10, p)) / Math.pow(10, p); }
function clamp(n: number, lo: number, hi: number) { return Math.max(lo, Math.min(hi, n)); }

// Day-of-year seasonal value for a given date (0..1, peak ≈ July 15 in N)
function seasonalFactor(date: Date, lat: number) {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = (date.getTime() - start.getTime()) + ((start.getTimezoneOffset() - date.getTimezoneOffset()) * 60 * 1000);
  const dayOfYear = Math.floor(diff / 86400000);
  const phase = lat < 0 ? (dayOfYear - 1) : (dayOfYear - 196);
  return (Math.cos((phase / 365) * Math.PI * 2) + 1) / 2; // 0..1 (1 = summer)
}

// Sunrise / sunset rough calculation
function sunTimes(date: Date, lat: number, lon: number): { sunrise: string; sunset: string } {
  const N = dayOfYear(date);
  const latRad = lat * Math.PI / 180;
  const decl = 23.45 * Math.PI / 180 * Math.sin(2 * Math.PI * (284 + N) / 365);
  const cosH = -Math.tan(latRad) * Math.tan(decl);
  let halfDay = 12;
  if (cosH >= 1) halfDay = 0;       // polar night
  else if (cosH <= -1) halfDay = 12; // polar day
  else halfDay = 12 + (Math.acos(cosH) * 12 / Math.PI);

  const solarNoon = 12 - lon / 15;
  const sunriseH = solarNoon - halfDay;
  const sunsetH  = solarNoon + halfDay;
  return {
    sunrise: fmtTime((sunriseH + 24) % 24),
    sunset:  fmtTime((sunsetH  + 24) % 24),
  };
}

function dayOfYear(d: Date) {
  const start = new Date(d.getFullYear(), 0, 0);
  return Math.floor((d.getTime() - start.getTime()) / 86400000);
}

function fmtTime(h: number) {
  const hh = Math.floor(h);
  const mm = Math.floor((h - hh) * 60);
  return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}

// Condition picking based on cloud cover + precip
function pickCondition(cloud: number, precip: number, uvMax: number): WeatherCondition {
  if (precip > 12) return "Heavy Rain";
  if (precip > 5)  return "Thunderstorm";
  if (precip > 2)  return "Rain";
  if (precip > 0.3) return "Light Rain";
  if (cloud > 85)  return "Overcast";
  if (cloud > 60)  return "Cloudy";
  if (cloud > 30)  return "Partly Cloudy";
  if (uvMax >= 9)  return "Hot";
  return "Clear";
}

function describe(c: WeatherCondition, high: number, low: number): string {
  switch (c) {
    case "Clear":         return `Clear skies with a high of ${high}° and a low of ${low}°.`;
    case "Partly Cloudy": return `Partly cloudy. High ${high}°, low ${low}°.`;
    case "Cloudy":        return `Cloudy throughout the day. High ${high}°, low ${low}°.`;
    case "Overcast":      return `Overcast. High ${high}°, low ${low}°.`;
    case "Light Rain":    return `Light rain expected. High ${high}°, low ${low}°.`;
    case "Rain":          return `Rain expected. High ${high}°, low ${low}°.`;
    case "Heavy Rain":    return `Heavy rainfall. High ${high}°, low ${low}°.`;
    case "Thunderstorm":  return `Thunderstorms likely. High ${high}°, low ${low}°.`;
    case "Fog":           return `Foggy conditions. High ${high}°, low ${low}°.`;
    case "Windy":         return `Windy with a high of ${high}° and a low of ${low}°.`;
    case "Hot":           return `Hot and sunny. High ${high}°, low ${low}°.`;
  }
}

// ---------- 5-year historical reconstruction ----------
// For a given (lat, lon, month, day) we hash into a stable seed
// and reconstruct 5 plausible years of past data, then average
// to produce today's expected values. Add a small trend drift
// (slight warming) so each "year" is plausibly different.
function historicalDayAvg(lat: number, lon: number, date: Date) {
  const zone = climateZone(lat);
  const profile = ZONES[zone];
  const seasonal = seasonalFactor(date, lat);
  const mIdx = date.getMonth();

  // Average expected high/low from zone profile for this month
  const monthTemps = monthlyTemps(profile, lat)[mIdx];
  const monthRain  = monthlyRain(profile, lat)[mIdx];

  // 5-year sampling: each year gets a unique seed & warming drift
  let sumH = 0, sumL = 0, sumR = 0, sumW = 0;
  for (let y = 0; y < 5; y++) {
    const seed = hashString(`${lat.toFixed(2)}|${lon.toFixed(2)}|${mIdx}|${date.getDate()}|y${y}`);
    const rng = mulberry32(seed);
    const warming = 0.04 * y; // 0.04°C/year drift
    const noiseH = (rng() - 0.5) * 4;
    const noiseL = (rng() - 0.5) * 3;
    const noiseR = (rng() - 0.5) * monthRain * 0.5;
    const noiseW = (rng() - 0.5) * 8;

    // Blend seasonal curve with monthly norms
    const baseH = monthTemps.high * (0.6 + 0.4 * seasonal) + profile.baseLow * 0.4 * (1 - seasonal);
    const baseL = monthTemps.low  * (0.6 + 0.4 * seasonal) + profile.baseLow * 0.4 * (1 - seasonal);
    sumH += baseH + noiseH + warming;
    sumL += baseL + noiseL + warming;
    sumR += Math.max(0, monthRain / 30 + noiseR / 30); // daily rain
    sumW += profile.humidity * 0.05 + noiseW;
  }
  return {
    high: sumH / 5,
    low:  sumL / 5,
    rain: sumR / 5,
    wind: sumW / 5,
  };
}

// ---------- Public API ----------

export function getCurrent(lat: number, lon: number, when = new Date()): CurrentWeather {
  const seed = hashString(`${lat.toFixed(2)}|${lon.toFixed(2)}|now|${when.getTime()}`);
  const rng = mulberry32(seed);
  const avg = historicalDayAvg(lat, lon, when);
  const seasonal = seasonalFactor(when, lat);
  const zone = climateZone(lat);
  const profile = ZONES[zone];

  const hour = when.getHours();
  const dayPhase = Math.sin(((hour - 6) / 24) * Math.PI * 2); // -1..1
  const baseHigh = avg.high;
  const baseLow  = avg.low;

  const temp = baseLow + (baseHigh - baseLow) * (0.5 + 0.5 * dayPhase);
  const humidity = clamp(profile.humidity + (rng() - 0.5) * 20, 20, 100);
  const windSpeed = clamp(avg.wind + (rng() - 0.5) * 6 + (seasonal > 0.7 ? 2 : 0), 0, 80);
  const uvIndex = hour >= 6 && hour <= 19
    ? Math.round(clamp(8 * Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI)) * (seasonal > 0.4 ? 1 : 0.5) + (rng() - 0.5) * 2, 0, 11))
    : 0;
  const visibility = clamp(25 + (rng() - 0.5) * 5 - (humidity > 85 ? 6 : 0), 5, 30);
  const cloudCover = Math.round(40 + (rng() - 0.5) * 60);

  const condition = pickCondition(cloudCover, 0, uvIndex);
  const feelsLike = temp + (humidity > 70 ? 1.5 : 0) - (windSpeed > 20 ? 2 : 0);

  return {
    temperature: round(temp),
    feelsLike: round(feelsLike),
    humidity: Math.round(humidity),
    windSpeed: round(windSpeed, 1),
    windDir: Math.round(rng() * 360),
    uvIndex,
    visibility: round(visibility, 1),
    pressure: Math.round(1010 + (rng() - 0.5) * 20),
    condition,
    description: describe(condition, Math.round(baseHigh), Math.round(baseLow)),
    isDay: hour >= 6 && hour <= 19,
    observedAt: when.toISOString(),
  };
}

/** Produce a single daily forecast using the historical average + day-noise. */
export function getDaily(lat: number, lon: number, date: Date): DailyWeather {
  const avg = historicalDayAvg(lat, lon, date);
  const zone = climateZone(lat);
  const profile = ZONES[zone];

  const seed = hashString(`${lat.toFixed(2)}|${lon.toFixed(2)}|${date.toISOString().slice(0, 10)}`);
  const rng = mulberry32(seed);

  // Trend: forecast tends to drift slightly warmer each day
  const trend = 0.15 * (date.getDate() % 7);

  const tempHigh = clamp(avg.high + trend + (rng() - 0.5) * 2, avg.low + 4, 55);
  const tempLow  = clamp(avg.low  + trend * 0.5 + (rng() - 0.5) * 2, -45, tempHigh - 3);

  // Build hourly
  const sun = sunTimes(date, lat, lon);
  const sunriseH = parseInt(sun.sunrise.slice(0, 2)) + parseInt(sun.sunrise.slice(3)) / 60;
  const sunsetH  = parseInt(sun.sunset.slice(0, 2))  + parseInt(sun.sunset.slice(3))  / 60;

  const hourly: HourlyWeather[] = [];
  let totalPrecip = 0;
  let maxPrecipProb = 0;
  let maxUV = 0;
  let minVis = 30;
  let maxGust = 0;
  let avgHum = 0;
  let maxCloud = 0;

  for (let h = 0; h < 24; h++) {
    const dayPhase = Math.sin(((h - 6) / 24) * Math.PI * 2); // -1..1
    const temp = tempLow + (tempHigh - tempLow) * (0.5 + 0.5 * dayPhase);
    const humidity = clamp(profile.humidity + (h < 6 || h > 20 ? 8 : -5) + (rng() - 0.5) * 15, 20, 100);
    const wind = clamp(avg.wind + (rng() - 0.5) * 8 + (h > 12 && h < 18 ? 2 : 0), 0, 90);
    const gust = wind * (1.2 + rng() * 0.6);
    const isDay = h >= sunriseH && h <= sunsetH;
    const uv = isDay ? Math.round(clamp(9 * Math.sin(((h - sunriseH) / Math.max(1, sunsetH - sunriseH)) * Math.PI) + (rng() - 0.5) * 1.5, 0, 11)) : 0;
    const cloud = clamp(45 + (rng() - 0.5) * 60 + (temp - tempHigh > -2 ? -10 : 0), 0, 100);
    const precipProb = clamp((cloud > 70 ? 60 + (rng() - 0.3) * 50 : cloud > 40 ? 20 + rng() * 30 : rng() * 10), 0, 100);
    const precip = precipProb > 70 ? round((rng() * 4 + cloud / 40), 1) : precipProb > 40 ? round(rng() * 1.2, 1) : 0;
    const visibility = clamp(28 - (humidity > 85 ? 6 : 0) - (precip > 1 ? 4 : 0) + (rng() - 0.5) * 3, 3, 30);
    const condition = pickCondition(cloud, precip, uv);
    const feelsLike = temp + (humidity > 75 ? 1.5 : 0) - (wind > 25 ? 2 : 0);

    hourly.push({
      hour: h,
      temperature: round(temp),
      feelsLike: round(feelsLike),
      humidity: Math.round(humidity),
      windSpeed: round(wind, 1),
      windDir: Math.round(rng() * 360),
      precipitation: precip,
      precipitationProb: Math.round(precipProb),
      uvIndex: uv,
      visibility: round(visibility, 1),
      condition,
      cloudCover: Math.round(cloud),
    });

    totalPrecip += precip;
    maxPrecipProb = Math.max(maxPrecipProb, precipProb);
    maxUV = Math.max(maxUV, uv);
    minVis = Math.min(minVis, visibility);
    maxGust = Math.max(maxGust, gust);
    avgHum += humidity;
    maxCloud = Math.max(maxCloud, cloud);
  }
  avgHum /= 24;

  const dominant = hourly.reduce((acc, h) => {
    acc[h.condition] = (acc[h.condition] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const condition = (Object.entries(dominant).sort((a, b) => b[1] - a[1])[0]?.[0] || "Clear") as WeatherCondition;
  const tempAvg = hourly.reduce((s, h) => s + h.temperature, 0) / 24;

  return {
    date: date.toISOString().slice(0, 10),
    tempHigh: round(tempHigh),
    tempLow: round(tempLow),
    tempAvg: round(tempAvg),
    feelsLikeHigh: round(tempHigh + (avgHum > 75 ? 1.5 : 0)),
    feelsLikeLow:  round(tempLow  - (avg.wind > 25 ? 2 : 0)),
    humidity: Math.round(avgHum),
    windSpeed: round(avg.wind, 1),
    windGust: round(maxGust, 1),
    precipitation: round(totalPrecip, 1),
    precipitationProb: Math.round(maxPrecipProb),
    uvIndex: maxUV,
    visibility: round(minVis, 1),
    sunrise: sun.sunrise,
    sunset:  sun.sunset,
    condition,
    description: describe(condition, Math.round(tempHigh), Math.round(tempLow)),
    hourly,
  };
}

/** Build a 14-day forecast starting from today. */
export function get14DayForecast(lat: number, lon: number, start = new Date()): DailyWeather[] {
  const out: DailyWeather[] = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    d.setHours(0, 0, 0, 0);
    out.push(getDaily(lat, lon, d));
  }
  return out;
}

/** Build a 7-day outlook summary (high/low + rain prob). */
export function get7DayOutlook(lat: number, lon: number, start = new Date()) {
  return get14DayForecast(lat, lon, start).slice(0, 7).map(d => ({
    date: d.date,
    tempHigh: d.tempHigh,
    tempLow: d.tempLow,
    precipitationProb: d.precipitationProb,
    condition: d.condition,
  }));
}

/** Climate normals: rich climate statistics averaged across 5 years. */
export function getClimateNormals(lat: number, lon: number): ClimateNormals {
  const zone = climateZone(lat);
  const profile = ZONES[zone];
  const monthTemps = monthlyTemps(profile, lat);
  const monthRain = monthlyRain(profile, lat);
  const highs = monthTemps.map(m => m.high);
  const lows = monthTemps.map(m => m.low);

  // Inject small variability based on lon to differentiate same-zone cities
  const lonOffset = ((lon % 30) / 30 - 0.5) * 2; // -1..1
  const adj = lonOffset * 1.5;
  const adjustedHighs = highs.map(h => round(h + adj));
  const adjustedLows = lows.map(l => round(l + adj));
  const adjustedAvg = adjustedHighs.map((h, i) => round((h + adjustedLows[i]) / 2));

  const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  const hottestIdx = adjustedHighs.indexOf(Math.max(...adjustedHighs));
  const coldestIdx = adjustedLows.indexOf(Math.min(...adjustedLows));
  const wettestIdx = monthRain.indexOf(Math.max(...monthRain));

  const annualAvg = round((adjustedHighs.reduce((a, b) => a + b, 0) + adjustedLows.reduce((a, b) => a + b, 0)) / 24);
  const annualRain = round(monthRain.reduce((a, b) => a + b, 0));
  const annualAvgHigh = round(adjustedHighs.reduce((a, b) => a + b, 0) / 12, 1);
  const annualAvgLow = round(adjustedLows.reduce((a, b) => a + b, 0) / 12, 1);

  // Year-over-year reconstruction (5 years)
  const yearlyAvgTemps: number[] = [];
  const yearlyRainfall: number[] = [];
  const yearlyExtremeHeat: number[] = [];
  const yearlyHeavyRain: number[] = [];
  const seedBase = `${lat.toFixed(2)}|${lon.toFixed(2)}|annual`;

  for (let y = 0; y < 5; y++) {
    const rng = mulberry32(hashString(`${seedBase}|y${y}`));
    const warming = 0.04 * y; // °C per year
    const yearlyAvg = annualAvg + warming + (rng() - 0.5) * 0.6;
    const yearlyR = annualRain + (rng() - 0.5) * annualRain * 0.18;

    // Approximate extreme days per year
    const heatThreshold = Math.max(35, profile.baseHigh);
    const isHot = profile.baseHigh >= 30;
    const baseExtremeHeat = isHot ? 25 + (rng() - 0.5) * 12 : 5 + (rng() - 0.5) * 6;
    const baseHeavyRain = profile.rainPeak > 200 ? 8 + (rng() - 0.5) * 4 : 3 + (rng() - 0.5) * 3;

    yearlyAvgTemps.push(round(yearlyAvg, 2));
    yearlyRainfall.push(Math.round(yearlyR));
    yearlyExtremeHeat.push(Math.max(0, Math.round(baseExtremeHeat + warming * 5)));
    yearlyHeavyRain.push(Math.max(0, Math.round(baseHeavyRain + (rng() - 0.5) * 2)));
  }

  // Rainy days per month (days with >1mm)
  const monthlyRainDays = monthRain.map(mm => Math.min(31, Math.round(mm / 30 * 30 + (mm > 150 ? 5 : 0))));
  const annualRainyDays = monthlyRainDays.reduce((a, b) => a + b, 0);

  // Sunshine hours per day per month (rough: tropical=8, subtropical=7, etc., seasonal adjusted)
  const baseSun = { tropical: 7.5, subtropical: 6.5, temperate: 5.5, boreal: 4.5, polar: 3.5 }[zone];
  const monthlySunshineHours = Array.from({ length: 12 }, (_, m) => {
    const seasonal = Math.abs(((m - 6) / 12) * 2); // 0 = summer, 2 = winter
    const seasonalAdj = seasonal * (zone === "polar" ? -2 : -0.8);
    const sun = baseSun + seasonalAdj + (monthRain[m] > 200 ? -1.2 : 0);
    return round(Math.max(1, sun), 1);
  });
  const annualSunshineHours = Math.round(monthlySunshineHours.reduce((a, b) => a + b, 0) * 30);

  // Best months to visit (score = comfort: temp in 18-28°C, low rain, high sun)
  const monthScores = adjustedAvg.map((t, i) => {
    const tempScore = (t >= 18 && t <= 27) ? 100 - Math.abs(t - 22.5) * 8 :
                      (t >= 10 && t <= 32) ? 60 - Math.abs(t - 22.5) * 5 : 20;
    const rainScore = Math.max(0, 100 - monthRain[i] * 0.4);
    const sunScore = monthlySunshineHours[i] * 12;
    const score = Math.round(tempScore * 0.4 + rainScore * 0.35 + sunScore * 0.25);
    let reason = "";
    if (tempScore >= 80 && rainScore >= 70) reason = "Pleasant temps with little rain";
    else if (tempScore >= 80) reason = "Comfortable temperatures";
    else if (rainScore >= 70) reason = "Dry and clear";
    else if (t < 10) reason = "Cold — bundle up";
    else if (t > 32) reason = "Very hot — bring water";
    else if (monthRain[i] > 200) reason = "Heavy monsoon rains";
    else reason = "Mixed conditions";
    return { month: months[i], score, reason, temp: t, rain: monthRain[i], sun: monthlySunshineHours[i] };
  });
  const bestMonths = monthScores
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(({ month, score, reason }) => ({ month, score, reason }));

  // Rainy season: contiguous months where rain > 60% of peak
  const rainThreshold = monthRain[wettestIdx] * 0.6;
  const rainyMonths = monthRain.map((r, i) => r >= rainThreshold ? months[i] : null).filter(Boolean) as string[];
  const rainySeason = {
    months: rainyMonths,
    start: rainyMonths[0] || "—",
    end: rainyMonths[rainyMonths.length - 1] || "—",
  };

  // Insights
  const tempRange = Math.round(Math.max(...adjustedHighs) - Math.min(...adjustedLows));
  const thunderstormDays = Math.round(annualRainyDays * 0.15);
  const sunnyDays = Math.round(annualSunshineHours / 8);
  const comfortDays = 365 - yearlyExtremeHeat[4] - yearlyHeavyRain[4] - thunderstormDays;

  const avgFirstYear = yearlyAvgTemps[0];
  const avgLastYear = yearlyAvgTemps[4];
  const warmingTrend = round((avgLastYear - avgFirstYear) / 4, 2); // °C per year average

  const currentYear = new Date().getFullYear();
  const dataRange = { from: currentYear - 5, to: currentYear - 1 };

  return {
    location: { lat, lon },
    monthlyHighs: adjustedHighs,
    monthlyLows: adjustedLows,
    monthlyAvgTemps: adjustedAvg,
    monthlyRain: monthRain,
    monthlyRainDays,
    monthlySunshineHours,
    yearlyAvgTemps,
    yearlyRainfall,
    yearlyExtremeHeatDays: yearlyExtremeHeat,
    yearlyHeavyRainDays: yearlyHeavyRain,
    annualAvgTemp: annualAvg,
    annualRainfall: annualRain,
    annualAvgHigh,
    annualAvgLow,
    annualRainyDays,
    annualSunshineHours,
    dataSpanYears: 5,
    dataRange,
    extremes: {
      hottestMonth: months[hottestIdx],
      hottestMonthTemp: adjustedHighs[hottestIdx],
      coldestMonth: months[coldestIdx],
      coldestMonthTemp: adjustedLows[coldestIdx],
      wettestMonth: months[wettestIdx],
      wettestMonthRain: monthRain[wettestIdx],
    },
    bestMonths,
    rainySeason,
    insights: {
      extremeHeatDaysPerYear: Math.round(yearlyExtremeHeat.reduce((a, b) => a + b, 0) / 5),
      heavyRainDaysPerYear: Math.round(yearlyHeavyRain.reduce((a, b) => a + b, 0) / 5),
      thunderstormDaysPerYear: thunderstormDays,
      sunnyDaysPerYear: sunnyDays,
      comfortDaysPerYear: comfortDays,
      temperatureRangeC: tempRange,
      warmingTrend,
    },
  };
}

/** Historical 5-year reconstruction for a date range. */
export function getHistorical(lat: number, lon: number, from: Date, to: Date) {
  const days: { date: string; highs: number[]; lows: number[]; rain: number[] }[] = [];
  const cur = new Date(from);
  while (cur <= to) {
    const seedBase = `${lat.toFixed(2)}|${lon.toFixed(2)}|${cur.toISOString().slice(0, 10)}`;
    const highs: number[] = [];
    const lows: number[] = [];
    const rain: number[] = [];
    for (let y = 0; y < 5; y++) {
      const seed = hashString(`${seedBase}|y${y}`);
      const rng = mulberry32(seed);
      const avg = historicalDayAvg(lat, lon, cur);
      highs.push(round(avg.high + (rng() - 0.5) * 4 + 0.04 * y));
      lows.push(round(avg.low + (rng() - 0.5) * 3 + 0.04 * y));
      rain.push(round(Math.max(0, avg.rain + (rng() - 0.5) * 4), 1));
    }
    days.push({
      date: cur.toISOString().slice(0, 10),
      highs,
      lows,
      rain,
    });
    cur.setDate(cur.getDate() + 1);
  }
  return days;
}

/**
 * Comprehensive geocoder covering 200+ cities across all climate zones.
 * Each entry: { name, country, region, latitude, longitude, timezone }.
 * The `key` is what users will type in the search box (lowercase).
 */
type City = { name: string; country: string; region: string; lat: number; lon: number; timezone: string };

const CITIES: City[] = [
  // ============ INDIA — State capitals & major cities ============
  { name: "Chennai",       country: "India", region: "Tamil Nadu",       lat: 13.0827,  lon: 80.2707,  timezone: "Asia/Kolkata" },
  { name: "Mumbai",        country: "India", region: "Maharashtra",      lat: 19.0760,  lon: 72.8777,  timezone: "Asia/Kolkata" },
  { name: "Delhi",         country: "India", region: "Delhi",            lat: 28.7041,  lon: 77.1025,  timezone: "Asia/Kolkata" },
  { name: "New Delhi",     country: "India", region: "Delhi",            lat: 28.6139,  lon: 77.2090,  timezone: "Asia/Kolkata" },
  { name: "Bengaluru",     country: "India", region: "Karnataka",        lat: 12.9716,  lon: 77.5946,  timezone: "Asia/Kolkata" },
  { name: "Bangalore",     country: "India", region: "Karnataka",        lat: 12.9716,  lon: 77.5946,  timezone: "Asia/Kolkata" },
  { name: "Kolkata",       country: "India", region: "West Bengal",      lat: 22.5726,  lon: 88.3639,  timezone: "Asia/Kolkata" },
  { name: "Hyderabad",     country: "India", region: "Telangana",        lat: 17.3850,  lon: 78.4867,  timezone: "Asia/Kolkata" },
  { name: "Ahmedabad",     country: "India", region: "Gujarat",          lat: 23.0225,  lon: 72.5714,  timezone: "Asia/Kolkata" },
  { name: "Pune",          country: "India", region: "Maharashtra",      lat: 18.5204,  lon: 73.8567,  timezone: "Asia/Kolkata" },
  { name: "Jaipur",        country: "India", region: "Rajasthan",        lat: 26.9124,  lon: 75.7873,  timezone: "Asia/Kolkata" },
  { name: "Lucknow",       country: "India", region: "Uttar Pradesh",    lat: 26.8467,  lon: 80.9462,  timezone: "Asia/Kolkata" },
  { name: "Kanpur",        country: "India", region: "Uttar Pradesh",    lat: 26.4499,  lon: 80.3319,  timezone: "Asia/Kolkata" },
  { name: "Nagpur",        country: "India", region: "Maharashtra",      lat: 21.1458,  lon: 79.0882,  timezone: "Asia/Kolkata" },
  { name: "Indore",        country: "India", region: "Madhya Pradesh",   lat: 22.7196,  lon: 75.8577,  timezone: "Asia/Kolkata" },
  { name: "Bhopal",        country: "India", region: "Madhya Pradesh",   lat: 23.2599,  lon: 77.4126,  timezone: "Asia/Kolkata" },
  { name: "Patna",         country: "India", region: "Bihar",            lat: 25.5941,  lon: 85.1376,  timezone: "Asia/Kolkata" },
  { name: "Vadodara",      country: "India", region: "Gujarat",          lat: 22.3072,  lon: 73.1812,  timezone: "Asia/Kolkata" },
  { name: "Ghaziabad",     country: "India", region: "Uttar Pradesh",    lat: 28.6692,  lon: 77.4538,  timezone: "Asia/Kolkata" },
  { name: "Ludhiana",      country: "India", region: "Punjab",           lat: 30.9010,  lon: 75.8573,  timezone: "Asia/Kolkata" },
  { name: "Agra",          country: "India", region: "Uttar Pradesh",    lat: 27.1767,  lon: 78.0081,  timezone: "Asia/Kolkata" },
  { name: "Nashik",        country: "India", region: "Maharashtra",      lat: 19.9975,  lon: 73.7898,  timezone: "Asia/Kolkata" },
  { name: "Faridabad",     country: "India", region: "Haryana",          lat: 28.4089,  lon: 77.3178,  timezone: "Asia/Kolkata" },
  { name: "Meerut",        country: "India", region: "Uttar Pradesh",    lat: 28.9845,  lon: 77.7064,  timezone: "Asia/Kolkata" },
  { name: "Rajkot",        country: "India", region: "Gujarat",          lat: 22.3039,  lon: 70.8022,  timezone: "Asia/Kolkata" },
  { name: "Varanasi",      country: "India", region: "Uttar Pradesh",    lat: 25.3176,  lon: 82.9739,  timezone: "Asia/Kolkata" },
  { name: "Srinagar",      country: "India", region: "Jammu & Kashmir",  lat: 34.0837,  lon: 74.7973,  timezone: "Asia/Kolkata" },
  { name: "Amritsar",      country: "India", region: "Punjab",           lat: 31.6340,  lon: 74.8723,  timezone: "Asia/Kolkata" },
  { name: "Chandigarh",    country: "India", region: "Chandigarh",       lat: 30.7333,  lon: 76.7794,  timezone: "Asia/Kolkata" },
  { name: "Jammu",         country: "India", region: "Jammu & Kashmir",  lat: 32.7266,  lon: 74.8570,  timezone: "Asia/Kolkata" },
  { name: "Shimla",        country: "India", region: "Himachal Pradesh", lat: 31.1048,  lon: 77.1734,  timezone: "Asia/Kolkata" },
  { name: "Manali",        country: "India", region: "Himachal Pradesh", lat: 32.2396,  lon: 77.1887,  timezone: "Asia/Kolkata" },
  { name: "Dehradun",      country: "India", region: "Uttarakhand",      lat: 30.3165,  lon: 78.0322,  timezone: "Asia/Kolkata" },
  { name: "Haridwar",      country: "India", region: "Uttarakhand",      lat: 29.9457,  lon: 78.1642,  timezone: "Asia/Kolkata" },
  { name: "Rishikesh",     country: "India", region: "Uttarakhand",      lat: 30.1033,  lon: 78.2948,  timezone: "Asia/Kolkata" },
  { name: "Nainital",      country: "India", region: "Uttarakhand",      lat: 29.3803,  lon: 79.4636,  timezone: "Asia/Kolkata" },
  { name: "Guwahati",      country: "India", region: "Assam",            lat: 26.1445,  lon: 91.7362,  timezone: "Asia/Kolkata" },
  { name: "Shillong",      country: "India", region: "Meghalaya",        lat: 25.5788,  lon: 91.8933,  timezone: "Asia/Kolkata" },
  { name: "Imphal",        country: "India", region: "Manipur",          lat: 24.8170,  lon: 93.9368,  timezone: "Asia/Kolkata" },
  { name: "Aizawl",        country: "India", region: "Mizoram",          lat: 23.7271,  lon: 92.7176,  timezone: "Asia/Kolkata" },
  { name: "Kohima",        country: "India", region: "Nagaland",         lat: 25.6747,  lon: 94.1100,  timezone: "Asia/Kolkata" },
  { name: "Itanagar",      country: "India", region: "Arunachal Pradesh",lat: 27.0844,  lon: 93.6053,  timezone: "Asia/Kolkata" },
  { name: "Gangtok",       country: "India", region: "Sikkim",           lat: 27.3389,  lon: 88.6065,  timezone: "Asia/Kolkata" },
  { name: "Panaji",        country: "India", region: "Goa",              lat: 15.4989,  lon: 73.8278,  timezone: "Asia/Kolkata" },
  { name: "Margao",        country: "India", region: "Goa",              lat: 15.2993,  lon: 73.9583,  timezone: "Asia/Kolkata" },
  { name: "Thiruvananthapuram", country: "India", region: "Kerala",     lat: 8.5241,   lon: 76.9366,  timezone: "Asia/Kolkata" },
  { name: "Kochi",         country: "India", region: "Kerala",           lat: 9.9312,   lon: 76.2673,  timezone: "Asia/Kolkata" },
  { name: "Kozhikode",     country: "India", region: "Kerala",           lat: 11.2588,  lon: 75.7804,  timezone: "Asia/Kolkata" },
  { name: "Coimbatore",    country: "India", region: "Tamil Nadu",       lat: 11.0168,  lon: 76.9558,  timezone: "Asia/Kolkata" },
  { name: "Madurai",       country: "India", region: "Tamil Nadu",       lat: 9.9252,   lon: 78.1198,  timezone: "Asia/Kolkata" },
  { name: "Tiruchirappalli", country: "India", region: "Tamil Nadu",     lat: 10.7905,  lon: 78.7047,  timezone: "Asia/Kolkata" },
  { name: "Salem",         country: "India", region: "Tamil Nadu",       lat: 11.6643,  lon: 78.1460,  timezone: "Asia/Kolkata" },
  { name: "Vellore",       country: "India", region: "Tamil Nadu",       lat: 12.9165,  lon: 79.1325,  timezone: "Asia/Kolkata" },
  { name: "Tirupati",      country: "India", region: "Andhra Pradesh",   lat: 13.6288,  lon: 79.4192,  timezone: "Asia/Kolkata" },
  { name: "Vijayawada",    country: "India", region: "Andhra Pradesh",   lat: 16.5062,  lon: 80.6480,  timezone: "Asia/Kolkata" },
  { name: "Visakhapatnam", country: "India", region: "Andhra Pradesh",   lat: 17.6868,  lon: 83.2185,  timezone: "Asia/Kolkata" },
  { name: "Guntur",        country: "India", region: "Andhra Pradesh",   lat: 16.3067,  lon: 80.4365,  timezone: "Asia/Kolkata" },
  { name: "Nellore",       country: "India", region: "Andhra Pradesh",   lat: 14.4426,  lon: 79.9865,  timezone: "Asia/Kolkata" },
  { name: "Kurnool",       country: "India", region: "Andhra Pradesh",   lat: 15.8281,  lon: 78.0373,  timezone: "Asia/Kolkata" },
  { name: "Anantapur",     country: "India", region: "Andhra Pradesh",   lat: 14.6819,  lon: 77.6006,  timezone: "Asia/Kolkata" },
  { name: "Kakinada",      country: "India", region: "Andhra Pradesh",   lat: 16.9891,  lon: 82.2475,  timezone: "Asia/Kolkata" },
  { name: "Rajahmundry",   country: "India", region: "Andhra Pradesh",   lat: 17.0005,  lon: 81.8040,  timezone: "Asia/Kolkata" },
  { name: "Rayachoti",     country: "India", region: "Andhra Pradesh",   lat: 14.0583,  lon: 78.7514,  timezone: "Asia/Kolkata" },
  { name: "Sattenapalle",  country: "India", region: "Andhra Pradesh",   lat: 16.3960,  lon: 80.1497,  timezone: "Asia/Kolkata" },
  { name: "Warangal",      country: "India", region: "Telangana",        lat: 17.9689,  lon: 79.5941,  timezone: "Asia/Kolkata" },
  { name: "Karimnagar",    country: "India", region: "Telangana",        lat: 18.4386,  lon: 79.1288,  timezone: "Asia/Kolkata" },
  { name: "Tirupati",      country: "India", region: "Andhra Pradesh",   lat: 13.6288,  lon: 79.4192,  timezone: "Asia/Kolkata" },
  { name: "Surat",         country: "India", region: "Gujarat",          lat: 21.1702,  lon: 72.8311,  timezone: "Asia/Kolkata" },
  { name: "Ranchi",        country: "India", region: "Jharkhand",        lat: 23.3441,  lon: 85.3096,  timezone: "Asia/Kolkata" },
  { name: "Bhubaneswar",   country: "India", region: "Odisha",           lat: 20.2961,  lon: 85.8245,  timezone: "Asia/Kolkata" },
  { name: "Cuttack",       country: "India", region: "Odisha",           lat: 20.4625,  lon: 85.8830,  timezone: "Asia/Kolkata" },
  { name: "Raipur",        country: "India", region: "Chhattisgarh",     lat: 21.2514,  lon: 81.6296,  timezone: "Asia/Kolkata" },
  { name: "Jabalpur",      country: "India", region: "Madhya Pradesh",   lat: 23.1815,  lon: 79.9864,  timezone: "Asia/Kolkata" },
  { name: "Gwalior",       country: "India", region: "Madhya Pradesh",   lat: 26.2183,  lon: 78.1828,  timezone: "Asia/Kolkata" },

  // ============ SOUTH ASIA ============
  { name: "Karachi",       country: "Pakistan",  region: "Sindh",           lat: 24.8607,  lon: 67.0011,  timezone: "Asia/Karachi" },
  { name: "Lahore",        country: "Pakistan",  region: "Punjab",          lat: 31.5204,  lon: 74.3587,  timezone: "Asia/Karachi" },
  { name: "Islamabad",     country: "Pakistan",  region: "ICT",             lat: 33.6844,  lon: 73.0479,  timezone: "Asia/Karachi" },
  { name: "Dhaka",         country: "Bangladesh",region: "",                lat: 23.8103,  lon: 90.4125,  timezone: "Asia/Dhaka" },
  { name: "Colombo",       country: "Sri Lanka",region: "Western",         lat: 6.9271,   lon: 79.8612,  timezone: "Asia/Colombo" },
  { name: "Kathmandu",     country: "Nepal",    region: "Bagmati",         lat: 27.7172,  lon: 85.3240,  timezone: "Asia/Kathmandu" },
  { name: "Thimphu",       country: "Bhutan",   region: "",                lat: 27.4728,  lon: 89.6390,  timezone: "Asia/Thimphu" },
  { name: "Male",          country: "Maldives", region: "",                lat: 4.1755,   lon: 73.5093,  timezone: "Indian/Maldives" },

  // ============ EAST ASIA ============
  { name: "Tokyo",         country: "Japan",     region: "Kanto",          lat: 35.6762,  lon: 139.6503, timezone: "Asia/Tokyo" },
  { name: "Osaka",         country: "Japan",     region: "Kansai",         lat: 34.6937,  lon: 135.5023, timezone: "Asia/Tokyo" },
  { name: "Kyoto",         country: "Japan",     region: "Kansai",         lat: 35.0116,  lon: 135.7681, timezone: "Asia/Tokyo" },
  { name: "Yokohama",      country: "Japan",     region: "Kanto",          lat: 35.4437,  lon: 139.6380, timezone: "Asia/Tokyo" },
  { name: "Sapporo",       country: "Japan",     region: "Hokkaido",       lat: 43.0618,  lon: 141.3545, timezone: "Asia/Tokyo" },
  { name: "Nagoya",        country: "Japan",     region: "Chubu",          lat: 35.1815,  lon: 136.9066, timezone: "Asia/Tokyo" },
  { name: "Fukuoka",       country: "Japan",     region: "Kyushu",         lat: 33.5904,  lon: 130.4017, timezone: "Asia/Tokyo" },
  { name: "Beijing",       country: "China",     region: "",               lat: 39.9042,  lon: 116.4074, timezone: "Asia/Shanghai" },
  { name: "Shanghai",      country: "China",     region: "",               lat: 31.2304,  lon: 121.4737, timezone: "Asia/Shanghai" },
  { name: "Guangzhou",     country: "China",     region: "Guangdong",      lat: 23.1291,  lon: 113.2644, timezone: "Asia/Shanghai" },
  { name: "Shenzhen",      country: "China",     region: "Guangdong",      lat: 22.5431,  lon: 114.0579, timezone: "Asia/Shanghai" },
  { name: "Chengdu",       country: "China",     region: "Sichuan",        lat: 30.5728,  lon: 104.0668, timezone: "Asia/Shanghai" },
  { name: "Xi'an",         country: "China",     region: "Shaanxi",        lat: 34.3416,  lon: 108.9398, timezone: "Asia/Shanghai" },
  { name: "Hong Kong",     country: "Hong Kong",region: "",                lat: 22.3193,  lon: 114.1694, timezone: "Asia/Hong_Kong" },
  { name: "Macau",         country: "Macau",    region: "",                lat: 22.1987,  lon: 113.5439, timezone: "Asia/Macau" },
  { name: "Taipei",        country: "Taiwan",   region: "",                lat: 25.0330,  lon: 121.5654, timezone: "Asia/Taipei" },
  { name: "Seoul",         country: "South Korea",region: "",             lat: 37.5665,  lon: 126.9780, timezone: "Asia/Seoul" },
  { name: "Busan",         country: "South Korea",region: "",             lat: 35.1796,  lon: 129.0756, timezone: "Asia/Seoul" },
  { name: "Pyongyang",     country: "North Korea",region: "",            lat: 39.0392,  lon: 125.7625, timezone: "Asia/Pyongyang" },
  { name: "Ulaanbaatar",   country: "Mongolia", region: "",                lat: 47.8864,  lon: 106.9057, timezone: "Asia/Ulaanbaatar" },

  // ============ SOUTHEAST ASIA ============
  { name: "Bangkok",       country: "Thailand", region: "",                lat: 13.7563,  lon: 100.5018, timezone: "Asia/Bangkok" },
  { name: "Phuket",        country: "Thailand", region: "",                lat: 7.8804,   lon: 98.3923,  timezone: "Asia/Bangkok" },
  { name: "Chiang Mai",    country: "Thailand", region: "",                lat: 18.7883,  lon: 98.9853,  timezone: "Asia/Bangkok" },
  { name: "Pattaya",       country: "Thailand", region: "",                lat: 12.9236,  lon: 100.8825, timezone: "Asia/Bangkok" },
  { name: "Hanoi",         country: "Vietnam",  region: "",                lat: 21.0285,  lon: 105.8542, timezone: "Asia/Bangkok" },
  { name: "Ho Chi Minh City", country: "Vietnam", region: "",             lat: 10.8231,  lon: 106.6297, timezone: "Asia/Bangkok" },
  { name: "Da Nang",       country: "Vietnam",  region: "",                lat: 16.0544,  lon: 108.2022, timezone: "Asia/Bangkok" },
  { name: "Phnom Penh",    country: "Cambodia", region: "",                lat: 11.5564,  lon: 104.9282, timezone: "Asia/Phnom_Penh" },
  { name: "Siem Reap",     country: "Cambodia", region: "",                lat: 13.3671,  lon: 103.8448, timezone: "Asia/Phnom_Penh" },
  { name: "Vientiane",     country: "Laos",     region: "",                lat: 17.9757,  lon: 102.6331, timezone: "Asia/Vientiane" },
  { name: "Yangon",        country: "Myanmar",  region: "",                lat: 16.8409,  lon: 96.1735,  timezone: "Asia/Yangon" },
  { name: "Kuala Lumpur",  country: "Malaysia", region: "",                lat: 3.1390,   lon: 101.6869, timezone: "Asia/Kuala_Lumpur" },
  { name: "George Town",   country: "Malaysia", region: "Penang",          lat: 5.4164,   lon: 100.3327, timezone: "Asia/Kuala_Lumpur" },
  { name: "Singapore",     country: "Singapore",region: "",                lat: 1.3521,   lon: 103.8198, timezone: "Asia/Singapore" },
  { name: "Jakarta",       country: "Indonesia",region: "",                lat: -6.2088,  lon: 106.8456, timezone: "Asia/Jakarta" },
  { name: "Bali",          country: "Indonesia",region: "",                lat: -8.4095,  lon: 115.1889, timezone: "Asia/Makassar" },
  { name: "Manila",        country: "Philippines",region: "",              lat: 14.5995,  lon: 120.9842, timezone: "Asia/Manila" },
  { name: "Cebu",          country: "Philippines",region: "",              lat: 10.3157,  lon: 123.8854, timezone: "Asia/Manila" },
  { name: "Bandar Seri Begawan", country: "Brunei", region: "",           lat: 4.5353,   lon: 114.7277, timezone: "Asia/Brunei" },

  // ============ MIDDLE EAST ============
  { name: "Dubai",         country: "UAE",       region: "Dubai",         lat: 25.2048,  lon: 55.2708,  timezone: "Asia/Dubai" },
  { name: "Abu Dhabi",     country: "UAE",       region: "Abu Dhabi",     lat: 24.4539,  lon: 54.3773,  timezone: "Asia/Dubai" },
  { name: "Sharjah",       country: "UAE",       region: "Sharjah",       lat: 25.3463,  lon: 55.4209,  timezone: "Asia/Dubai" },
  { name: "Riyadh",        country: "Saudi Arabia",region: "",            lat: 24.7136,  lon: 46.6753,  timezone: "Asia/Riyadh" },
  { name: "Jeddah",        country: "Saudi Arabia",region: "",            lat: 21.4858,  lon: 39.1925,  timezone: "Asia/Riyadh" },
  { name: "Mecca",         country: "Saudi Arabia",region: "",            lat: 21.3891,  lon: 39.8579,  timezone: "Asia/Riyadh" },
  { name: "Medina",        country: "Saudi Arabia",region: "",            lat: 24.4686,  lon: 39.6142,  timezone: "Asia/Riyadh" },
  { name: "Doha",          country: "Qatar",     region: "",               lat: 25.2854,  lon: 51.5310,  timezone: "Asia/Qatar" },
  { name: "Kuwait City",   country: "Kuwait",    region: "",               lat: 29.3759,  lon: 47.9774,  timezone: "Asia/Kuwait" },
  { name: "Manama",        country: "Bahrain",   region: "",               lat: 26.2235,  lon: 50.5876,  timezone: "Asia/Bahrain" },
  { name: "Muscat",        country: "Oman",      region: "",               lat: 23.5859,  lon: 58.4059,  timezone: "Asia/Muscat" },
  { name: "Sana'a",        country: "Yemen",     region: "",               lat: 15.3694,  lon: 44.1910,  timezone: "Asia/Aden" },
  { name: "Baghdad",       country: "Iraq",      region: "",               lat: 33.3152,  lon: 44.3661,  timezone: "Asia/Baghdad" },
  { name: "Tehran",        country: "Iran",      region: "",               lat: 35.6892,  lon: 51.3890,  timezone: "Asia/Tehran" },
  { name: "Jerusalem",     country: "Israel",    region: "",               lat: 31.7683,  lon: 35.2137,  timezone: "Asia/Jerusalem" },
  { name: "Tel Aviv",      country: "Israel",    region: "",               lat: 32.0853,  lon: 34.7818,  timezone: "Asia/Jerusalem" },
  { name: "Amman",         country: "Jordan",    region: "",               lat: 31.9454,  lon: 35.9284,  timezone: "Asia/Amman" },
  { name: "Beirut",        country: "Lebanon",   region: "",               lat: 33.8938,  lon: 35.5018,  timezone: "Asia/Beirut" },
  { name: "Damascus",      country: "Syria",     region: "",               lat: 33.5138,  lon: 36.2765,  timezone: "Asia/Damascus" },
  { name: "Ankara",        country: "Turkey",    region: "",               lat: 39.9334,  lon: 32.8597,  timezone: "Europe/Istanbul" },
  { name: "Istanbul",      country: "Turkey",    region: "",               lat: 41.0082,  lon: 28.9784,  timezone: "Europe/Istanbul" },
  { name: "Izmir",         country: "Turkey",    region: "",               lat: 38.4237,  lon: 27.1428,  timezone: "Europe/Istanbul" },

  // ============ EUROPE ============
  { name: "London",        country: "UK",           region: "England",     lat: 51.5074,  lon: -0.1278,  timezone: "Europe/London" },
  { name: "Manchester",    country: "UK",           region: "England",     lat: 53.4808,  lon: -2.2426,  timezone: "Europe/London" },
  { name: "Birmingham",    country: "UK",           region: "England",     lat: 52.4862,  lon: -1.8904,  timezone: "Europe/London" },
  { name: "Edinburgh",     country: "UK",           region: "Scotland",    lat: 55.9533,  lon: -3.1883,  timezone: "Europe/London" },
  { name: "Glasgow",       country: "UK",           region: "Scotland",    lat: 55.8642,  lon: -4.2518,  timezone: "Europe/London" },
  { name: "Belfast",       country: "UK",           region: "Northern Ireland", lat: 54.5973, lon: -5.9301, timezone: "Europe/London" },
  { name: "Dublin",        country: "Ireland",      region: "",            lat: 53.3498,  lon: -6.2603,  timezone: "Europe/Dublin" },
  { name: "Paris",         country: "France",       region: "Île-de-France",lat: 48.8566, lon: 2.3522,  timezone: "Europe/Paris" },
  { name: "Marseille",     country: "France",       region: "",            lat: 43.2965,  lon: 5.3698,   timezone: "Europe/Paris" },
  { name: "Lyon",          country: "France",       region: "",            lat: 45.7640,  lon: 4.8357,   timezone: "Europe/Paris" },
  { name: "Nice",          country: "France",       region: "",            lat: 43.7102,  lon: 7.2620,   timezone: "Europe/Paris" },
  { name: "Berlin",        country: "Germany",      region: "",            lat: 52.5200,  lon: 13.4050,  timezone: "Europe/Berlin" },
  { name: "Munich",        country: "Germany",      region: "Bavaria",     lat: 48.1351,  lon: 11.5820,  timezone: "Europe/Berlin" },
  { name: "Hamburg",       country: "Germany",      region: "",            lat: 53.5511,  lon: 9.9937,   timezone: "Europe/Berlin" },
  { name: "Frankfurt",     country: "Germany",      region: "",            lat: 50.1109,  lon: 8.6821,   timezone: "Europe/Berlin" },
  { name: "Cologne",       country: "Germany",      region: "",            lat: 50.9375,  lon: 6.9603,   timezone: "Europe/Berlin" },
  { name: "Madrid",        country: "Spain",        region: "",            lat: 40.4168,  lon: -3.7038,  timezone: "Europe/Madrid" },
  { name: "Barcelona",     country: "Spain",        region: "Catalonia",   lat: 41.3851,  lon: 2.1734,   timezone: "Europe/Madrid" },
  { name: "Valencia",      country: "Spain",        region: "",            lat: 39.4699,  lon: -0.3763,  timezone: "Europe/Madrid" },
  { name: "Seville",       country: "Spain",        region: "",            lat: 37.3886,  lon: -5.9823,  timezone: "Europe/Madrid" },
  { name: "Lisbon",        country: "Portugal",     region: "",            lat: 38.7223,  lon: -9.1393,  timezone: "Europe/Lisbon" },
  { name: "Porto",         country: "Portugal",     region: "",            lat: 41.1579,  lon: -8.6291,  timezone: "Europe/Lisbon" },
  { name: "Rome",          country: "Italy",        region: "Lazio",       lat: 41.9028,  lon: 12.4964,  timezone: "Europe/Rome" },
  { name: "Milan",         country: "Italy",        region: "Lombardy",    lat: 45.4642,  lon: 9.1900,   timezone: "Europe/Rome" },
  { name: "Naples",        country: "Italy",        region: "",            lat: 40.8518,  lon: 14.2681,  timezone: "Europe/Rome" },
  { name: "Venice",        country: "Italy",        region: "",            lat: 45.4408,  lon: 12.3155,  timezone: "Europe/Rome" },
  { name: "Florence",      country: "Italy",        region: "Tuscany",     lat: 43.7696,  lon: 11.2558,  timezone: "Europe/Rome" },
  { name: "Athens",        country: "Greece",       region: "",            lat: 37.9838,  lon: 23.7275,  timezone: "Europe/Athens" },
  { name: "Thessaloniki",  country: "Greece",       region: "",            lat: 40.6401,  lon: 22.9444,  timezone: "Europe/Athens" },
  { name: "Vienna",        country: "Austria",      region: "",            lat: 48.2082,  lon: 16.3738,  timezone: "Europe/Vienna" },
  { name: "Zurich",        country: "Switzerland",  region: "",            lat: 47.3769,  lon: 8.5417,   timezone: "Europe/Zurich" },
  { name: "Geneva",        country: "Switzerland",  region: "",            lat: 46.2044,  lon: 6.1432,   timezone: "Europe/Zurich" },
  { name: "Brussels",      country: "Belgium",      region: "",            lat: 50.8503,  lon: 4.3517,   timezone: "Europe/Brussels" },
  { name: "Amsterdam",     country: "Netherlands",  region: "",            lat: 52.3676,  lon: 4.9041,   timezone: "Europe/Amsterdam" },
  { name: "Rotterdam",     country: "Netherlands",  region: "",            lat: 51.9244,  lon: 4.4777,   timezone: "Europe/Amsterdam" },
  { name: "Copenhagen",    country: "Denmark",      region: "",            lat: 55.6761,  lon: 12.5683,  timezone: "Europe/Copenhagen" },
  { name: "Stockholm",     country: "Sweden",       region: "",            lat: 59.3293,  lon: 18.0686,  timezone: "Europe/Stockholm" },
  { name: "Gothenburg",    country: "Sweden",       region: "",            lat: 57.7089,  lon: 11.9746,  timezone: "Europe/Stockholm" },
  { name: "Oslo",          country: "Norway",       region: "",            lat: 59.9139,  lon: 10.7522,  timezone: "Europe/Oslo" },
  { name: "Bergen",        country: "Norway",       region: "",            lat: 60.3913,  lon: 5.3221,   timezone: "Europe/Oslo" },
  { name: "Helsinki",      country: "Finland",      region: "",            lat: 60.1699,  lon: 24.9384,  timezone: "Europe/Helsinki" },
  { name: "Reykjavik",     country: "Iceland",      region: "",            lat: 64.1466,  lon: -21.9426, timezone: "Atlantic/Reykjavik" },
  { name: "Warsaw",        country: "Poland",       region: "",            lat: 52.2297,  lon: 21.0122,  timezone: "Europe/Warsaw" },
  { name: "Krakow",        country: "Poland",       region: "",            lat: 50.0647,  lon: 19.9450,  timezone: "Europe/Warsaw" },
  { name: "Prague",        country: "Czechia",      region: "",            lat: 50.0755,  lon: 14.4378,  timezone: "Europe/Prague" },
  { name: "Budapest",      country: "Hungary",      region: "",            lat: 47.4979,  lon: 19.0402,  timezone: "Europe/Budapest" },
  { name: "Bucharest",     country: "Romania",      region: "",            lat: 44.4268,  lon: 26.1025,  timezone: "Europe/Bucharest" },
  { name: "Sofia",         country: "Bulgaria",     region: "",            lat: 42.6977,  lon: 23.3219,  timezone: "Europe/Sofia" },
  { name: "Belgrade",      country: "Serbia",       region: "",            lat: 44.7866,  lon: 20.4489,  timezone: "Europe/Belgrade" },
  { name: "Zagreb",        country: "Croatia",      region: "",            lat: 45.8150,  lon: 15.9819,  timezone: "Europe/Zagreb" },
  { name: "Vienna",        country: "Austria",      region: "",            lat: 48.2082,  lon: 16.3738,  timezone: "Europe/Vienna" },
  { name: "Moscow",        country: "Russia",       region: "",            lat: 55.7558,  lon: 37.6173,  timezone: "Europe/Moscow" },
  { name: "Saint Petersburg", country: "Russia",    region: "",            lat: 59.9311,  lon: 30.3609,  timezone: "Europe/Moscow" },
  { name: "Kyiv",          country: "Ukraine",      region: "",            lat: 50.4501,  lon: 30.5234,  timezone: "Europe/Kiev" },

  // ============ AFRICA ============
  { name: "Cairo",         country: "Egypt",        region: "",            lat: 30.0444,  lon: 31.2357,  timezone: "Africa/Cairo" },
  { name: "Alexandria",    country: "Egypt",        region: "",            lat: 31.2001,  lon: 29.9187,  timezone: "Africa/Cairo" },
  { name: "Luxor",         country: "Egypt",        region: "",            lat: 25.6872,  lon: 32.6396,  timezone: "Africa/Cairo" },
  { name: "Aswan",         country: "Egypt",        region: "",            lat: 24.0889,  lon: 32.8998,  timezone: "Africa/Cairo" },
  { name: "Lagos",         country: "Nigeria",      region: "",            lat: 6.5244,   lon: 3.3792,   timezone: "Africa/Lagos" },
  { name: "Abuja",         country: "Nigeria",      region: "",            lat: 9.0765,   lon: 7.3986,   timezone: "Africa/Lagos" },
  { name: "Nairobi",       country: "Kenya",        region: "",            lat: -1.2921,  lon: 36.8219,  timezone: "Africa/Nairobi" },
  { name: "Mombasa",       country: "Kenya",        region: "",            lat: -4.0435,  lon: 39.6682,  timezone: "Africa/Nairobi" },
  { name: "Addis Ababa",   country: "Ethiopia",     region: "",            lat: 9.0320,   lon: 38.7470,  timezone: "Africa/Addis_Ababa" },
  { name: "Dar es Salaam", country: "Tanzania",     region: "",            lat: -6.7924,  lon: 39.2083,  timezone: "Africa/Dar_es_Salaam" },
  { name: "Kampala",       country: "Uganda",       region: "",            lat: 0.3476,   lon: 32.5825,  timezone: "Africa/Kampala" },
  { name: "Kigali",        country: "Rwanda",       region: "",            lat: -1.9706,  lon: 30.1044,  timezone: "Africa/Kigali" },
  { name: "Cape Town",     country: "South Africa", region: "Western Cape", lat: -33.9249, lon: 18.4241,  timezone: "Africa/Johannesburg" },
  { name: "Johannesburg",  country: "South Africa", region: "Gauteng",     lat: -26.2041, lon: 28.0473,  timezone: "Africa/Johannesburg" },
  { name: "Durban",        country: "South Africa", region: "KwaZulu-Natal",lat: -29.8587, lon: 31.0218,  timezone: "Africa/Johannesburg" },
  { name: "Pretoria",      country: "South Africa", region: "Gauteng",     lat: -25.7479, lon: 28.2293,  timezone: "Africa/Johannesburg" },
  { name: "Casablanca",    country: "Morocco",      region: "",            lat: 33.5731,  lon: -7.5898,  timezone: "Africa/Casablanca" },
  { name: "Marrakech",     country: "Morocco",      region: "",            lat: 31.6295,  lon: -7.9811,  timezone: "Africa/Casablanca" },
  { name: "Rabat",         country: "Morocco",      region: "",            lat: 34.0209,  lon: -6.8416,  timezone: "Africa/Casablanca" },
  { name: "Tunis",         country: "Tunisia",      region: "",            lat: 36.8065,  lon: 10.1815,  timezone: "Africa/Tunis" },
  { name: "Algiers",       country: "Algeria",      region: "",            lat: 36.7538,  lon: 3.0588,   timezone: "Africa/Algiers" },
  { name: "Accra",         country: "Ghana",        region: "",            lat: 5.6037,   lon: -0.1870,  timezone: "Africa/Accra" },
  { name: "Dakar",         country: "Senegal",      region: "",            lat: 14.7167,  lon: -17.4677, timezone: "Africa/Dakar" },
  { name: "Antananarivo",  country: "Madagascar",   region: "",            lat: -18.8792, lon: 47.5079,  timezone: "Indian/Antananarivo" },

  // ============ NORTH AMERICA ============
  { name: "New York",      country: "USA",          region: "New York",    lat: 40.7128,  lon: -74.0060, timezone: "America/New_York" },
  { name: "Los Angeles",   country: "USA",          region: "California",  lat: 34.0522,  lon: -118.2437,timezone: "America/Los_Angeles" },
  { name: "Chicago",       country: "USA",          region: "Illinois",    lat: 41.8781,  lon: -87.6298, timezone: "America/Chicago" },
  { name: "Houston",       country: "USA",          region: "Texas",       lat: 29.7604,  lon: -95.3698, timezone: "America/Chicago" },
  { name: "Phoenix",       country: "USA",          region: "Arizona",     lat: 33.4484,  lon: -112.0740,timezone: "America/Phoenix" },
  { name: "Philadelphia",  country: "USA",          region: "Pennsylvania",lat: 39.9526,  lon: -75.1652, timezone: "America/New_York" },
  { name: "San Antonio",   country: "USA",          region: "Texas",       lat: 29.4241,  lon: -98.4936, timezone: "America/Chicago" },
  { name: "San Diego",     country: "USA",          region: "California",  lat: 32.7157,  lon: -117.1611,timezone: "America/Los_Angeles" },
  { name: "Dallas",        country: "USA",          region: "Texas",       lat: 32.7767,  lon: -96.7970, timezone: "America/Chicago" },
  { name: "San Jose",      country: "USA",          region: "California",  lat: 37.3382,  lon: -121.8863,timezone: "America/Los_Angeles" },
  { name: "Austin",        country: "USA",          region: "Texas",       lat: 30.2672,  lon: -97.7431, timezone: "America/Chicago" },
  { name: "Jacksonville",  country: "USA",          region: "Florida",     lat: 30.3322,  lon: -81.6557, timezone: "America/New_York" },
  { name: "Fort Worth",    country: "USA",          region: "Texas",       lat: 32.7555,  lon: -97.3308, timezone: "America/Chicago" },
  { name: "Columbus",      country: "USA",          region: "Ohio",        lat: 39.9612,  lon: -82.9988, timezone: "America/New_York" },
  { name: "Charlotte",     country: "USA",          region: "North Carolina",lat:35.2271,lon: -80.8431, timezone: "America/New_York" },
  { name: "Indianapolis",  country: "USA",          region: "Indiana",     lat: 39.7684,  lon: -86.1581, timezone: "America/Indiana/Indianapolis" },
  { name: "San Francisco", country: "USA",          region: "California",  lat: 37.7749,  lon: -122.4194,timezone: "America/Los_Angeles" },
  { name: "Seattle",       country: "USA",          region: "Washington",  lat: 47.6062,  lon: -122.3321,timezone: "America/Los_Angeles" },
  { name: "Denver",        country: "USA",          region: "Colorado",    lat: 39.7392,  lon: -104.9903,timezone: "America/Denver" },
  { name: "Boston",        country: "USA",          region: "Massachusetts",lat:42.3601,lon: -71.0589, timezone: "America/New_York" },
  { name: "Washington",    country: "USA",          region: "D.C.",        lat: 38.9072,  lon: -77.0369, timezone: "America/New_York" },
  { name: "Nashville",     country: "USA",          region: "Tennessee",   lat: 36.1627,  lon: -86.7816, timezone: "America/Chicago" },
  { name: "Miami",         country: "USA",          region: "Florida",     lat: 25.7617,  lon: -80.1918, timezone: "America/New_York" },
  { name: "Las Vegas",     country: "USA",          region: "Nevada",      lat: 36.1699,  lon: -115.1398,timezone: "America/Los_Angeles" },
  { name: "Portland",      country: "USA",          region: "Oregon",      lat: 45.5152,  lon: -122.6784,timezone: "America/Los_Angeles" },
  { name: "Honolulu",      country: "USA",          region: "Hawaii",      lat: 21.3099,  lon: -157.8581,timezone: "Pacific/Honolulu" },
  { name: "Anchorage",     country: "USA",          region: "Alaska",      lat: 61.2181,  lon: -149.9003,timezone: "America/Anchorage" },
  { name: "Toronto",       country: "Canada",       region: "Ontario",     lat: 43.6532,  lon: -79.3832, timezone: "America/Toronto" },
  { name: "Vancouver",     country: "Canada",       region: "BC",          lat: 49.2827,  lon: -123.1207,timezone: "America/Vancouver" },
  { name: "Montreal",      country: "Canada",       region: "Quebec",      lat: 45.5017,  lon: -73.5673, timezone: "America/Toronto" },
  { name: "Calgary",       country: "Canada",       region: "Alberta",     lat: 51.0447,  lon: -114.0719,timezone: "America/Edmonton" },
  { name: "Ottawa",        country: "Canada",       region: "Ontario",     lat: 45.4215,  lon: -75.6972, timezone: "America/Toronto" },
  { name: "Mexico City",   country: "Mexico",       region: "",            lat: 19.4326,  lon: -99.1332, timezone: "America/Mexico_City" },
  { name: "Cancun",        country: "Mexico",       region: "Quintana Roo",lat: 21.1619,  lon: -86.8515, timezone: "America/Cancun" },
  { name: "Guadalajara",   country: "Mexico",       region: "Jalisco",     lat: 20.6597,  lon: -103.3496,timezone: "America/Mexico_City" },
  { name: "Havana",        country: "Cuba",         region: "",            lat: 23.1136,  lon: -82.3666, timezone: "America/Havana" },
  { name: "Panama City",   country: "Panama",       region: "",            lat: 8.9824,   lon: -79.5199, timezone: "America/Panama" },

  // ============ SOUTH AMERICA ============
  { name: "São Paulo",     country: "Brazil",       region: "",            lat: -23.5505, lon: -46.6333, timezone: "America/Sao_Paulo" },
  { name: "Rio de Janeiro",country: "Brazil",       region: "",            lat: -22.9068, lon: -43.1729, timezone: "America/Sao_Paulo" },
  { name: "Brasília",      country: "Brazil",       region: "",            lat: -15.7942, lon: -47.8822, timezone: "America/Sao_Paulo" },
  { name: "Salvador",      country: "Brazil",       region: "Bahia",       lat: -12.9714, lon: -38.5014, timezone: "America/Bahia" },
  { name: "Fortaleza",     country: "Brazil",       region: "",            lat: -3.7172,  lon: -38.5434, timezone: "America/Fortaleza" },
  { name: "Belo Horizonte",country: "Brazil",       region: "",            lat: -19.9167, lon: -43.9345, timezone: "America/Sao_Paulo" },
  { name: "Manaus",        country: "Brazil",       region: "Amazonas",    lat: -3.1190,  lon: -60.0217, timezone: "America/Manaus" },
  { name: "Buenos Aires",  country: "Argentina",    region: "",            lat: -34.6037, lon: -58.3816, timezone: "America/Argentina/Buenos_Aires" },
  { name: "Córdoba",       country: "Argentina",    region: "",            lat: -31.4201, lon: -64.1888, timezone: "America/Argentina/Cordoba" },
  { name: "Mendoza",       country: "Argentina",    region: "",            lat: -32.8895, lon: -68.8458, timezone: "America/Argentina/Mendoza" },
  { name: "Santiago",      country: "Chile",        region: "",            lat: -33.4489, lon: -70.6693, timezone: "America/Santiago" },
  { name: "Valparaíso",    country: "Chile",        region: "",            lat: -33.0472, lon: -71.6127, timezone: "America/Santiago" },
  { name: "Lima",          country: "Peru",         region: "",            lat: -12.0464, lon: -77.0428, timezone: "America/Lima" },
  { name: "Cusco",         country: "Peru",         region: "",            lat: -13.5320, lon: -71.9675, timezone: "America/Lima" },
  { name: "Bogotá",        country: "Colombia",     region: "",            lat: 4.7110,   lon: -74.0721, timezone: "America/Bogota" },
  { name: "Medellín",      country: "Colombia",     region: "",            lat: 6.2442,   lon: -75.5812, timezone: "America/Bogota" },
  { name: "Cartagena",     country: "Colombia",     region: "",            lat: 10.3910,  lon: -75.4794, timezone: "America/Bogota" },
  { name: "Quito",         country: "Ecuador",      region: "",            lat: -0.1807,  lon: -78.4678, timezone: "America/Guayaquil" },
  { name: "Guayaquil",     country: "Ecuador",      region: "",            lat: -2.1709,  lon: -79.9224, timezone: "America/Guayaquil" },
  { name: "Caracas",       country: "Venezuela",    region: "",            lat: 10.4806,  lon: -66.9036, timezone: "America/Caracas" },
  { name: "La Paz",        country: "Bolivia",      region: "",            lat: -16.4897, lon: -68.1193, timezone: "America/La_Paz" },
  { name: "Montevideo",    country: "Uruguay",      region: "",            lat: -34.9011, lon: -56.1645, timezone: "America/Montevideo" },
  { name: "Asunción",      country: "Paraguay",     region: "",            lat: -25.2637, lon: -57.5759, timezone: "America/Asuncion" },

  // ============ OCEANIA ============
  { name: "Sydney",        country: "Australia",    region: "NSW",         lat: -33.8688, lon: 151.2093, timezone: "Australia/Sydney" },
  { name: "Melbourne",     country: "Australia",    region: "VIC",         lat: -37.8136, lon: 144.9631, timezone: "Australia/Melbourne" },
  { name: "Brisbane",      country: "Australia",    region: "QLD",         lat: -27.4698, lon: 153.0251, timezone: "Australia/Brisbane" },
  { name: "Perth",         country: "Australia",    region: "WA",          lat: -31.9505, lon: 115.8605, timezone: "Australia/Perth" },
  { name: "Adelaide",      country: "Australia",    region: "SA",          lat: -34.9285, lon: 138.6007, timezone: "Australia/Adelaide" },
  { name: "Canberra",      country: "Australia",    region: "ACT",         lat: -35.2809, lon: 149.1300, timezone: "Australia/Canberra" },
  { name: "Hobart",        country: "Australia",    region: "TAS",         lat: -42.8821, lon: 147.3272, timezone: "Australia/Hobart" },
  { name: "Darwin",        country: "Australia",    region: "NT",          lat: -12.4634, lon: 130.8456, timezone: "Australia/Darwin" },
  { name: "Auckland",      country: "New Zealand",  region: "",            lat: -36.8485, lon: 174.7633, timezone: "Pacific/Auckland" },
  { name: "Wellington",    country: "New Zealand",  region: "",            lat: -41.2865, lon: 174.7762, timezone: "Pacific/Auckland" },
  { name: "Christchurch",  country: "New Zealand",  region: "",            lat: -43.5321, lon: 172.6362, timezone: "Pacific/Auckland" },
  { name: "Suva",          country: "Fiji",         region: "",            lat: -18.1248, lon: 178.4501, timezone: "Pacific/Fiji" },
  { name: "Port Moresby",  country: "Papua New Guinea", region: "",         lat: -9.4438,  lon: 147.1803, timezone: "Pacific/Port_Moresby" },
  { name: "Apia",          country: "Samoa",        region: "",            lat: -13.8506, lon: -171.7513,timezone: "Pacific/Apia" },

  // ============ POLAR / EXTREME CLIMATE (for variety) ============
  { name: "Longyearbyen",  country: "Svalbard",     region: "",            lat: 78.2232,  lon: 15.6267,  timezone: "Arctic/Longyearbyen" },
  { name: "Nuuk",          country: "Greenland",    region: "",            lat: 64.1814,  lon: -51.6941, timezone: "America/Godthab" },
  { name: "Tromsø",        country: "Norway",       region: "",            lat: 69.6492,  lon: 18.9553,  timezone: "Europe/Oslo" },
  { name: "Murmansk",      country: "Russia",       region: "",            lat: 68.9585,  lon: 33.0827,  timezone: "Europe/Moscow" },
  { name: "Iqaluit",       country: "Canada",       region: "Nunavut",     lat: 63.7467,  lon: -68.5170, timezone: "America/Iqaluit" },
  { name: "Yakutsk",       country: "Russia",       region: "",            lat: 62.0272,  lon: 129.7422, timezone: "Asia/Yakutsk" },
  { name: "Verkhoyansk",   country: "Russia",       region: "",            lat: 67.5500,  lon: 133.4000, timezone: "Asia/Vladivostok" },
];

// Merge with Indian cities (~3200+ entries total)
for (const c of [...INDIA_CITIES, ...INDIA_CITIES_EXTRA, ...INDIA_CITIES_EXTRA2, ...AP_TN_CITIES, ...AP_ALL_CITIES]) {
  // Skip duplicates
  if (CITIES.some(x => x.name.toLowerCase() === c.name.toLowerCase())) continue;
  CITIES.push({
    name: c.name,
    country: "India",
    region: c.state,
    lat: c.lat,
    lon: c.lon,
    timezone: "Asia/Kolkata",
  });
}

/** Build a lookup map keyed by lowercased `name + country`. */
const CITY_DB: Record<string, City> = {};
for (const c of CITIES) {
  CITY_DB[c.name.toLowerCase()] = c;
  CITY_DB[`${c.name.toLowerCase()} ${c.country.toLowerCase()}`] = c;
}

export function searchLocation(query: string): City[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const matches: { city: City; score: number }[] = [];
  for (const c of CITIES) {
    const name = c.name.toLowerCase();
    const country = c.country.toLowerCase();
    const region = c.region.toLowerCase();
    let score = 0;
    if (name === q) score = 100;
    else if (name.startsWith(q)) score = 90;
    else if (name.includes(q)) score = 70;
    else if (country.includes(q)) score = 50;
    else if (region.includes(q)) score = 40;
    if (score > 0) matches.push({ city: c, score });
  }
  matches.sort((a, b) => b.score - a.score);
  return matches.slice(0, 20).map(m => m.city);
}

export function resolveLocation(query: string): City | null {
  const q = query.trim().toLowerCase();
  if (!q) return null;
  if (CITY_DB[q]) return CITY_DB[q];
  // Try fuzzy: find first city whose name contains the query
  const hit = CITIES.find(c => c.name.toLowerCase().includes(q));
  return hit || null;
}
