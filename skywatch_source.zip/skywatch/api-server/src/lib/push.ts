/**
 * Web Push notifications. Uses VAPID keys for authentication.
 * Subscriptions can be tied to either a logged-in user or an
 * anonymous browser session.
 */

import webpush from "web-push";
import { db } from "./db.js";
import type { Alert } from "./alerts.js";

const PUBLIC  = process.env.VAPID_PUBLIC_KEY;
const PRIVATE = process.env.VAPID_PRIVATE_KEY;
const SUBJECT = process.env.VAPID_SUBJECT || "mailto:admin@skywatch.app";

let configured = false;
if (PUBLIC && PRIVATE) {
  webpush.setVapidDetails(SUBJECT, PUBLIC, PRIVATE);
  configured = true;
  console.log("[push] VAPID configured");
} else {
  console.log("[push] VAPID keys missing — push will be logged to console");
}

export function getVapidPublicKey() {
  return PUBLIC || "";
}

export function isPushConfigured() {
  return configured;
}

interface PushSubRow {
  id: number;
  endpoint: string;
  p256dh: string;
  auth: string;
}

export function savePushSubscription(opts: {
  userId?: number | null;
  anonymousId?: string | null;
  endpoint: string;
  keys: { p256dh: string; auth: string };
}) {
  db.prepare(
    `INSERT INTO push_subscriptions (user_id, anonymous_id, endpoint, p256dh, auth)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(endpoint) DO UPDATE SET
       user_id = excluded.user_id,
       anonymous_id = excluded.anonymous_id,
       p256dh = excluded.p256dh,
       auth = excluded.auth`
  ).run(opts.userId ?? null, opts.anonymousId ?? null, opts.endpoint, opts.keys.p256dh, opts.keys.auth);
}

export function removePushSubscription(endpoint: string) {
  db.prepare("DELETE FROM push_subscriptions WHERE endpoint = ?").run(endpoint);
}

function getSubscriptionsFor(opts: { userId?: number | null; anonymousId?: string | null }) {
  const subs: PushSubRow[] = [];
  if (opts.userId) {
    subs.push(...(db.prepare(
      "SELECT * FROM push_subscriptions WHERE user_id = ?"
    ).all(opts.userId) as PushSubRow[]));
  }
  if (opts.anonymousId) {
    subs.push(...(db.prepare(
      "SELECT * FROM push_subscriptions WHERE anonymous_id = ?"
    ).all(opts.anonymousId) as PushSubRow[]));
  }
  // de-dupe by endpoint
  const seen = new Set<string>();
  return subs.filter(s => (seen.has(s.endpoint) ? false : (seen.add(s.endpoint), true)));
}

export async function sendAlertPush(opts: {
  userId?: number | null;
  anonymousId?: string | null;
  alert: Alert;
  locationName: string;
}) {
  const subs = getSubscriptionsFor(opts);
  if (!subs.length) return { ok: true, sent: 0 };

  const payload = JSON.stringify({
    title: opts.alert.title,
    body: `${opts.locationName} — ${opts.alert.message}`,
    icon: "/icon-192.png",
    tag: `skywatch-${opts.alert.type}-${opts.alert.forecastDay}`,
    data: { alert: opts.alert, location: opts.locationName },
  });

  if (!configured) {
    console.log(`\n[push-stub]\n${payload}\n`);
    return { ok: true, sent: 0, stub: true };
  }

  const results = await Promise.allSettled(
    subs.map(s =>
      webpush.sendNotification(
        {
          endpoint: s.endpoint,
          keys: { p256dh: s.p256dh, auth: s.auth },
        },
        payload
      ).catch(err => {
        if (err.statusCode === 404 || err.statusCode === 410) {
          removePushSubscription(s.endpoint);
        }
        throw err;
      })
    )
  );

  const sent = results.filter(r => r.status === "fulfilled").length;
  return { ok: true, sent };
}
