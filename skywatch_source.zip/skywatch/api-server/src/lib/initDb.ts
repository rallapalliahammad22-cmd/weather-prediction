// Standalone script to (re)create the database. Run with: npm run init-db
import { dbReady } from "./db.js";

dbReady().then(() => {
  console.log("[initDb] Done.");
  process.exit(0);
}).catch(err => {
  console.error("[initDb] Failed:", err);
  process.exit(1);
});
