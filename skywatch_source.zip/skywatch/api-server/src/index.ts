/**
 * SkyWatch API Server
 * --------------------------------------------------------------
 * Express + SQLite. All endpoints are documented inline below.
 */

import "dotenv/config";
import express from "express";
import cors from "cors";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { existsSync } from "fs";

import authRoutes from "./routes/auth.js";
import locationsRoutes from "./routes/locations.js";
import weatherRoutes from "./routes/weather.js";
import alertsRoutes from "./routes/alerts.js";
import notificationsRoutes from "./routes/notifications.js";
import { startAlertChecker } from "./jobs/alertChecker.js";
import { dbReady } from "./lib/db.js"; // initialise database

const app = express();
const PORT = Number(process.env.PORT || 4000);
const FRONTEND = process.env.FRONTEND_URL || "http://localhost:5173";

// Resolve __dirname for ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "1mb" }));

// ---------- Health ----------
app.get("/api", (_req, res) => {
  res.json({
    name: "SkyWatch API",
    version: "1.0.0",
    uptime: process.uptime(),
    endpoints: [
      "GET  /api/health",
      "POST /api/auth/register",
      "POST /api/auth/login",
      "GET  /api/auth/me",
      "PATCH /api/auth/me",
      "GET  /api/locations?...",
      "POST /api/locations",
      "POST /api/locations/:id/activate",
      "DELETE /api/locations/:id",
      "GET  /api/locations/:id/snapshot",
      "GET  /api/weather/current?lat=&lon=",
      "GET  /api/weather/forecast?lat=&lon=",
      "GET  /api/weather/outlook?lat=&lon=",
      "GET  /api/weather/climate?lat=&lon=",
      "GET  /api/weather/historical?lat=&lon=&from=&to=",
      "GET  /api/weather/search?q=",
      "GET  /api/alerts",
      "POST /api/alerts/generate",
      "POST /api/alerts/:id/acknowledge",
      "DELETE /api/alerts/:id",
      "GET  /api/notifications/vapid-public-key",
      "POST /api/notifications/push/subscribe",
      "POST /api/notifications/push/unsubscribe",
      "POST /api/notifications/preferences",
    ],
  });
});
app.get("/api/health", (_req, res) => res.json({ ok: true, ts: Date.now() }));

// ---------- Routes ----------
app.use("/api/auth", authRoutes);
app.use("/api/locations", locationsRoutes);
app.use("/api/weather", weatherRoutes);
app.use("/api/alerts", alertsRoutes);
app.use("/api/notifications", notificationsRoutes);

// ---------- Static frontend (Electron production) ----------
// Look for the React dist folder in known locations and serve it.
// Registered BEFORE the 404 handler so React routes work.
const STATIC_CANDIDATES = [
  join(__dirname, "..", "..", "..", "weather-app", "dist"),  // dev source
  join(__dirname, "..", "frontend"),                          // bundled: dist/index.js -> ../frontend
  join(__dirname, "..", "..", "frontend"),                    // alt
  join(__dirname, "..", "public"),                            // legacy
  join(__dirname, "public"),
];

let frontendDir: string | null = null;
for (const dir of STATIC_CANDIDATES) {
  if (existsSync(join(dir, "index.html"))) {
    frontendDir = dir;
    break;
  }
}

if (frontendDir) {
  console.log(`[static] Serving frontend from: ${frontendDir}`);
  app.use(express.static(frontendDir));
} else {
  console.log("[static] No frontend dist found - API only mode");
  app.get("/", (_req, res) => {
    res.json({
      name: "SkyWatch API",
      version: "1.0.0",
      docs: "/api",
      uptime: process.uptime(),
    });
  });
}

// ---------- 404 (only for /api/* that didn't match) ----------
app.use("/api", (req, res) => {
  res.status(404).json({ error: `Not found: ${req.method} ${req.path}` });
});

// ---------- SPA fallback (last resort) ----------
// For non-/api routes, if frontend dist exists, serve index.html so React Router works.
if (frontendDir) {
  app.get(/^(?!\/api).*/, (_req, res) => {
    res.sendFile(join(frontendDir!, "index.html"));
  });
} else {
  // No frontend - 404 everything else
  app.use((req, res) => {
    res.status(404).json({ error: `Not found: ${req.method} ${req.path}` });
  });
}

// ---------- Errors ----------
app.use((err: any, _req: any, res: any, _next: any) => {
  console.error("[error]", err);
  res.status(500).json({ error: err.message || "Internal server error" });
});

// ---------- Boot ----------
dbReady().then(() => {
  app.listen(PORT, () => {
    console.log(`\n☁  SkyWatch API running at http://localhost:${PORT}`);
    console.log(`   Frontend expected at ${FRONTEND}`);
    console.log(`   Try: curl http://localhost:${PORT}/api/health\n`);
    startAlertChecker();
  });
}).catch(err => {
  console.error("[boot] failed to start:", err);
  process.exit(1);
});
