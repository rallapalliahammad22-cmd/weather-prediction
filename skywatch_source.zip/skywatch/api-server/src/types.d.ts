// Global type declarations for the SkyWatch API server

import type { TokenPayload } from "./lib/auth.js";

declare global {
  namespace Express {
    interface Request {
      /** Populated by the `attachUser` middleware when a valid JWT is present. */
      user?: TokenPayload;
    }
  }
}

export {};
