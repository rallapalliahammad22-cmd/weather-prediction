export const USERS_SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  phone TEXT,
  display_name TEXT,
  notification_prefs TEXT NOT NULL DEFAULT '{"email":true,"sms":false,"push":true,"inApp":true}',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`;
