export const LOCATIONS_SCHEMA = `
CREATE TABLE IF NOT EXISTS locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  anonymous_id TEXT,
  name TEXT NOT NULL,
  country TEXT,
  region TEXT,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  timezone TEXT,
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_locations_user ON locations(user_id);
CREATE INDEX IF NOT EXISTS idx_locations_anon ON locations(anonymous_id);
`;
