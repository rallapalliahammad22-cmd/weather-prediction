# SkyWatch setup for Windows PowerShell
# Run with:  powershell -ExecutionPolicy Bypass -File .\setup.ps1
$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "☁  SkyWatch setup" -ForegroundColor Cyan
Write-Host ""

# Backend
Write-Host "[1/2] Installing api-server..." -ForegroundColor Yellow
Set-Location "$PSScriptRoot\api-server"
# Remove old lockfile to apply new overrides
if (Test-Path package-lock.json) { Remove-Item package-lock.json -Force }
npm install
if ($LASTEXITCODE -ne 0) { Write-Host "❌ api-server install failed" -ForegroundColor Red; exit 1 }

# Frontend
Write-Host ""
Write-Host "[2/2] Installing weather-app..." -ForegroundColor Yellow
Set-Location "$PSScriptRoot\weather-app"
if (Test-Path package-lock.json) { Remove-Item package-lock.json -Force }
npm install
if ($LASTEXITCODE -ne 0) { Write-Host "❌ weather-app install failed" -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "✅ Done. To start the app:" -ForegroundColor Green
Write-Host ""
Write-Host "   Terminal 1:  cd `"$PSScriptRoot\api-server`"  ;  npm run dev"
Write-Host "   Terminal 2:  cd `"$PSScriptRoot\weather-app`" ;  npm run dev"
Write-Host ""
Write-Host "Then open http://localhost:5173 in your browser."
Write-Host ""
Write-Host "Run 'npm audit' in each folder to verify vulnerabilities are fixed."
